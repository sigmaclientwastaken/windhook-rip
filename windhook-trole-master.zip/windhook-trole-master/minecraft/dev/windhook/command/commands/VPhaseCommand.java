package dev.windhook.command.commands;

import dev.windhook.command.Command;
import dev.windhook.utils.Integers;
import dev.windhook.utils.Utils;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;

public class VPhaseCommand extends Command {

	public VPhaseCommand() {
		super("vphase", "vphase", "Vertically clips to the closest block below you.", "vp");
	}

	@Override
	public String executeCommand(String line, String[] args) {

		if(mc.thePlayer.onGround) {
			//mc.player.setPosition(((int)event.x) - 0.5, event.y, ((int)event.z) - 0.5);
			for(int i = 1; i < 9; i++) {
				BlockPos pos = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - i, mc.thePlayer.posZ);
				IBlockState blockState = Utils.getBlockState(pos);
				if(blockState.getBlock().getMaterial() == Material.air && i < 8
						&& Utils.getBlockState(pos.down()).getBlock().getMaterial() == Material.air) {
					mc.thePlayer.setPosition(pos.getX() + 0.5, mc.thePlayer.posY - (i + 1), pos.getZ() + 0.5);
					break;
				}
			}
		}
		
		return "&aYou have VPhased!&a.";
		
	}

}