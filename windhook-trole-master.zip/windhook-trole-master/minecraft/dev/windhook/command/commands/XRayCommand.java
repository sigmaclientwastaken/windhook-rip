package dev.windhook.command.commands;

import java.util.ArrayList;
import java.util.List;

import dev.windhook.BaseClient;
import dev.windhook.command.Command;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.modules.render.XRay;
import dev.windhook.utils.Lists;

public class XRayCommand extends Command {

	public XRayCommand() {
		super("xray", "xray <add|remove|clear> [name|id]", "Add or remove a block from the xray list");
	}

	@Override
	public String executeCommand(String line, String[] args) {

		/*
		ArrayList<Integer> exceptions = ModuleManager.xray.get();

		if (args.length < 2) {
			if (args.length < 1)
				return getSyntax("&c");

			if ("clear".equals(args[0].toLowerCase())) {
				exceptions.clear();
				ModuleManager.xray.KEY_IDS = exceptions;
				return "&aThe exceptions list has been cleared";
			}
			return getSyntax("&c");
		}

		String blockStr = args[1].toUpperCase();


		switch (args[0].toLowerCase()) {
		case "add": {
			if (exceptions.contains(block))
				return String.format("&cThe block &e%s&c is already in the list", block);

			exceptions.add(block);
			ModuleManager.xray.setExceptions(exceptions);
			return String.format("&aThe block &e%s&a has been added to the list", block);
		}
		case "remove": {
			if (!(exceptions.contains(block))) {
				return String.format("&cThe block &e%s&c is not in the list", block);
			}
			exceptions.remove(block);
			ModuleManager.xray.setExceptions(exceptions);
			return String.format("&aThe block &e%s&a has been removed from the list", block);
		}
		default: {
			return getSyntax("&c");
		}
		}

		 */
		return ".";
	}

}