package dev.windhook.command.commands;

import dev.windhook.command.Command;
import dev.windhook.gui.newgui.NewClickGui;
import dev.windhook.module.ModuleManager;
import dev.windhook.utils.Integers;
import dev.windhook.utils.RenderUtils;

public class BypassValueCommand extends Command {

	public BypassValueCommand() {
		super("bypassvalue", "bypassvalue", "Fixes random errors.", "fixme");
	}

	@Override
	public String executeCommand(String line, String[] args) {

		ModuleManager.clickGuiNew.newGui = new NewClickGui();
		ModuleManager.clickGuiNew.newGui.fr = RenderUtils.getFontRenderer().getFont(22);
		ModuleManager.clickGuiNew.newGui.small = RenderUtils.getFontRenderer().getFont(17);
		ModuleManager.clickGuiNew.mode.set("Old");
		
		return String.format("&aFixed!.");
		
	}

}