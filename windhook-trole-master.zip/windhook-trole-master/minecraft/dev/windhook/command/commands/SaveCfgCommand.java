package dev.windhook.command.commands;

import dev.windhook.command.Command;
import dev.windhook.config.ConfigManager;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

public class SaveCfgCommand extends Command {

	public SaveCfgCommand() {
		super("savecfg", "savecfg <config>", "Saves a config.", "cfgsave");
	}

	@Override
	public String executeCommand(String line, String[] args) {

		boolean exists = false;

		File myObj = Paths.get("WindHookConfigs",name+".json").toFile();
		try {
			exists = myObj.createNewFile();
		} catch (IOException ignored) {}

		ConfigManager.save(args[0]);
		
		return String.format("&aSaved "+args[0]+"! [Exists:"+exists+"]");
		
	}

}