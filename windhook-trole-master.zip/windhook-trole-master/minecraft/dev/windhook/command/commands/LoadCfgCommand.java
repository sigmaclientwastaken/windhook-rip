package dev.windhook.command.commands;

import dev.windhook.command.Command;
import dev.windhook.config.ConfigManager;
import dev.windhook.gui.newgui.NewClickGui;
import dev.windhook.module.ModuleManager;
import dev.windhook.utils.Integers;
import dev.windhook.utils.RenderUtils;

public class LoadCfgCommand extends Command {

	public LoadCfgCommand() {
		super("loadcfg", "loadcfg <config>", "Loads a config.", "cfgload");
	}

	@Override
	public String executeCommand(String line, String[] args) {
		if (args.length != 1)
			return getSyntax("&c");

		ConfigManager.load(args[0]);
		
		return String.format("&aLoaded "+args[0]+"!");
		
	}

}