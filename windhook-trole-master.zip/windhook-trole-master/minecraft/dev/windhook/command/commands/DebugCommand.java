package dev.windhook.command.commands;

import dev.windhook.command.Command;
import dev.windhook.gui.newgui.NewClickGui;
import dev.windhook.module.ModuleManager;
import dev.windhook.utils.RenderUtils;

public class DebugCommand extends Command {

	public DebugCommand() {
		super("debug", "debug", "Fixes random errors.");
	}

	@Override
	public String executeCommand(String line, String[] args) {
		return String.format("&aPlayerID: " + mc.session.getSessionID()
							+ " | ");
	}

}