package dev.windhook.command.commands;

import dev.windhook.BaseClient;
import dev.windhook.command.Command;
import dev.windhook.module.ModuleManager;
import dev.windhook.utils.Strings;

import java.util.ArrayList;
import java.util.List;

public class ReloadComand extends Command {

	public ReloadComand() {
		super("reload", "reload", "Reloads all of the modules.");
	}

	@Override
	public String executeCommand(String line, String[] args) {
		BaseClient.getInstance().getModuleManager().registerModules();
		return String.format("Reloaded!");
	}

}