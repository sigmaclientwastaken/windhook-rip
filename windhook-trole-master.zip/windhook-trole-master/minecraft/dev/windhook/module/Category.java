package dev.windhook.module;

import java.awt.Color;

public enum Category {
	CLIENT("Client", 0, Color.decode("#F39C12").getRGB(), 'e'),
	COMBAT("Combat", 1, Color.decode("#E74C3C").getRGB(), 'j'),
	MOVEMENT("Movement", 2, Color.decode("#2ECC71").getRGB(), 'b'),
	WORLD("World", 3, Color.decode("#3498DB").getRGB(), 'h'),
	PLAYER("Player", 4, Color.decode("#8E44AD").getRGB(), 'k'),
	EXPLOIT("Exploit", 5, Color.decode("#139CF2").getRGB(), 'd'),
	RENDER("Render", 6, Color.decode("#3700CE").getRGB(), 'g'),
	GHOST("Ghost", 7, Color.decode("#353535").getRGB(), 'f'),
	SEMI_HIDDEN("Semi_Hidden", 8, Color.decode("#8E44AD").getRGB(), 'k'),
	HIDDEN("Hidden", 9, Color.decode("#8E44AD").getRGB(), 'k');

	private String name;
	public int moduleIndex;
	public int posX, posY;
	public boolean expanded;
	public int offset;
	public int color;

	public int getColor() {
		return color;
	}

	public char getIcon() {
		return icon;
	}

	public char icon;

	public String getName() {
		return name;
	}

	Category(String name, int offset, int color, char icon) {
		this.name = name;
		this.offset = offset;
		this.color = color;
		this.icon = icon;
		posX = 20 + (100 * offset);
		posY = 85; //Should be 85.5
		expanded = true;
	}


}