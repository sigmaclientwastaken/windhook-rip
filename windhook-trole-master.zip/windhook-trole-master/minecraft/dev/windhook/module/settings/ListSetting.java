package dev.windhook.module.settings;

import java.util.List;

public class ListSetting extends Setting {

    public List<String> value;

    public List<String> getValue() {
        return value;
    }

    public void setValue(List<String> value) {
        this.value = value;
    }

    public ListSetting(String name, List<String> value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void format() {}

}
