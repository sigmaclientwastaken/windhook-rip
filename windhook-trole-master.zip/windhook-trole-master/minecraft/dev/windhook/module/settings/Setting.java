package dev.windhook.module.settings;

public class Setting {

    public String name;
    public String thingy;
    public boolean visible;

}
