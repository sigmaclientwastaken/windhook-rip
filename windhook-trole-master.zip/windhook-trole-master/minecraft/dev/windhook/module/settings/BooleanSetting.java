package dev.windhook.module.settings;

public class BooleanSetting extends Setting {

    public boolean enabled;

    public boolean isEnabled() {
        return enabled;
    }

    public String getName() {
        return name;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public BooleanSetting(String name, boolean enabled, boolean visible) {
        this.name = name;
        this.enabled = enabled;
        this.thingy = "CheckBox";
        this.visible = visible;
    }
    public BooleanSetting(String name, boolean enabled) {
        this.name = name;
        this.enabled = enabled;
        this.thingy = "CheckBox";
        this.visible = true;
    }

    public void toggle() {
        enabled = !enabled;
    }

}

