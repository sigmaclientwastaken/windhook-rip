package dev.windhook.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import dev.windhook.BaseClient;
import dev.windhook.event.events.HurtcamEvent;
import dev.windhook.module.modules.client.*;
import dev.windhook.module.modules.combat.*;
import dev.windhook.module.modules.exploit.*;
import dev.windhook.module.modules.ghost.LegitAura;
import dev.windhook.module.modules.ghost.Reach;
import dev.windhook.module.modules.movement.*;
import dev.windhook.module.modules.player.*;
import dev.windhook.module.modules.render.*;
import dev.windhook.module.modules.semi_hidden.AdvancedTabGui;
import dev.windhook.module.modules.semi_hidden.BlurBuffer;
import dev.windhook.module.modules.world.*;
import dev.windhook.event.EventListener;
import dev.windhook.event.events.KeyPressedEvent;
import dev.windhook.event.events.MouseClickEvent;
import dev.windhook.module.settings.Setting;


public class ModuleManager extends EventListener {

	/** If you are wondering "why not lambda", it's pretty easy: thread safety. */

	public static List<Module> modules;

	public static TabGui tabGui = new TabGui();
	public static dev.windhook.module.modules.client.ArrayList arrayList = new dev.windhook.module.modules.client.ArrayList();
	public static ClickGui clickGui = new ClickGui();
	public static ClickGuiNew clickGuiNew = new ClickGuiNew();
	public static XRay xray = new XRay();
	public static BlurBuffer blur = new BlurBuffer();
	public static Gamespeed gameSpeed = new Gamespeed();
	public static Sprint sprint = new Sprint();
	public static HudElements hudElement = new HudElements();
	public static PingSpoof pingSpoof = new PingSpoof();
	public static Fly fly = new Fly();
	public static Aura aura = new Aura();
	public static NewAura newAura = new NewAura();
	public static Animations anim = new Animations();
	public static Targets targets = new Targets();
	public static NoRotate noRotate = new NoRotate();
	public static HotbarOverlay hotbarOverlay = new HotbarOverlay();
	public static AntiPumpkin antiPumpkin = new AntiPumpkin();
	public static AntiOverlay antiOverlay = new AntiOverlay();
	public static Scaffold scaffold = new Scaffold();
	public static Speed speed = new Speed();
	public static TargetStrafe ts = new TargetStrafe();

	public static SetPosition SETPOS = new SetPosition();


	public ModuleManager() {
		this.modules = new ArrayList<Module>();
		BaseClient.instance.getEventManager().registerListener(this);

		registerModules();
	}

	public void registerModules() {
		modules.clear();

		/// CLIENT
		registerModule(targets);
		registerModule(arrayList);
	//	registerModule(new Replay());
		registerModule(hotbarOverlay);
		registerModule(clickGui);
		registerModule(tabGui);
		registerModule(clickGuiNew);
		registerModule(hudElement);
		registerModule(new StreamerMode());

		/// COMBAT
		registerModule(new Friends());
		registerModule(new Velocity());
		registerModule(aura);
		registerModule(new Criticals());
		registerModule(new TPAura());
		registerModule(new TPHit());
		registerModule(newAura);
		registerModule(new AutoGapple());
		registerModule(new AutoHeal());

		/// MOVEMENT
		registerModule(fly);
		registerModule(sprint);
		registerModule(new TestModule());
		registerModule(new Boost());
		registerModule(new GuiMove());
		registerModule(speed);
		registerModule(new Step());
		registerModule(new NoPush());
		registerModule(ts);
		registerModule(new NoSlow());
		registerModule(new WaterStrafe());
		registerModule(new HighJump());

		/// RENDER
		registerModule(xray);
		registerModule(new TargetHud());
		registerModule(anim);
		registerModule(new ChinaLamp());
		registerModule(antiPumpkin);
		registerModule(antiOverlay);
		registerModule(new ESP());
		registerModule(new NoHurtcam());

		/// PLAYER
		registerModule(new BadNet());
		registerModule(new Clutch());
		registerModule(new InvManager());
		registerModule(gameSpeed);
		registerModule(new AntiStuck());
		registerModule(new AutoArmor());
		registerModule(new ChestStealer());
		registerModule(new NoFall());
		registerModule(new Blink());

		/// WORLD
		registerModule(new NameProtect());
		registerModule(scaffold);
		registerModule(SETPOS);
		registerModule(new KillSults());
		registerModule(new Alerter());
		registerModule(new AutoPlay());

		/// SEMI_HIDDEN
		registerModule(new AdvancedTabGui());

		/// EXPLOIT
		registerModule(new Disabler());
		registerModule(pingSpoof);
		registerModule(noRotate);
		registerModule(new AntiVerus());
		registerModule(new Phase());
		registerModule(new Teleport());
		registerModule(new AntiVoid());
		registerModule(new GodMode());

		/// GHOST
//		registerModule(new LegitAura());
		registerModule(new Reach());
	}

	public void registerModule(Module module) {
		modules.add(module);
		//module.setToggled();
	}

	public Module getModule(Class<? extends Module> clasz) {
		for (int i = 0; i < modules.size(); i++) {
			if (modules.get(i).getClass().equals(clasz))
				return modules.get(i);
		}

		return null;
	}

	public Module getModule(String name) {
		for (Module module : modules) {
			if (module.getName().equalsIgnoreCase(name))
				return module;
		}

		return null;
	}

	public Setting getSetting(String name, Module module) {
		Setting[] set = new Setting[1];

		module.settings.forEach(s -> {
			if(Objects.equals(s.name, name)) {
				set[0] = s;
				return;
			}
		});

		return set[0];
	}

	public List<Module> getModules(int key) {
		List<Module> modules = new ArrayList<Module>();
		for (int i = 0; i < ModuleManager.modules.size(); i++) {
			if (ModuleManager.modules.get(i).getKey() == key)
				modules.add(ModuleManager.modules.get(i));
		}

		return modules;
	}

	public List<Module> getModules(Category category) {
		List<Module> modules = new ArrayList<Module>();
		for (int i = 0; i < ModuleManager.modules.size(); i++) {
			Module module = ModuleManager.modules.get(i);
			if (module.getCategory().equals(category))
				modules.add(module);
		}

		return modules;
	}

	public Module getModule(int key) {
		List<Module> modules = getModules(key);
		if (modules.size() == 0)
			return null;

		return modules.get(0);
	}

	public List<Module> getModules() {
		return modules;
	}

	public List<Module> getToggledModules() {
		List<Module> modules = new ArrayList<Module>();
		for (int i = 0; i < ModuleManager.modules.size(); i++) {
			Module module = ModuleManager.modules.get(i);
			if (module.isToggled())
				modules.add(module);
		}

		return modules;
	}

	public List<Module> getToggledModules2() {
		List<Module> modules = new ArrayList<Module>();
		for (int i = 0; i < ModuleManager.modules.size(); i++) {
			Module module = ModuleManager.modules.get(i);
			if (module.isToggled() && !(module.category == Category.HIDDEN || module.category == Category.SEMI_HIDDEN || !module.isShownInModuleArrayList()))
				modules.add(module);
		}

		return modules;
	}

	public List<Module> getToggledModules3() {
		List<Module> modules = new ArrayList<Module>();
		for (int i = 0; i < ModuleManager.modules.size(); i++) {
			Module module = ModuleManager.modules.get(i);


			if (module.nalFade != 0 && !(module.category == Category.HIDDEN || module.category == Category.SEMI_HIDDEN || !module.isShownInModuleArrayList()))
				modules.add(module);
		}

		return modules;
	}

	public void setupArray() {
		for(Module module : ModuleManager.modules) {
			if(module.isToggled()) {
				module.nalFade = 255;
			}
		}
	}

	/**
	 * @formatter:off
	 * The module's key will be equal to the button id passed (a list can be found in the MouseClickEvent class) BUT negative,
	 * MINUS 1 (since 0 is used for NONE, and we don't want modules to get activated when the mouse button 0 is pressed).
	 * So mouse button 0 is going to be -1, button 1 is -2 and so on
	 * @formatter:on
	 */
	@Override
	public void onMouseClick(MouseClickEvent event) {
		List<Module> modules = new ArrayList<Module>(getModules(-event.getButton() - 1));

		for (int i = 0; i < modules.size(); i++) {
			modules.get(i).toggle();
		}
	}

	@Override
	public void onKeyPressed(KeyPressedEvent event) {
		List<Module> modules = new ArrayList<Module>(getModules(event.getKey()));

		for (int i = 0; i < modules.size(); i++) {
			modules.get(i).toggle();
		}
	}

	public void toggleModules() {
		for (int i = 0; i < modules.size(); i++) {
			if (modules.get(i).isToggled())
				modules.get(i).setToggled(true);
		}
	}

	public void setModules(List<Module> modules) {
		ModuleManager.modules = modules;
	}
}