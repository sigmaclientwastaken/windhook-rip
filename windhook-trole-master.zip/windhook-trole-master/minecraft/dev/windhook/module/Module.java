package dev.windhook.module;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import dev.windhook.BaseClient;
import dev.windhook.event.EventListener;
import dev.windhook.module.settings.Setting;
import dev.windhook.utils.Strings;
import dev.windhook.utils.Timer;

public class Module extends EventListener {

	protected String name;
	protected String description;
	protected int key;
	protected Category category;
	public boolean expanded;

	public int nalFade = 0;

	public ArrayList<Setting> settings = new ArrayList<Setting>();

	public boolean flag;
	private boolean toggled;

	private boolean showInModuleArraylist;

	public Color color;

	protected Timer timer;

	protected ExecutorService singleExecutorService;
	protected ExecutorService executorService;

	public Module(String name, String description, int key, Category category) {
		initializeModule(name, description, key, category, (category.equals(Category.HIDDEN) ? false : true), false);
	}

	public Module(String name, String description, int key, Category category, boolean showInModuleArrayList) {
		initializeModule(name, description, key, category, showInModuleArrayList, false);
	}

	public Module(String name, String description, int key, Category category, boolean showInModuleArrayList,
			boolean toggled) {
		initializeModule(name, description, key, category, showInModuleArrayList, toggled);
	}

	private void initializeModule(String name, String description, int key, Category category,
			boolean showInModuleArrayList, boolean toggled) {
		this.name = name;
		this.description = description;
		this.key = key;
		this.category = category;
		this.toggled = toggled;
		this.flag = toggled;

		this.showInModuleArraylist = showInModuleArrayList;

		this.timer = new Timer(true);
		this.singleExecutorService = Executors.newFixedThreadPool(1);
		this.executorService = Executors.newCachedThreadPool();
		setup();
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	public Category getCategory() {
		return category;
	}

	public boolean isShownInModuleArrayList() {
		return showInModuleArraylist;
	}

	public boolean isToggled() {
		return toggled;
	}

	public Color getColor() {
		return color;
	}

	public String getNameWithAddon() {
		return name;
	}

	public String getAddon() { return null; }

	public void setup() {

	}

	public void onEnable() {

	}

	public void onDisable() {

	}

	public void addSettings(Setting... settingsList) {
		settings.addAll(Arrays.asList(settingsList));
	}

	public void toggle() {
		setToggled(!(toggled));
	}

	public Timer getTimer() {
		return timer;
	}

	public void setToggled(boolean toggled) {
		this.toggled = toggled;
		if (toggled) {
			BaseClient.instance.getEventManager().registerListener(this);
			nalFade = 1;
			onEnable();
		} else {
			BaseClient.instance.getEventManager().unregisterListener(this);
			onDisable();
		}
	}

	public void setToggledSilent(boolean toggled) {
		this.toggled = toggled;
		if (toggled) {
			BaseClient.instance.getEventManager().registerListener(this);
		} else {
			BaseClient.instance.getEventManager().unregisterListener(this);
		}
	}

	public ArrayList<Setting> getVisibleSettings() {
		ArrayList<Setting> settingst = new ArrayList<>();
		for(Setting set : settings) {
			if(set.visible) {
				settingst.add(set);
			}
		}
		return settingst;
	}

	public boolean isExpanded() {
		return expanded;
	}

	public void setExpanded(boolean expanded) {
		this.expanded = expanded;
	}

}