package dev.windhook.module.modules.combat;

import dev.windhook.event.events.UpdateEvent;
import dev.windhook.event.events.VelocityEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.module.settings.ModeSetting;
import org.lwjgl.input.Keyboard;

public class Velocity extends Module {

	ModeSetting mode = new ModeSetting("Mode", "Cancel", "Cancel", "TP", "Flag", "Jump", "Motion");

	float lastYaw, lastPitch;
	float flag1, flag2;

	public Velocity() {
		super("Velocity", "Reduces knockback taken!", Keyboard.KEY_NONE, Category.COMBAT, true);
		addSettings(mode);
	}

	@Override
	public void setup() {
		this.color = Color.COMBAT;
	}

	@Override
	public void onUpdate(UpdateEvent event) {
		lastPitch = flag2;
		lastYaw = flag1;
		flag2 = mc.thePlayer.rotationPitch;
		flag1 = mc.thePlayer.rotationYaw;
	}

	@Override
	public void onVelocity(VelocityEvent event) {
		if(mode.is("Cancel")) {
			event.setCancelled(true);
		}

		if(mode.is("Flag")) {
			event.setCancelled(true);
			mc.thePlayer.setPositionAndUpdate(mc.thePlayer.posX, mc.thePlayer.posY - 0.1, mc.thePlayer.posZ);
		}

		if(mode.is("Jump")) {
			mc.thePlayer.jump();
		}

		if(mode.is("Motion")) {
			mc.thePlayer.motionX = 0;
			mc.thePlayer.motionZ = 0;
		}

		if(mode.is("TP")) {
			mc.thePlayer.setPositionAndUpdate(mc.thePlayer.posX, mc.thePlayer.posY - 0.05, mc.thePlayer.posZ);
			mc.thePlayer.setPositionAndUpdate(mc.thePlayer.posX, mc.thePlayer.posY - 0.07, mc.thePlayer.posZ);
			mc.thePlayer.setPositionAndRotation(mc.thePlayer.posX, mc.thePlayer.posY - 0.09, mc.thePlayer.posZ, lastYaw, lastPitch);
		}
	}
}