package dev.windhook.module.modules.combat;

import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.PacketReceivedEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.utils.Timer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.S0CPacketSpawnPlayer;
import net.minecraft.util.MathHelper;

import java.util.ArrayList;
import java.util.List;

public class AntiBot extends Module {

    ModeSetting mode = new ModeSetting("Mode", "Hypixel", "Mineplex", "Matrix");
    BooleanSetting dead = new BooleanSetting("Remove Dead", false),
                remove = new BooleanSetting("Remove Bots", false);
    
    ArrayList<Entity>entities = new ArrayList<>();
    private final Timer timer = new Timer();
    Timer lastRemoved = new Timer();

    public AntiBot() {
        super("AntiBot", "t", 0, Category.COMBAT);
        addSettings(mode, dead, remove);
    }

    public static List<EntityPlayer> getInvalid() {
        return invalid;
    }

    private static final List<EntityPlayer> invalid = new ArrayList<>();
    private static final List<EntityPlayer> removed = new ArrayList<>();

    public void onEnable() {
        invalid.clear();
    }

    public void onDisable() {
        invalid.clear();
    }

    @Override
    public void onMotion(MotionEvent event) {
        String currentSetting = mode.getMode();
        boolean killer = remove.isEnabled();
        
        if (event.isPre()) {
            if (dead.isEnabled())
                for (Object o : mc.theWorld.loadedEntityList) {
                    if (o instanceof EntityPlayer) {
                        EntityPlayer ent = (EntityPlayer) o;
                        assert ent != mc.thePlayer;
                        if (ent.isPlayerSleeping()) {
                            mc.theWorld.removeEntity(ent);
                        }
                    }
                }
        }
        if(currentSetting.equalsIgnoreCase("Mineplex") && mc.thePlayer.ticksExisted > 40)
            for(Entity o : mc.theWorld.loadedEntityList){
                if(o instanceof EntityPlayer && !(o instanceof EntityPlayerSP)){
                    int ticks = o.ticksExisted;
                    double diffY = Math.abs(mc.thePlayer.posY - o.posY);
                    String name = o.getName();
                    String customname = o.getCustomNameTag();
                    if(customname == "" && !invalid.contains((EntityPlayer) o)){
                        invalid.add((EntityPlayer) o);
                    }
                }
            }
        if (event.isPre() && currentSetting.equalsIgnoreCase("hypixel")) {
            //Clears the invalid player list after a second to prevent false positives staying permanent.
            if(killer){
                if(!removed.isEmpty()){
                    if(lastRemoved.delay(1000)){
                        lastRemoved.reset();
                        removed.clear();
                    }
                }
            }
            if (!invalid.isEmpty() && timer.delay(1000)) {
                invalid.clear();
                timer.reset();
            }
            // Loop through entity list
            for (Object o : mc.theWorld.getLoadedEntityList()) {
                if (o instanceof EntityPlayer) {
                    EntityPlayer ent = (EntityPlayer) o;
                    //Make sure it's not the local player + they are in a worrying distance. Ignore them if they're already invalid.
                    if (ent != mc.thePlayer && !invalid.contains(ent)) {
                        //Handle current mode
                        if ("Hypixel".equals(currentSetting)) {
                            String formated = ent.getDisplayName().getFormattedText();
                            String custom = ent.getCustomNameTag();
                            String name = ent.getName();

                            if (ent.isInvisible() && !formated.startsWith("§c") && formated.endsWith("§r") && custom.equals(name)) {
                                double diffX = Math.abs(ent.posX - mc.thePlayer.posX);
                                double diffY = Math.abs(ent.posY - mc.thePlayer.posY);
                                double diffZ = Math.abs(ent.posZ - mc.thePlayer.posZ);
                                double diffH = Math.sqrt(diffX * diffX + diffZ * diffZ);
                                if (diffY < 13 && diffY > 10 && diffH < 3) {
                                    List<EntityPlayer> list = getTabPlayerList();
                                    if (!list.contains(ent)) {
                                        if (killer) {
                                            lastRemoved.reset();
                                            removed.add(ent);
                                            mc.theWorld.removeEntity(ent);
                                        }
                                        invalid.add(ent);
                                    }

                                }

                            }
                            //SHOP BEDWARS
                            if (!formated.startsWith("§") && formated.endsWith("§r")) {
                                invalid.add(ent);
                            }
                            if (ent.isInvisible()) {
                                //BOT INVISIBLES IN GAME
                                if (!custom.equalsIgnoreCase("") && custom.toLowerCase().contains("§c§c") && name.contains("§c")) {
                                    if (killer) {
                                        lastRemoved.reset();
                                        removed.add(ent);
                                        mc.theWorld.removeEntity(ent);
                                    }
                                    invalid.add(ent);
                                }
                            }
                            //WATCHDOG BOT
                            if (!custom.equalsIgnoreCase("") && custom.toLowerCase().contains("§c") && custom.toLowerCase().contains("§r")) {
                                if (killer) {
                                    lastRemoved.reset();
                                    removed.add(ent);
                                    mc.theWorld.removeEntity(ent);
                                }
                                invalid.add(ent);
                            }

                            //BOT LOBBY
                            if (formated.contains("§8[NPC]")) {
                                invalid.add(ent);
                            }
                            if (!formated.contains("§c") && !custom.equalsIgnoreCase("")) {

                                invalid.add(ent);
                            }
                        }
                    }
                }
            }
        }
    }

    public List<EntityPlayer> getTabPlayerList() {
        final NetHandlerPlayClient var4 = mc.thePlayer.sendQueue;
        final List<EntityPlayer> list = new ArrayList<>();
        final List<NetworkPlayerInfo> players = GuiPlayerTabOverlay.field_175252_a.sortedCopy(var4.getPlayerInfoMap());
        for (final NetworkPlayerInfo o : players) {
            if (o == null) {
                continue;
            }
            list.add(mc.theWorld.getPlayerEntityByName(o.getGameProfile().getName()));
        }
        return list;
    }

}
