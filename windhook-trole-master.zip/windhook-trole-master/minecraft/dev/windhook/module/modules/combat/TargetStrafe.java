package dev.windhook.module.modules.combat;

import dev.windhook.BaseClient;
import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.MoveEvent;
import dev.windhook.event.events.Render3DEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.modules.movement.Speed;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.utils.ts.EntityValidator;
import dev.windhook.utils.ts.impl.VoidCheck;
import dev.windhook.utils.ts.impl.WallCheck;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;

public class TargetStrafe extends Module {

    NumberSetting radius = new NumberSetting("Radius", 5.5, 1, 11, 0.1);
    public BooleanSetting space = new BooleanSetting("Space Only", false);
    BooleanSetting render = new BooleanSetting("Render", true);

    public TargetStrafe() {
        super("TargetStrafe", "Strafes around targets!", Keyboard.KEY_NONE, Category.COMBAT);
        addSettings(radius, space);
        this.targetValidator = new EntityValidator();
        this.targetValidator.add(new VoidCheck());
        this.targetValidator.add(new WallCheck());
    }

    private final EntityValidator targetValidator;
    private int direction = -1;

    @Override
    public void onMotion(MotionEvent event) {
        if (event.getEventType() == MotionEvent.Type.PRE) {
            if (mc.thePlayer.isCollidedHorizontally) {
                this.switchDirection();
            }

            if (mc.gameSettings.keyBindLeft.isPressed()) {
                this.direction = 1;
            }

            if (mc.gameSettings.keyBindRight.isPressed()) {
                this.direction = -1;
            }
        }

    }

    @Override
    public void onMove(MoveEvent event) {
        if(canStrafe()) {
            strafe(event, (Speed.instance.isToggled()? Math.max(Speed.instance.moveSpeed, Speed.instance.getBaseMoveSpeed()) : Speed.instance.getBaseMoveSpeed()));
        }
    }

    private void switchDirection() {
        if (this.direction == 1) {
            this.direction = -1;
        } else {
            this.direction = 1;
        }

    }

    public void strafe(MoveEvent event, double moveSpeed) {
        EntityLivingBase target = ModuleManager.newAura.kTarget;
        float[] rotations = getRotationsEntity(target);
        if ((double)mc.thePlayer.getDistanceToEntity(target) <= (Double)this.radius.getValue()) {
            setSpeed(event, moveSpeed, rotations[0], (double)this.direction, 0.0D);
        } else {
            setSpeed(event, moveSpeed, rotations[0], (double)this.direction, 1.0D);
        }

    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (this.canStrafe() && render.isEnabled()) {
            this.drawCircle(ModuleManager.newAura.kTarget, event.getPartialTicks(), (Double)this.radius.getValue());
        }

    }

    private void drawCircle(Entity entity, float partialTicks, double rad) {
        GL11.glPushMatrix();
        GL11.glDisable(3553);
        GL11.glEnable(2848);
        GL11.glEnable(2881);
        GL11.glEnable(2832);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glHint(3154, 4354);
        GL11.glHint(3155, 4354);
        GL11.glHint(3153, 4354);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1.0F);
        GL11.glBegin(3);
        double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)partialTicks - mc.getRenderManager().viewerPosX;
        double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)partialTicks - mc.getRenderManager().viewerPosY;
        double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)partialTicks - mc.getRenderManager().viewerPosZ;
        float r = 0.003921569F * (float)Color.WHITE.getRed();
        float g = 0.003921569F * (float)Color.WHITE.getGreen();
        float b = 0.003921569F * (float)Color.WHITE.getBlue();
        double pix2 = 6.283185307179586D;

        for(int i = 0; i <= 90; ++i) {
            GL11.glColor3f(r, g, b);
            GL11.glVertex3d(x + rad * Math.cos((double)i * 6.283185307179586D / 45.0D), y, z + rad * Math.sin((double)i * 6.283185307179586D / 45.0D));
        }

        GL11.glEnd();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glDisable(2848);
        GL11.glDisable(2881);
        GL11.glEnable(2832);
        GL11.glEnable(3553);
        GL11.glPopMatrix();
    }

    public boolean canStrafe() {
        return ModuleManager.newAura.isToggled() && ModuleManager.newAura.kTarget != null && isToggled() && this.targetValidator.validate(ModuleManager.newAura.kTarget) && (!space.isEnabled() || mc.gameSettings.keyBindJump.isKeyDown());
    }

    public void setSpeed(MoveEvent moveEvent, double moveSpeed) {
        setSpeed(moveEvent, moveSpeed, mc.thePlayer.rotationYaw, (double)mc.thePlayer.movementInput.moveStrafe, (double)mc.thePlayer.movementInput.moveForward);
    }

    public void setSpeed(MoveEvent moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (pseudoForward != 0.0D) {
            if (pseudoStrafe > 0.0D) {
                yaw = pseudoYaw + (float)(pseudoForward > 0.0D ? -45 : 45);
            } else if (pseudoStrafe < 0.0D) {
                yaw = pseudoYaw + (float)(pseudoForward > 0.0D ? 45 : -45);
            }

            strafe = 0.0D;
            if (pseudoForward > 0.0D) {
                forward = 1.0D;
            } else if (pseudoForward < 0.0D) {
                forward = -1.0D;
            }
        }

        if (strafe > 0.0D) {
            strafe = 1.0D;
        } else if (strafe < 0.0D) {
            strafe = -1.0D;
        }

        double mx = Math.cos(Math.toRadians((double)(yaw + 90.0F)));
        double mz = Math.sin(Math.toRadians((double)(yaw + 90.0F)));
        moveEvent.x = forward * moveSpeed * mx + strafe * moveSpeed * mz;
        moveEvent.z = forward * moveSpeed * mz - strafe * moveSpeed * mx;
    }

    public float[] getRotations(double posX, double posY, double posZ) {
        EntityPlayerSP player = mc.thePlayer;
        double x = posX - player.posX;
        double y = posY - (player.posY + (double)player.getEyeHeight());
        double z = posZ - player.posZ;
        double dist = (double) MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0D / 3.141592653589793D) - 90.0F;
        float pitch = (float)(-(Math.atan2(y, dist) * 180.0D / 3.141592653589793D));
        return new float[]{yaw, pitch};
    }

    public float[] getRotationsEntity(EntityLivingBase entity) {
        return isOnHypixel() && mc.thePlayer.isMoving() ? getRotations(entity.posX + randomNumber(0.03D, -0.03D), entity.posY + (double)entity.getEyeHeight() - 0.4D + randomNumber(0.07D, -0.07D), entity.posZ + randomNumber(0.03D, -0.03D)) : getRotations(entity.posX, entity.posY + (double)entity.getEyeHeight() - 0.4D, entity.posZ);
    }

    public boolean isOnHypixel() {
        return !mc.isSingleplayer() && mc.getCurrentServerData().serverIP.contains("hypixel");
    }

    public static double randomNumber(double max, double min) {
        return Math.random() * (max - min) + min;
    }

}
