package dev.windhook.module.modules.combat;

import dev.windhook.BaseClient;
import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.PacketReceivedEvent;
import dev.windhook.event.events.Render3DEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.utils.Colors;
import dev.windhook.utils.Timer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.network.INetHandler;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S29PacketSoundEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class NewAura extends Module {

	BooleanSetting raytrace = new BooleanSetting("Ray Trace", false);
	BooleanSetting antibot =  new BooleanSetting("AntiBot", false);
	BooleanSetting soundCheck =  new BooleanSetting("Sound Check", false);
	BooleanSetting autoblock =  new BooleanSetting("Autoblock", false);
	BooleanSetting legitRange =  new BooleanSetting("Legit Range", false);
	BooleanSetting newHit =  new BooleanSetting("1.9+ Hits", false);
	BooleanSetting targetEsp =  new BooleanSetting("Target ESP", false);

	NumberSetting rangeSet =  new NumberSetting("Range", 4, 1, 10, 0.1);
	NumberSetting preAimRangeSet =  new NumberSetting("Pre Aim Range", 2, 0, 5, 0.1);
	NumberSetting maxaps =  new NumberSetting("Max APS", 10, 0, 20, 1);
	NumberSetting minaps =  new NumberSetting("Min APs", 2, 0, 20, 1);

	ModeSetting autoblockMode =  new ModeSetting("Autoblock Mode", "Intave", "Intave", "SmartIntave", "NCP", "Hypixel", "Other");
	ModeSetting mode =  new ModeSetting("Mode", "Single", "Single", "Nearest", "Multi", "Switch");
	ModeSetting rotations =  new ModeSetting("Rotations", "Intave", "Intave", "Smooth", "Instant", "AAC");


	public NewAura() {
		super("NewAura", "This mod enables friends. When you hit a friend, the event will be cancelled", Keyboard.KEY_NONE, Category.COMBAT);
		addSettings(mode, autoblockMode, rotations, rangeSet, preAimRangeSet, maxaps, minaps, raytrace, antibot, soundCheck, autoblock, legitRange, newHit, targetEsp);
	}

	public EntityLivingBase kTarget;
	public double range;
	public double preAimRange;
	public double cracks;
	float yaw;
	float pitch;
	private float lastYaw;
	private float lastPitch;
	double minCPS;
	double maxCPS;
	public float yaww;
	public float pitchh;
	public float[] facing;
	private final CopyOnWriteArrayList<Entity> copyEntities = new CopyOnWriteArrayList<>();
	private final ArrayList<Entity> madeSound = new ArrayList<>();
	Timer time = new Timer();
	Timer timeAB = new Timer();
	Random random = new Random();
	public ArrayList<Entity> bots = new ArrayList<>();

	public void onEnable() {
		mc.gameSettings.keyBindUseItem.pressed = false;
	}

	public void onDisable() {
		bots.clear();
		mc.gameSettings.keyBindSprint.pressed = false;
	}

	@Override
	public void onPacketReceived(PacketReceivedEvent event) {
		if (soundCheck.isEnabled()) {
			final Packet<? extends INetHandler> packet = event.getPacket();
			if (packet instanceof S29PacketSoundEffect) {
				final S29PacketSoundEffect soundEffect = (S29PacketSoundEffect) packet;
				copyEntities.addAll(mc.theWorld.loadedEntityList);
				copyEntities.forEach(entity -> {
					if (entity != mc.thePlayer && entity.getDistance(soundEffect.getX(), soundEffect.getY(),
							soundEffect.getZ()) <= 0.8)
						madeSound.add(entity);

				});
				copyEntities.clear();
			}
		}
	}

	@Override
	public void onMotion(MotionEvent event) {
		if(event.getEventType() == MotionEvent.Type.PRE) {

			if (kTarget != null) {

				this.facing = getEntityRotations(mc.thePlayer, kTarget);
				event.setYaw(yaww);
				event.setPitch(pitchh);
				yaww = interpolateRotation(yaww, facing[0], 180);
				pitchh = interpolateRotation(pitchh, facing[1], 180);
			}

			if (antibot.isEnabled()) {

				for (final Object entity : mc.theWorld.getLoadedEntityList())
					if (entity instanceof EntityPlayer)
						if ((isBot((EntityPlayer) entity) || ((EntityPlayer) entity).isInvisible())
								&& entity != mc.thePlayer) {
							bots.add((EntityPlayer) entity);
							mc.theWorld.removeEntity((Entity) entity);

						}
			}
			if (autoblock.isEnabled()) {
				if (autoblock.isEnabled()) {
					if(!mc.thePlayer.isSwingInProgress) {
						if (mc.thePlayer.getHeldItem() != null)
							if (mc.thePlayer.getHeldItem().getItem() instanceof net.minecraft.item.ItemSword) {
								if(!hasTarget()) {
									mc.gameSettings.keyBindUseItem.pressed = false;
								}
							}
					}
				}
			}

			if (mode != null || kTarget == null) {
				kTarget = (EntityLivingBase) modes();
			}

			range = rangeSet.value;
			preAimRange = preAimRangeSet.value;
			maxCPS = maxaps.value;
			minCPS = minaps.value;

			int CPS = randomNumber((int) maxCPS, (int) minCPS);
			if (kTarget != null && kTarget != mc.thePlayer
					&& mc.thePlayer.getDistanceToEntity(kTarget) < range + preAimRange
					&& ((EntityPlayer) kTarget).getHealth() != 0) {

				if (bots.contains(kTarget) || BaseClient.instance.getFriendsManager().isFriend(kTarget.getName())
						|| kTarget.getName().equalsIgnoreCase("§6Shop"))
					return;

				event.setPitch(Rotations.pitch);
				event.setYaw(Rotations.yaw);
				RotationModes(kTarget);

				if (legitRange.isEnabled()) {
					if (mc.thePlayer != null && mc.thePlayer.getDistanceToEntity(kTarget) <= range && kTarget != null
							&& mc.objectMouseOver != null && mc.objectMouseOver.entityHit != null) {
						if (madeSound.contains(kTarget) || bots.contains(kTarget)
								|| BaseClient.instance.getFriendsManager().isFriend(kTarget.getName())
								|| kTarget.getName().equalsIgnoreCase("§6Shop"))
							return;

						if (newHit.isEnabled()) {
							if (mc.thePlayer.ticksExisted % 12 == 0) {
								mc.clickMouse();
								time.reset();
							}
						} else {

							if (time.hasReached(1000 / CPS)) {
								time.reset();


								mc.clickMouse();
								time.reset();
							}
						}
					}
					AutoBlock();
				} else {

					if (newHit.isEnabled()) {
						if (mc.thePlayer.ticksExisted % 12 == 0) {
							if (mc.thePlayer.getDistanceToEntity(kTarget) <= range && kTarget != null) {
								if (madeSound.contains(kTarget) || bots.contains(kTarget)
										|| BaseClient.instance.getFriendsManager().isFriend(kTarget.getName())
										|| kTarget.getName().equalsIgnoreCase("§6Shop"))
									return;
								AutoBlock();

								if (time.hasReached(1000 / CPS)) {
									time.reset();


									mc.playerController.attackEntity(mc.thePlayer, kTarget);
									mc.thePlayer.swingItem();
									time.reset();
								}

							}
						}
					} else {
						if (mc.thePlayer.getDistanceToEntity(kTarget) <= range && kTarget != null) {
							if (bots.contains(kTarget) || BaseClient.instance.getFriendsManager().isFriend(kTarget.getName())
									|| kTarget.getName().equalsIgnoreCase("§6Shop"))
								return;
							AutoBlock();

							if (time.hasReached(1000 / CPS)) {
								time.reset();

								mc.thePlayer.swingItem();
								mc.playerController.attackEntity(mc.thePlayer, kTarget);

								time.reset();
							}
						}
					}

				}
			} else {
				kTarget = null;
			}

		}
	}

	@Override
	public void onRender3D(Render3DEvent event) {
		if (targetEsp.isEnabled()) {
			drawTargetESP((EntityPlayer) kTarget, mc.timer.renderPartialTicks);
		}
	}

	public void mouseFix() {
		float f = this.mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
		float f2 = f * f * f * 1.2F;
		Rotations.yaw -= Rotations.yaw % f2;
		Rotations.pitch -= Rotations.pitch % (f2 * f);

	}

	public Entity modes() {
		EntityPlayer target = null;
		switch (mode.getMode()) {
			case "Switch":
				for (Object o : mc.theWorld.loadedEntityList) {
					Entity e = (Entity) o;

					if (!e.getName().equals(mc.thePlayer.getName()) && e instanceof EntityPlayer
							&& !(e instanceof EntityArmorStand)) {
						EntityPlayer player = (EntityPlayer) e;
						if (target == null || player.hurtTime < target.hurtTime) {
							if(mc.thePlayer.getDistanceToEntity(e) <  range + preAimRange) {
								target = (EntityPlayer) player;
							}
						} else if (player.hurtTime == target.hurtTime) {
							if (mc.thePlayer.getDistanceToEntity(player) < mc.thePlayer.getDistanceToEntity(target)) {
								if(mc.thePlayer.getDistanceToEntity(e) <  range +preAimRange) {
									target = (EntityPlayer) player;
								}


							}
						}
					}
				}
				return target;

			case "Single":
				for (Object o : mc.theWorld.loadedEntityList) {
					Entity e = (Entity) o;

					if (!e.getName().equals(mc.thePlayer.getName()) && e instanceof EntityPlayer
							&& !(e instanceof EntityArmorStand)) {
						if (target == null || mc.thePlayer
								.getDistanceToEntity(e) <= mc.thePlayer.getDistanceToEntity(target) + preAimRange) {
							if(mc.thePlayer.getDistanceToEntity(e) <  range+ preAimRange) {
								target = (EntityPlayer) e;
							}

						}
					}
				}
				return target;

			case "Multy":

				for (Object o : mc.theWorld.loadedEntityList) {
					Entity e = (Entity) o;
					if (!e.getName().equals(mc.thePlayer.getName()) && e instanceof EntityPlayer
							&& !(e instanceof EntityArmorStand)) {
						if (target == null) {

							if(mc.thePlayer.getDistanceToEntity(e) <  range+ preAimRange) {
								target = (EntityPlayer) e;
							}
						}
					}
				}

			case "Nearest":

				for (Object o : mc.theWorld.loadedEntityList) {
					Entity e = (Entity) o;
					if (!e.getName().equals(mc.thePlayer.getName()) && e instanceof EntityPlayer
							&& !(e instanceof EntityArmorStand)) {

						if (target == null
								|| mc.thePlayer.getDistanceToEntity(e) < mc.thePlayer.getDistanceToEntity(target)) {
							if(mc.thePlayer.getDistanceToEntity(e) <  range + preAimRange) {
								target = (EntityPlayer) e;
							}

						}
					}
				}
		}
		return target;

	}
	public int randomNumber(int max, int min) {
		return Math.round(min + (float) Math.random() * (max - min));
	}

	public void RotationModes(Entity target) {
		if (target == null) {
			return;
		}
		Vec3 randomCenter = Rotations.getRandomCenter(target.getEntityBoundingBox());
		Vec3 Center = Rotations.getCenter(target.getEntityBoundingBox());
		Vec3 Center2 = Rotations.getCenter2(target.getEntityBoundingBox());

		float yaw1 = Rotations.getYawToPoint(Center);

		float pitch1 = Rotations.getPitchToPoint(Center);
		float pitch3 = Rotations.getPitchToPoint(Center2);

		float yaw2 = Rotations.getYawToPoint(randomCenter);
		float pitch2 = Rotations.getPitchToPoint(randomCenter);

		switch (rotations.getMode()) {

			case "Instant":

				Rotations.setRotation(yaw1, pitch3);

				break;
			case "Smooth":

				Rotations.setYaw(yaw1, randomNumber(33, 14));
				Rotations.setPitch(pitch1, randomNumber(20, 8));

				break;
			case "AAC":
				try {
					if (mc.objectMouseOver.entityHit != null) {
						Rotations.setYaw(yaw1, 0);
						Rotations.setPitch(pitch1, 0);
						if (bots.contains(kTarget) || BaseClient.instance.getFriendsManager().isFriend(kTarget.getName())
								|| kTarget.getName().equalsIgnoreCase("§6Shop"))
							return;
					}

					if (mc.objectMouseOver.entityHit == null) {
						Rotations.setYaw(yaw2, 90F);
						Rotations.setPitch(pitch2, 180F);
						if (bots.contains(kTarget) || BaseClient.instance.getFriendsManager().isFriend(kTarget.getName())
								|| kTarget.getName().equalsIgnoreCase("§6Shop"))
							return;
					}
				} catch (NullPointerException e) {

				}

				break;
			case "Intave":
				float[] rota = Rotations.getNewKillAuraRots(mc.thePlayer, (EntityLivingBase) target, lastYaw, lastPitch);
				lastYaw = rota[0];
				lastPitch = rota[1];
				try {
					if (mc.objectMouseOver.entityHit != null) {
						if (bots.contains(kTarget) || BaseClient.instance.getFriendsManager().isFriend(kTarget.getName())
								|| kTarget.getName().equalsIgnoreCase("§6Shop"))
							return;

						Rotations.setYaw(rota[0], 180F);
						Rotations.setPitch(rota[1], 180F);

					}
				} catch (NullPointerException e) {

				}
				try {
					if (mc.objectMouseOver.entityHit == null) {
						Rotations.setYaw(rota[0], 180F);
						Rotations.setPitch(rota[1], 180F);
					}
				} catch (NullPointerException e) {

				}
				break;

		}
	}

	public boolean hasTarget() {
		return kTarget != null;
	}

	public void AutoBlock() {
		if (autoblock.isEnabled()) {

			if (mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) {
				switch (autoblockMode.getMode()) {

					case "Intave":

						if (mc.thePlayer.isSwingInProgress) {
							if (mc.thePlayer.getHeldItem() != null)
								if (mc.thePlayer.getHeldItem().getItem() instanceof net.minecraft.item.ItemSword) {
									mc.gameSettings.keyBindUseItem.pressed = true;
									// Speed.setSpeed(0.2875);
								}
						}

					case "SmartIntave":

						if (mc.thePlayer.isSwingInProgress && mc.thePlayer.hurtTime != 0) {
							if (mc.thePlayer.getHeldItem() != null)
								if (mc.thePlayer.getHeldItem().getItem() instanceof net.minecraft.item.ItemSword) {
									mc.gameSettings.keyBindUseItem.pressed = true;
									// Speed.setSpeed(0.2875);
								}
						}
						break;
					case "NCP":
						if (mc.thePlayer.getHeldItem() != null)
							if (mc.thePlayer.getHeldItem().getItem() instanceof net.minecraft.item.ItemSword) {

								mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld,
										mc.thePlayer.getHeldItem());
							}
//						}
						break;
					case "Hypixel":
//						if(mc.thePlayer.ticksExisted % 3 == 0) {
						if (mc.thePlayer.getHeldItem() != null)
							if (mc.thePlayer.getHeldItem().getItem() instanceof net.minecraft.item.ItemSword) {
								mc.thePlayer.setItemInUse(mc.thePlayer.getHeldItem(), 100);
//								mc.playerController.sendUseItem((EntityPlayer) mc.thePlayer, (World) mc.theWorld,
//										mc.thePlayer.getHeldItem());
							}
//						}
						//mc.gameSettings.keyBindUseItem.pressed = false;

						break;
					case "Other":
						if (timeAB.hasReached(randomNumber(63, 56))) {
							mc.gameSettings.keyBindUseItem.pressed = true;
							mc.gameSettings.keyBindSprint.pressed = false;
							mc.thePlayer.setItemInUse(mc.thePlayer.getHeldItem(),
									mc.thePlayer.getHeldItem().getMaxItemUseDuration());
							mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
							mc.gameSettings.keyBindSprint.pressed = false;
							timeAB.reset();
						}

						mc.gameSettings.keyBindUseItem.pressed = false;
						break;

				}

			}
		}
	}

	public boolean smartblock(Entity entity) {

		float yaw = entity.rotationYaw;
		while (yaw > 360.0F) {
			yaw -= 360.0F;
		}
		while (yaw < 0.0F) {
			yaw += 360.0F;
		}
		while (yaw > 360.0F) {
			yaw -= 360.0F;
		}
		while (yaw < 0.0F) {
			yaw += 360.0F;
		}

		if (Math.abs(yaw - mc.thePlayer.rotationYawHead) >= 130.0F
				&& Math.abs(yaw - mc.thePlayer.rotationYawHead) <= 280.0F) {
			return true;
		}
		return false;
	}

	float lostHealthPercentage = 0;
	float lastHealthPercentage = 0;

	public void drawFace(int x, int y, float u, float v, int uWidth, int vHeight, int width, int height,
						 float tileWidth, float tileHeight, AbstractClientPlayer e) {
		mc.getTextureManager().bindTexture(e.getLocationSkin());
		GL11.glEnable(GL11.GL_BLEND);
		Gui.drawScaledCustomSizeModalRect(x, y, u, v, uWidth, vHeight, width, height, tileWidth, tileHeight);
		GL11.glDisable(GL11.GL_BLEND);
	}

	public int Color(int health) {
		if (health == 20) {
			return 0xFF2FEA29;
		} else if (health == 19) {
			return 0xFF40EA29;
		} else if (health == 18) {
			return 0xFF72EA29;
		} else if (health == 17) {
			return 0xFF8AEA29;
		} else if (health == 16) {
			return 0xFFA1EA29;
		} else if (health == 15) {
			return 0xFFB8EA29;
		} else if (health == 14) {
			return 0xFFC7EA29;
		} else if (health == 13) {
			return 0xFFD3EA29;
		} else if (health == 12) {
			return 0xFFE4EA29;
		} else if (health == 11) {
			return 0xFFE4EA29;
		} else if (health == 10) {
			return 0xFFEAE729;
		} else if (health == 9) {
			return 0xFFEAD629;
		} else if (health == 8) {
			return 0xFFEAC129;
		} else if (health == 7) {
			return 0xFFEAB829;
		} else if (health == 6) {
			return 0xFFEAA729;
		} else if (health == 5) {
			return 0xFFEA8F29;
		} else if (health == 4) {
			return 0xFFEA7B29;
		} else if (health == 3) {
			return 0xFFEA6629;
		} else if (health == 2) {
			return 0xFFEA5E29;
		} else if (health == 1) {
			return 0xFFEA4029;
		} else if (health < 1) {
			return 0xFFFC0303;
		}
		return 0xFF000000;
	}

	private double getProtection(EntityLivingBase target) {
		double protection = 0;

		for (int i = 0; i <= 3; i++) {
			ItemStack stack = target.getCurrentArmor(i);

			if (stack != null) {
				if (stack.getItem() instanceof ItemArmor) {
					ItemArmor armor = (ItemArmor) stack.getItem();
					protection += armor.damageReduceAmount;
				}

				protection += EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, stack) * 0.25;
			}
		}

		return protection;
	}

	private double getWeaponStrength(ItemStack stack) {
		double damage = 0;

		if (stack != null) {
			if (stack.getItem() instanceof ItemSword) {
				ItemSword sword = (ItemSword) stack.getItem();
				damage += sword.getDamageVsEntity();
			}

			if (stack.getItem() instanceof ItemTool) {
				ItemTool tool = (ItemTool) stack.getItem();
				damage += tool.getToolMaterial().getDamageVsEntity();
			}

			damage += EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, stack) * 1.25;
		}

		return damage;
	}

	public void drawRect(double left, double top, double right, double bottom, int color) {
		if (left < right) {
			double i = left;
			left = right;
			right = i;
		}

		if (top < bottom) {
			double j = top;
			top = bottom;
			bottom = j;
		}

		float f3 = (float) (color >> 24 & 255) / 255.0F;
		float f = (float) (color >> 16 & 255) / 255.0F;
		float f1 = (float) (color >> 8 & 255) / 255.0F;
		float f2 = (float) (color & 255) / 255.0F;
		Tessellator tessellator = Tessellator.getInstance();
		WorldRenderer worldrenderer = tessellator.getWorldRenderer();
		GlStateManager.enableBlend();
		GlStateManager.disableTexture2D();
		GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
		GlStateManager.color(f, f1, f2, f3);
		worldrenderer.begin(7, DefaultVertexFormats.POSITION);
		worldrenderer.pos(left, bottom, 0.0D).endVertex();
		worldrenderer.pos(right, bottom, 0.0D).endVertex();
		worldrenderer.pos(right, top, 0.0D).endVertex();
		worldrenderer.pos(left, top, 0.0D).endVertex();
		tessellator.draw();
		GlStateManager.enableTexture2D();
		GlStateManager.disableBlend();
	}

	public int getColor(int red, int green, int blue, int opacity) {
		int color = MathHelper.clamp_int(opacity, 0, 255) << 24;
		color |= MathHelper.clamp_int(red, 0, 255) << 16;
		color |= MathHelper.clamp_int(green, 0, 255) << 8;
		color |= MathHelper.clamp_int(blue, 0, 255);
		return color;
	}

	private void renderPlayer(int posX, int posY, int scale, EntityLivingBase player) {
		GlStateManager.enableColorMaterial();
		GlStateManager.pushMatrix();
		GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		GlStateManager.translate((float) posX, (float) posY, 50.0F);
		GlStateManager.scale((float) (-scale), (float) scale, (float) scale);
		GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
		RenderHelper.enableStandardItemLighting();
		player.rotationYawHead = player.rotationYaw;
		player.prevRotationYawHead = player.rotationYaw;
		GlStateManager.translate(0.0F, 0.0F, 0.0F);
		RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
		rendermanager.setPlayerViewY(180.0F);
		rendermanager.setRenderShadow(false);
		rendermanager.renderEntityWithPosYaw(player, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
		rendermanager.setRenderShadow(true);
		player.renderYawOffset = player.rotationYaw;
		player.prevRotationYawHead = player.rotationYaw;
		player.rotationYawHead = player.rotationYaw;
		GlStateManager.popMatrix();
		RenderHelper.disableStandardItemLighting();
		GlStateManager.disableRescaleNormal();
		GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
		GlStateManager.disableTexture2D();
		GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
	}

	public void fillRect(final double x, final double y, final double width, final double height,
						 final java.awt.Color color) {

		GL11.glColor4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F,
				color.getAlpha() / 255.0F);

		GL11.glBegin(GL11.GL_QUADS);

		GL11.glVertex2d(x, y + height);
		GL11.glVertex2d(x + width, y + height);
		GL11.glVertex2d(x + width, y);
		GL11.glVertex2d(x, y);

	}


	boolean isBot(EntityPlayer player) {
		if (!isInTablist(player))
			return true;
		if (!madeSound.contains(player) && soundCheck.isEnabled())
			return true;
		return invalidName(player);
	}

	boolean isInTablist(EntityPlayer player) {
		if (Minecraft.getMinecraft().isSingleplayer())
			return false;
		for (final NetworkPlayerInfo playerInfo : Minecraft.getMinecraft().getNetHandler().getPlayerInfoMap())
			if (playerInfo.getGameProfile().getName().equalsIgnoreCase(player.getName()))
				return true;
		return false;
	}

	boolean invalidName(Entity e) {
		if (e.getName().contains("-"))
			return true;
		if (e.getName().contains("/"))
			return true;
		if (e.getName().contains("|"))
			return true;
		if (e.getName().contains("<"))
			return true;
		if (e.getName().contains(">"))
			return true;
		return false;
	}

	public void drawRect(float g, float h, float i, float j, java.awt.Color col2) {
		GL11.glColor4f(col2.getRed() / 255.0F, col2.getGreen() / 255.0F, col2.getBlue() / 255.0F,
				col2.getAlpha() / 255.0F);

		GL11.glEnable(3042);
		GL11.glDisable(3553);
		GL11.glBlendFunc(770, 771);
		GL11.glEnable(2848);

		GL11.glPushMatrix();
		GL11.glBegin(7);
		GL11.glVertex2d(i, h);
		GL11.glVertex2d(g, h);
		GL11.glVertex2d(g, j);
		GL11.glVertex2d(i, j);
		GL11.glEnd();
		GL11.glPopMatrix();

		GL11.glEnable(3553);
		GL11.glDisable(3042);
		GL11.glDisable(2848);
	}

	public float interpolateRotation(float par1, float par2, float par3) {
		float f = MathHelper.wrapAngleTo180_float(par2 - par1);
		if (f > par3)
			f = par3;
		if (f < -par3)
			f = -par3;
		return par1 + f;
	}

	public float[] getEntityRotations(EntityPlayerSP player, EntityLivingBase target) {
		final double posX = target.posX - player.posX;
		final double posY = target.posY + target.getEyeHeight() - (player.posY + player.getEyeHeight());
		float RotationY2 = (float) MathHelper.getRandomDoubleInRange(new Random(), 150, 180);
		final double posZ = target.posZ - player.posZ;
		final double var14 = MathHelper.sqrt_double(posX * posX + posZ * posZ);
		float yaw = (float) (Math.atan2(posZ, posX) * RotationY2 / Math.PI) - 90.0f;
		float pitch = (float) (-(Math.atan2(posY, var14) * RotationY2 / Math.PI));
		float f2 = mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
		float f3 = f2 * f2 * f2 * 1.2F;
		yaw -= yaw % f3;
		pitch -= pitch % (f3 * f2);
		return new float[] { yaw, pitch };
	}

	public void drawTargetESP(EntityPlayer target, float pt) {
		if(target == null)
			return;

		final double x = target.lastTickPosX + (target.posX - target.lastTickPosX) * pt
				- mc.getRenderManager().viewerPosX;
		final double y = target.lastTickPosY + (target.posY - target.lastTickPosY) * pt
				- mc.getRenderManager().viewerPosY;
		final double z = target.lastTickPosZ + (target.posZ - target.lastTickPosZ) * pt
				- mc.getRenderManager().viewerPosZ;
		int[] rgb = Colors.getRGB(new Color(255, 133, 226).brighter().getRGB());
		GlStateManager.pushMatrix();
		GlStateManager.enableBlend();
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GlStateManager.disableDepth();
		GlStateManager.disableTexture2D();
		GlStateManager.disableAlpha();
		GL11.glLineWidth(3F);
		GL11.glShadeModel(GL11.GL_SMOOTH);
		GL11.glDisable(GL11.GL_CULL_FACE);
		final double size = target.width * 1.2;
		float factor = (float) Math.sin(System.nanoTime() / 300000000f);
		GL11.glTranslatef(0, factor, 0);
		GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
		{
			for (int j = 0; j < 361; j++) {
				color(Colors.getColor(rgb[0], rgb[1], rgb[2], 200));
				double x1 = x + Math.cos(Math.toRadians(j)) * size;
				double z1 = z - Math.sin(Math.toRadians(j)) * size;
				GL11.glVertex3d(x1, y + 1, z1);
				color(Colors.getColor(rgb[0], rgb[1], rgb[2], 0));
				GL11.glVertex3d(x1, y + 1 + factor * 0.4f, z1);
			}
		}
		GL11.glEnd();
		GL11.glBegin(GL11.GL_LINE_LOOP);
		{
			for (int j = 0; j < 361; j++) {
				color(Colors.getColor(rgb[0], rgb[1], rgb[2], 1));
				GL11.glVertex3d(x + Math.cos(Math.toRadians(j)) * size, y + 1, z - Math.sin(Math.toRadians(j)) * size);
			}
		}
		GL11.glEnd();
		GlStateManager.enableAlpha();
		GL11.glShadeModel(GL11.GL_FLAT);
		GL11.glDisable(GL11.GL_LINE_SMOOTH);
		GL11.glEnable(GL11.GL_CULL_FACE);
		GlStateManager.enableBlend();

		GlStateManager.enableTexture2D();
		GlStateManager.enableDepth();
		GlStateManager.disableBlend();
		GlStateManager.resetColor();
		GlStateManager.popMatrix();
	}

	public void color(int argb) {

		float alpha = (argb >> 24 & 255) / 255f;
		float red = (argb >> 16 & 255) / 255f;
		float green = (argb >> 8 & 255) / 255f;
		float blue = (argb & 255) / 255f;

		GL11.glColor4f(red, green, blue, alpha);
	}

	public static class Rotations {

		public static float yaw;
		public static float pitch;
		public static boolean RotationInUse;
		static Minecraft mc = Minecraft.getMinecraft();
		Random random = new Random();
		float ran = 0;
		static Timer time = new Timer();
		public static float friction = 0;
		public static float strafe = 0;
		public static float forward = 0;
		public static float f1 = 0;
		public static float f2 = 0;

		public static int getRotation(double before, float after) {

			while (before > 360.0D) {
				before -= 360.0D;
			}
			while (before < 0.0D) {
				before += 360.0D;
			}
			while (after > 360.0F) {
				after -= 360.0F;
			}
			while (after < 0.0F) {
				after += 360.0F;
			}
			if (before > after) {
				if (before - after > 180.0D) {
					return 1;
				}
				return -1;
			}
			if (after - before > 180.0D) {
				return -1;
			}
			return 1;
		}

		public static boolean setYaw(float y, float speed) {

			setRotation(yaw, pitch);
			if (speed >= 360.0F) {
				yaw = y;
				return true;
			}

			if ((isInRange(yaw, y, speed)) || (speed >= 360.0F)) {
				yaw = y;
				return true;
			}
			if (getRotation(yaw, y) < 0) {
				yaw = yaw - speed;
			} else {
				yaw = yaw + speed;
			}
			return false;
		}

		public static boolean isInRange(double before, float after, float max) {
			while (before > 360.0D)
				before -= 360.0D;
			while (before < 0.0D)
				before += 360.0D;
			while (after > 360.0F)
				after -= 360.0F;
			while (after < 0.0F)
				after += 360.0F;
			if (before > after) {
				if ((before - after > 180.0D) && (360.0D - before - after <= max))
					return true;
				return before - after <= max;
			} else {
				if ((after - before > 180.0D) && (360.0F - after - before <= max))
					return true;
				return after - before <= max;
			}
		}

		public static boolean setPitch(float p, float speed) {

			if (p > 90.0F)
				p = 90.0F;
			else if (p < -90.0F)
				p = -90.0F;

			if ((Math.abs(pitch - p) <= speed) || (speed >= 360.0F)) {
				pitch = p;
				return false;
			}

			if (p < pitch)
				pitch = pitch - speed;
			else
				pitch = pitch + speed;

			return true;
		}

		public static void setRotation(float y, float p) {
			if (p > 90.0F)
				p = 90.0F;
			else if (p < -90.0F)
				p = -90.0F;

			yaw = y;
			pitch = p;
			RotationInUse = true;
		}


		public static float[] getNewKillAuraRots(final EntityPlayerSP player, final EntityLivingBase target, float currentYaw, float currentPitch) {
			Vec3 positionEyes = player.getPositionEyes(1.0F);
			float f11 = target.getCollisionBorderSize();
			double ex = MathHelper.clamp_double(positionEyes.xCoord, target.getEntityBoundingBox().minX - f11, target.getEntityBoundingBox().maxX + f11);
			double ey = MathHelper.clamp_double(positionEyes.yCoord, target.getEntityBoundingBox().minY - f11, target.getEntityBoundingBox().maxY + f11);
			double ez = MathHelper.clamp_double(positionEyes.zCoord, target.getEntityBoundingBox().minZ - f11, target.getEntityBoundingBox().maxZ + f11);
			double x = ex - player.posX;
			double y = ey - (player.posY + (double) player.getEyeHeight());
			double z = ez - player.posZ;
			float calcYaw = (float) ((MathHelper.func_181159_b(z, x) * 180.0D / Math.PI) - 90.0F);
			float calcPitch = (float) (-((MathHelper.func_181159_b(y, MathHelper.sqrt_double(x * x + z * z)) * 180.0D / Math.PI)));
			float yawSpeed =   40;
			float pitchSpeed = 180;
			float yaw = updateRotation(currentYaw, calcYaw, yawSpeed);
			float pitch = updateRotation(currentPitch, calcPitch, pitchSpeed);
			double diffYaw = MathHelper.wrapAngleTo180_float(calcYaw - currentYaw);
			double diffPitch = MathHelper.wrapAngleTo180_float(calcPitch - currentPitch);
			if((!(-yawSpeed <= diffYaw) || !(diffYaw <= yawSpeed)) || (!(-pitchSpeed <= diffPitch) || !(diffPitch <= pitchSpeed))) {
				yaw += RandomUtil.nextFloat(1, 2) * Math.sin(pitch * Math.PI);
				pitch += RandomUtil.nextFloat(1, 2) * Math.sin(yaw * Math.PI);
			}
			final float f2 = mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
			final float f3 = f2 * f2 * f2 * 1.2F;
			yaw -= (yaw % f3);
			pitch -=(pitch % (f3 * f2));
			return new float[] {yaw, pitch };
		}



		public static float updateRotation(float p_70663_1_, float p_70663_2_, float p_70663_3_) {
			float f = MathHelper.wrapAngleTo180_float(p_70663_2_ - p_70663_1_);
			if (f > p_70663_3_) {
				f = p_70663_3_;
			}

			if (f < -p_70663_3_) {
				f = -p_70663_3_;
			}

			return p_70663_1_ + f;
		}

		public static float getPitch() {
			if (RotationInUse)
				return pitch;
			return Minecraft.getMinecraft().thePlayer.rotationPitch;
		}

		public static float getYaw() {
			if (RotationInUse)
				return yaw;
			return Minecraft.getMinecraft().thePlayer.rotationYaw;
		}

		public static float[] getRotationsForPoint(Vec3 point) {
			if (point == null)
				return null;
			double diffX = point.xCoord - Minecraft.getMinecraft().thePlayer.posX;
			double diffY = point.yCoord
					- (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight() - 0.6);
			double diffZ = point.zCoord - Minecraft.getMinecraft().thePlayer.posZ;
			double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
			float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F;
			float pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);
			final float f2 = Minecraft.getMinecraft().gameSettings.mouseSensitivity * 0.6F + 0.2F;
			final float f3 = f2 * f2 * f2 * 1.2F;
			yaw -= yaw % f3;
			pitch -= pitch % (f3 * f2);
			return new float[] { MathHelper.wrapAngleTo180_float(yaw), MathHelper.wrapAngleTo180_float(pitch) };
		}

		public static Vec3 getRandomCenter(AxisAlignedBB bb) {
			return new Vec3(bb.minX + (bb.maxX - bb.minX) * 0.5 * Math.random(),
					bb.minY + (bb.maxY - bb.minY) * 1 * Math.random(), bb.minZ + (bb.maxZ - bb.minZ) * 0.5 * Math.random());
		}

		public static Vec3 getCenter(AxisAlignedBB bb) {
			return new Vec3(bb.minX + (bb.maxX - bb.minX) * 0.5, bb.minY + (bb.maxY - bb.minY) * 0.5,
					bb.minZ + (bb.maxZ - bb.minZ) * 0.5);
		}

		public static Vec3 getCenter2(AxisAlignedBB bb) {
			return new Vec3(bb.minX + (bb.maxX - bb.minX) * 0.5 - 5, bb.minY + (bb.maxY - bb.minY) * 0.1,
					bb.minZ + (bb.maxZ - bb.minZ) * 0.5);
		}

		public static float getYawToPoint(Vec3 p) {
			float[] rotations = getRotationsForPoint(p);

			return rotations[0];
		}



		public static float getPitchToPoint(Vec3 p) {
			float[] rotations = getRotationsForPoint(p);
			return rotations[1];
		}

		public void onTick() {
			if (!RotationInUse) {
				yaw = mc.thePlayer.rotationYaw;
				pitch = mc.thePlayer.rotationPitch;
			}
		}

	}

	public static class RandomUtil {
		public static int nextInt(int origin, int bound) {
			return ThreadLocalRandom.current().nextInt(origin, bound);
		}
		public static long nextLong(long origin, long bound) {
			return ThreadLocalRandom.current().nextLong(origin, bound);
		}
		public static float nextFloat(double origin, double bound) {
			return (float) ThreadLocalRandom.current().nextDouble((float)origin, (float)bound);
		}
		public static float nextFloat(float origin, float bound) {
			return (float) ThreadLocalRandom.current().nextDouble(origin, bound);
		}
		public static double nextDouble(double origin, double bound) {
			return ThreadLocalRandom.current().nextDouble(origin, bound);
		}

		public static double randomSin() {
			return Math.sin(RandomUtil.nextDouble(0, 2*Math.PI));
		}
	}

}