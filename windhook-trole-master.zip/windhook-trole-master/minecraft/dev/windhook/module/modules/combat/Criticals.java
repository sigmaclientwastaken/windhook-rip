package dev.windhook.module.modules.combat;

import dev.windhook.event.events.*;
import dev.windhook.BaseClient;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.utils.MovementUtil;
import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.settings.Setting;
import dev.windhook.module.settings.*;
import dev.windhook.utils.Player;
import dev.windhook.utils.Timer;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;

import java.util.ArrayList;

import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import org.lwjgl.input.Keyboard;

public class Criticals extends Module {

    public static Criticals instance;

    public ModeSetting mode = new ModeSetting("Mode", "Packet", "Packet", "HPacket", "Minis", "HMinis", "Hover", "Jump");
    public NumberSetting hurtTime = new NumberSetting("Hurt Time", 10, 0, 20, 1);

    public Criticals() {
        super("Criticals", "Its crits", Keyboard.KEY_NONE, Category.COMBAT);
        addSettings(mode);
        instance = this;
    }

    Timer lastStep = new Timer();
    Timer timer = new Timer();
    int groundTicks, stage, count;
    double y;

    @Override
    public void onEnable() {
        stage = 0;
        count = 0;
    }

    @Override
    public void onMotion(MotionEvent event) {
        if(isOnGround(0.001)){
            groundTicks ++;
        }else if(!mc.thePlayer.onGround){
            groundTicks = 0;
        }

        if(event.isPre() && mode.is("Hover")){
            mc.thePlayer.lastReportedPosY = 0;
            double ypos = mc.thePlayer.posY;

            if(isOnGround(0.001)){
                event.setGround(false);
                if(stage == 0){
                    y = ypos + 1E-8;
                    event.setGround(true);
                }else if(stage == 1)
                    y-= 5E-15;
                else
                    y-= 4E-15;

                if(y <= mc.thePlayer.posY){
                    stage = 0;
                    y = mc.thePlayer.posY;
                    event.setGround(true);
                }
                event.setY(y);
                stage ++;
            }else
                stage = 0;

        }
    }

    @Override
    public void onStep(StepEvent event) {
        lastStep.reset();
        if(!mc.thePlayer.isCollidedHorizontally){
            y = mc.thePlayer.boundingBox.minY;
            stage = 0;
        }
    }

    @Override
    public void onJump(JumpEvent event) {
        if (Aura.isSetupTick() && Aura.instance.isToggled()) {
            if(mode.is("Minis") || mode.is("HMinis")){
                //if minis criticals is not on ground, send packet onground to be able to jump
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(
                        mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, true));
            }
        }
    }

    @Override
    public void onAttack(AttackEvent event) {
        if(event.isPreAttack()){
            if( event.getEntity() != null){
                if(mc.thePlayer.onGround && isOnGround(0.001) /*&& !(Client.getModuleManager().isEnabled(LongJump.class) || Client.getModuleManager().isEnabled(Bhop.class))*/){
                    if(mode.is("Packet") || mode.is("HPacket")){
                        if(event.getEntity().hurtResistantTime <= hurtTime.getValue() && lastStep.delay(20)
                                && (timer.delay(200) || event.getEntity().hurtResistantTime > 0) && mc.thePlayer.isCollidedVertically){
                            if(groundTicks > 1){
                                doCrits();
                            }

                        }
                    }else if (!mc.thePlayer.isJumping && mode.is("Jump")){
                        mc.thePlayer.jump();
                    }
                    timer.reset();

                }
            }
        }
    }

    @Override
    public void onPacketReceived(PacketReceivedEvent event) {
        if(event.getPacket() instanceof S08PacketPlayerPosLook){
            stage = 0;
        }
    }


    public void doCrits() {
        //0.0625 , 17.64e-8
        double off = 0.0626;
        double x = mc.thePlayer.posX; double y = mc.thePlayer.posY; double z = mc.thePlayer.posZ;
        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y+off, z, false));
        if(mode.is("HPacket")){
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y+off+0.00000000001, z, false));
        }
        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));


    }

    public boolean isOnGround(double height) {
        return !mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0.0D, -height, 0.0D)).isEmpty();
    }

}
