package dev.windhook.module.modules.combat;

import com.sun.javafx.geom.Vec3d;
import dev.windhook.BaseClient;
import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.utils.PathFinder;
import dev.windhook.utils.Timer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C02PacketUseEntity.Action;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TPAura extends Module {

	NumberSetting aps = new NumberSetting("Delay",500,0,5000,1);
	NumberSetting range = new NumberSetting("Range", 20, 3, 100, 1);

	Timer time = new Timer();
	public double delay;

	double x;
	double y;
	double z;

	EntityLivingBase en = null;

	ArrayList<Vec3> positions = new ArrayList<Vec3>();
	ArrayList<Vec3> positionsBack = new ArrayList<Vec3>();

	public TPAura() {
		super("TPAura", "Automatically attacks enemies", Keyboard.KEY_Y, Category.COMBAT, true);
		addSettings(aps, range);
	}

	@Override
	public void setup() {
		this.color = Color.COMBAT;
	}


	@Override
	public void onDisable() {
		positions.clear();
		positionsBack.clear();
	}

	@Override
	public void onUpdate(UpdateEvent event) {
		delay = aps.getValue();
		if(time.hasReached((long) delay)) {
			Vec3 prePos = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
			attack(modes());
			mc.thePlayer.setPositionAndUpdate(prePos.xCoord, prePos.yCoord, prePos.zCoord);
			time.reset();
		}
	}

	public Entity modes() {
		Entity target = null;

		for(EntityPlayer entity : mc.theWorld.playerEntities) {
			if(entity != mc.thePlayer)

				if(target == null || entity.getDistanceToEntity(mc.thePlayer) < target.getDistanceToEntity(mc.thePlayer)) {
					target = entity;
				}

		}
		return target;
	}

	public void attack(Entity en) {

		if (en == null) {
			return;
		}

		double range = 0;
		if(en != null)
			range = mc.thePlayer.getDistanceToEntity(en);
		double maxTP = 0.31;
		double step = maxTP / range;
		int steps = 0;
		int ind = 0;
		for (int i = 0; i < 100; i++) {
			steps++;
			if (maxTP * steps > range) {
				break;
			}
		}
//        double angleA = Math.toRadians(Math.toDegrees(Math.atan2(mc.thePlayer.posX - en.posX, mc.thePlayer.posZ - en.posZ)) + 180);
		for (int i = 0; i < steps; i++) {
			ind++;
			double difX = mc.thePlayer.posX - en.posX;
			double difZ = mc.thePlayer.posZ - en.posZ;
			double divider = step * i;
			x = mc.thePlayer.posX - difX * divider;
			y = mc.thePlayer.posY;
			z = mc.thePlayer.posZ - difZ * divider;
			difX = x - en.posX;
			difZ = z - en.posZ;
			double dist = Math.sqrt(difX * difX + difZ * difZ);
			if(dist < 3) {
				break;
			}
			sendPacket(false);
		}
		mc.thePlayer.swingItem();
		mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C02PacketUseEntity(en, C02PacketUseEntity.Action.ATTACK));
		// Go back!
		for (int i = positions.size() - 2; i > -1; i--) {
			{
				x = positions.get(i).xCoord;
				y = positions.get(i).yCoord;
				z = positions.get(i).zCoord;
			}
			sendPacket(true);
		}
	}

	public void sendPacket(boolean goingBack) {
		C03PacketPlayer.C04PacketPlayerPosition playerPacket = new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, true);
		mc.thePlayer.sendQueue.addToSendQueueNoEvent(playerPacket);
		if (goingBack) {
			positionsBack.add(new Vec3(x, y, z));
			return;
		}
		positions.add(new Vec3(x, y, z));
	}

	public static List<Vec3> calculatePath(Vec3 startPos, Vec3 endPos) {
		System.out.println("Test-1");
		final PathFinder pathfinder = new PathFinder(startPos, endPos);
		System.out.println("Test");
		pathfinder.calculatePath(5000);
		System.out.println("Test2");
		int i = 0;
		Vec3 lastLoc = null;
		Vec3 lastDashLoc = null;
		final List<Vec3> path = new ArrayList<>();
		final List<Vec3> pathFinderPath = pathfinder.getPath();
		for (final Vec3 pathElm : pathFinderPath) {
			if (i == 0 || i == pathFinderPath.size() - 1) {
				if (lastLoc != null) {
					path.add(lastLoc.addVector(0.5, 0, 0.5));
				}
				path.add(pathElm.addVector(0.5, 0, 0.5));
				lastDashLoc = pathElm;
			} else {
				boolean canContinue = true;
				if (pathElm.squareDistanceTo(lastDashLoc) > 30) {
					canContinue = false;
				} else {
					final double smallX = Math.min(lastDashLoc.xCoord, pathElm.xCoord);
					final double smallY = Math.min(lastDashLoc.yCoord, pathElm.yCoord);
					final double smallZ = Math.min(lastDashLoc.zCoord, pathElm.zCoord);
					final double bigX = Math.max(lastDashLoc.xCoord, pathElm.xCoord);
					final double bigY = Math.max(lastDashLoc.yCoord, pathElm.yCoord);
					final double bigZ = Math.max(lastDashLoc.zCoord, pathElm.zCoord);
					cordsLoop: for (int x = (int) smallX; x <= bigX; x++) {
						for (int y = (int) smallY; y <= bigY; y++) {
							for (int z = (int) smallZ; z <= bigZ; z++) {
								if (!PathFinder.checkPositionValidity(x, y, z, false)) {
									canContinue = false;
									break cordsLoop;
								}
							}
						}
					}
				}
				if (!canContinue) {
					path.add(lastLoc.addVector(0.5, 0, 0.5));
					lastDashLoc = lastLoc;
				}
			}
			lastLoc = pathElm;
			i++;
		}
		return path;
	}

}