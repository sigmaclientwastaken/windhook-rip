package dev.windhook.module.modules.combat;

import dev.windhook.event.events.MotionEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.utils.Timer;
import net.minecraft.block.BlockAir;
import net.minecraft.init.Items;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemSoup;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class AutoHeal extends Module {
    
    private int slot = -1;
    private int currentslot = -1;
    public static boolean healing = false;
    Timer timer = new Timer();

    BooleanSetting soups = new BooleanSetting("Soups",false);
    BooleanSetting potions = new BooleanSetting("Potions",true);
    BooleanSetting jumpPot = new BooleanSetting("Jump",false);
    BooleanSetting regenpots = new BooleanSetting("Regen Pots",true);
    BooleanSetting speedpots = new BooleanSetting("Speed Pots",true);
    NumberSetting health = new NumberSetting("Health", 10, 1, 20, 1);
    NumberSetting delay = new NumberSetting("Delay", 5, 5, 20, 1);
    public static boolean doSoup;

    public AutoHeal() {
        super("AutoHeal", "Automatically throws potions for you", 0, Category.COMBAT);
        addSettings(soups, potions, jumpPot, regenpots, speedpots, health, delay);
    }

    @Override
    public void onDisable() {
        currentslot = -1;
        healing = false;
    }

    @Override
    public void onMotion(MotionEvent event) {
        if (!isBlockUnder() || !isCloseEnough()) return;
        int eatables = 0;
        if (potions.isEnabled())
        {
            eatables += getPotionCount();
            if (regenpots.isEnabled())
                eatables += getRegenCount();
            if (speedpots.isEnabled()) {
                eatables += getSpeedCount();
            }
        }
        if (soups.isEnabled()) {
            int soupSlot = this.getSoupSlot();
            if(event.isPre()) {
                if(shouldHeal() && soupSlot != -1) {
                    doSoup = true;
                }
            } else if(doSoup) {
                doSoup = false;
                mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, soupSlot, 5, 2, mc.thePlayer);
                mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(5));
                mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
                mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.DROP_ALL_ITEMS, BlockPos.ORIGIN, EnumFacing.DOWN));
                mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
            }
        }
        if (potions.isEnabled()) {
            if (eatables > 0) {
                if (event.isPre()) {
                    update();
                    if (slot == -1) {
                        healing = false;
                        return;
                    }
                    boolean up = jumpPot.isEnabled() && mc.thePlayer.onGround;
                    if (mc.thePlayer.inventory.mainInventory[slot] != null && mc.thePlayer.inventory.mainInventory[slot].getItem() == Items.potionitem) {
                        if (up) mc.thePlayer.jump();
                        event.setPitch(up ? -90 : 90);
                    }
                } else {
                    if (slot == -1) return;
                    if (!healing) return;
                    if (mc.thePlayer.inventory.mainInventory[slot] == null) return;
                    int packetSlot = slot;
                    if (slot < 9) {
                        currentslot = mc.thePlayer.inventory.currentItem;
                        highlight(slot);
                        mc.getNetHandler().getNetworkManager().sendPacket(new C08PacketPlayerBlockPlacement(mc.thePlayer.getHeldItem()));
                        highlight(mc.thePlayer.inventory.currentItem);
                        highlight(currentslot);
                    } else {
                        mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(8));
                        mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, 8, 2, mc.thePlayer);
                        mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.mainInventory[slot]));
                        mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, packetSlot, 8, 2, mc.thePlayer);
                        mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                    }
                    timer.reset();
                    healing = false;
                }
            } else {
                healing = false;
            }
        }
    }

    private void update() {
        for (int i = 0; i < 36; ++i) {
            if (mc.thePlayer != null && mc.theWorld != null && mc.thePlayer.inventory.mainInventory[i] != null) {
                final ItemStack is = mc.thePlayer.inventory.mainInventory[i];
                final Item item = is.getItem();
                if (item instanceof ItemPotion && potions.isEnabled()) {
                    final ItemPotion potion = (ItemPotion) item;
                    if (potion.getEffects(is) != null) {
                        for (final PotionEffect o : potion.getEffects(is)) {
                            if (o.getPotionID() == Potion.heal.id && shouldHeal() || timer.hasReached(delay.getValue() * 50) && o.getPotionID() == Potion.moveSpeed.id && speedpots.isEnabled() && !mc.thePlayer.isPotionActive(Potion.moveSpeed) || shouldHeal() && (o.getPotionID() == Potion.regeneration.id && regenpots.isEnabled() && !mc.thePlayer.isPotionActive(Potion.regeneration)) && ItemPotion.isSplash(is.getItemDamage())) {
                                slot = i;
                                healing = true;
                            }
                        }
                    }
                }
            }
        }
    }

    private int getPotionCount() {
        int count = 0;
        for (Slot s : mc.thePlayer.inventoryContainer.inventorySlots)
            if (s.getHasStack()) {

                ItemStack is = s.getStack();
                if ((is.getItem() instanceof ItemPotion)) {

                    ItemPotion ip = (ItemPotion) is.getItem();
                    if (ItemPotion.isSplash(is.getMetadata())) {

                        boolean hasHealing = false;
                        for (PotionEffect pe : ip.getEffects(is))
                            if (pe.getPotionID() == Potion.heal.getId()) {

                                hasHealing = true;
                                break;
                            }
                        if (hasHealing) {
                            count++;
                        }
                    }
                }
            }
        return count;
    }

    private int getSoupSlot() {
        int itemSlot = -1;

        for(int i = 9; i < 45; ++i) {
            if(mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                Item item = is.getItem();
                if(item instanceof ItemSoup) {
                    itemSlot = i;
                }
            }
        }

        return itemSlot;
    }
    private int getRegenCount() {
        int count = 0;
        for (Slot s : mc.thePlayer.inventoryContainer.inventorySlots)
            if (s.getHasStack()) {

                ItemStack is = s.getStack();
                if ((is.getItem() instanceof ItemPotion)) {

                    ItemPotion ip = (ItemPotion) is.getItem();
                    if (ItemPotion.isSplash(is.getMetadata())) {

                        boolean hasHealing = false;
                        for (PotionEffect pe : ip.getEffects(is))
                            if (pe.getPotionID() == Potion.regeneration.getId()) {

                                hasHealing = true;
                                break;
                            }
                        if (hasHealing) {
                            count++;
                        }
                    }
                }
            }
        return count;
    }

    private int getSpeedCount() {
        int count = 0;
        for (Slot s : mc.thePlayer.inventoryContainer.inventorySlots)
            if (s.getHasStack()) {

                ItemStack is = s.getStack();
                if ((is.getItem() instanceof ItemPotion)) {

                    ItemPotion ip = (ItemPotion) is.getItem();
                    if (ItemPotion.isSplash(is.getMetadata())) {

                        boolean hasSpeed = false;
                        for (PotionEffect pe : ip.getEffects(is))
                            if (pe.getPotionID() == Potion.moveSpeed.getId()) {
                                hasSpeed = true;
                                break;
                            }
                        if (hasSpeed) {
                            count++;
                        }
                    }
                }
            }
        return count;
    }

    private boolean isBlockUnder() {
        for (int i = (int) (mc.thePlayer.posY - 1.0); i > 0; --i) {
            BlockPos pos = new BlockPos(mc.thePlayer.posX, i, mc.thePlayer.posZ);
            if (mc.theWorld.getBlockState(pos).getBlock() instanceof BlockAir) continue;
            return true;
        }
        return false;
    }

    private void highlight(int slot) {
        mc.thePlayer.inventory.currentItem = slot;
        mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(slot));
    }

    private boolean isCloseEnough() {
        for (double i = mc.thePlayer.posY; i > 0;i-= 0.001) {
            if (mc.theWorld.getBlockState(new BlockPos(mc.thePlayer.posX,i,mc.thePlayer.posZ)).getBlock() instanceof BlockAir) continue;
            return mc.thePlayer.posY - i <= 1.5;
        }
        return false;
    }

    private boolean shouldHeal() {
        return mc.thePlayer.getHealth() <= health.getValue() && timer.hasReached(delay.getValue() * 50);
    }
}
