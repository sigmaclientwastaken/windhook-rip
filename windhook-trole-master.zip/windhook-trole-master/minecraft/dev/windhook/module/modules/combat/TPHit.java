package dev.windhook.module.modules.combat;

import dev.windhook.event.events.Render3DEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.utils.Utils;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;

public class TPHit extends Module {

    double x;
    double y;
    double z;

    EntityLivingBase en = null;

    ArrayList<Vec3> positions = new ArrayList<Vec3>();
    ArrayList<Vec3> positionsBack = new ArrayList<Vec3>();

    NumberSetting range = new NumberSetting("Range", 7, 3, 50, 0.5);

    public TPHit() {
        super("TPHit", "Hits the nearest entity using teleportation.", Keyboard.KEY_NONE, Category.COMBAT);
        settings.add(range);
    }


    @Override
    public void onDisable() {
        positions.clear();
        positionsBack.clear();
        super.onDisable();
    }

    @Override
    public void onEnable() {
        mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
        en = Utils.getClosestEntity((float) range.getValue());
        double range = 0;
        if(en != null)
             range = mc.thePlayer.getDistanceToEntity(en);
        double maxTP = 0.31;
        double step = maxTP / range;
        int steps = 0;
        int ind = 0;
        for (int i = 0; i < 100; i++) {
            steps++;
            if (maxTP * steps > range) {
                setToggled(false);
                break;
            }
        }
//        double angleA = Math.toRadians(Math.toDegrees(Math.atan2(mc.thePlayer.posX - en.posX, mc.thePlayer.posZ - en.posZ)) + 180);
        for (int i = 0; i < steps; i++) {
            ind++;
            double difX = mc.thePlayer.posX - en.posX;
            double difZ = mc.thePlayer.posZ - en.posZ;
            double divider = step * i;
            x = mc.thePlayer.posX - difX * divider;
            y = mc.thePlayer.posY;
            z = mc.thePlayer.posZ - difZ * divider;
            difX = x - en.posX;
            difZ = z - en.posZ;
            double dist = Math.sqrt(difX * difX + difZ * difZ);
            if(dist < 3) {
                setToggled(false);
                break;
            }
            sendPacket(false);
        }
        mc.thePlayer.swingItem();
        mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C02PacketUseEntity(en, C02PacketUseEntity.Action.ATTACK));
        // Go back!
        for (int i = positions.size() - 2; i > -1; i--) {
            {
                x = positions.get(i).xCoord;
                y = positions.get(i).yCoord;
                z = positions.get(i).zCoord;
            }
            sendPacket(true);
        }
        mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
        super.onEnable();
        setToggled(false);
    }

    /*
    @Override
    public void onRender3D(Render3DEvent event) {
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(GL11.GL_BLEND);
        Utils.lineWidth(2);
        Utils.color4f(0.3f, 1f, 0.3f, 1f);
        Utils.glBegin(3);
        int i = 0;
        for (Vec3 vec : positions) {
            Utils.putVertex3d(Utils.getRenderPos(vec.xCoord, vec.yCoord, vec.zCoord));
            i++;
        }
        Utils.glEnd();
        Utils.color4f(0.3f, 0.3f, 1f, 1f);
        Utils.glBegin(3);
        i = 0;
        for (Vec3 vec : positionsBack) {
            Utils.putVertex3d(Utils.getRenderPos(vec.xCoord, vec.yCoord, vec.zCoord));
            i++;
        }
        Utils.glEnd();
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glPopMatrix();
        Utils.lineWidth(3);
        for (Vec3 vec : positions) {
            drawESP(1f, 0.3f, 0.3f, 1f, vec.xCoord, vec.yCoord, vec.zCoord);
        }
        Utils.lineWidth(1.5f);
        for (Vec3 vec : positionsBack) {
            drawESP(0.3f, 0.3f, 1f, 1f, vec.xCoord, vec.yCoord, vec.zCoord);
        }
    }

     */

    public void sendPacket(boolean goingBack) {
        C03PacketPlayer.C04PacketPlayerPosition playerPacket = new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, true);
        mc.thePlayer.sendQueue.addToSendQueueNoEvent(playerPacket);
        if (goingBack) {
            positionsBack.add(new Vec3(x, y, z));
            return;
        }
        positions.add(new Vec3(x, y, z));
    }

    public void drawESP(float red, float green, float blue, float alpha, double x, double y, double z) {
        double xPos = x - mc.getRenderManager().renderPosX;
        double yPos = y - mc.getRenderManager().renderPosY;
        double zPos = z - mc.getRenderManager().renderPosZ;
        Utils.drawOutlinedEntityESP(xPos, yPos, zPos, mc.thePlayer.width / 2, mc.thePlayer.height, red, green,
                blue, alpha);
    }

}
