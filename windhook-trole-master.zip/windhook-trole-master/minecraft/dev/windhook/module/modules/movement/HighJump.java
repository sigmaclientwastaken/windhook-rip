package dev.windhook.module.modules.movement;

import dev.windhook.BaseClient;
import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import net.minecraft.potion.Potion;
import org.lwjgl.input.Keyboard;

public class HighJump extends Module {

	ModeSetting mode = new ModeSetting("Mode", "Skywars.com", "Skywars.com");
	NumberSetting y = new NumberSetting("Y", 9, 0.1, 20, 0.1);
	BooleanSetting strafe = new BooleanSetting("Strafe", false);

	public HighJump() {
		super("HighJump", "Automatically sprints for you!", Keyboard.KEY_NONE, Category.MOVEMENT);
		addSettings(mode, y, strafe);
	}

	long ticks;

	@Override
	public void onEnable() {
		ticks = 0;
		longjump();
	}

	@Override
	public void onDisable() {

	}

	@Override
	public void onUpdate(UpdateEvent event) {
		ticks++;

		if(ticks > 10 && mc.thePlayer.onGround) {
			BaseClient.chatMessage("Disabled HighJump to prevent flags!");
			setToggled(false);
		}
	}

	@Override
	public void onMotion(MotionEvent event) {
		if(strafe.isEnabled()) {
			strafe();
		}
	}

	public void longjump() {

		if(mode.is("Skywars.com")) {
			mc.thePlayer.motionY = y.getValue();
		}

	}

	public void strafe() {
		if (!isMoving()) return;
		float yaw = direction();
		mc.thePlayer.motionX = -Math.sin(yaw) * getBaseMoveSpeed();
		mc.thePlayer.motionZ = Math.cos(yaw) * getBaseMoveSpeed();
	}

	public float direction() {
		float rotationYaw = mc.thePlayer.rotationYaw;
		if(mc.thePlayer.moveForward < 0f)
			rotationYaw += 180f;
		float forward = 1f;
		if(mc.thePlayer.moveForward < 0f)
			forward = -0.5f;
		else if(mc.thePlayer.moveForward > 0f)
			forward = 0.5f;
		if (mc.thePlayer.moveStrafing > 0f) rotationYaw -= 90f * forward;
		if (mc.thePlayer.moveStrafing < 0f) rotationYaw += 90f * forward;
		return (float) Math.toRadians(rotationYaw);
	}

	public boolean isMoving() {
		return mc.thePlayer != null && (mc.thePlayer.movementInput.moveForward != 0f || mc.thePlayer.movementInput.moveStrafe != 0f);
	}

	public double getBaseMoveSpeed() {
		double baseSpeed = 0.2873;
		if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
			final int amplifier = mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
			baseSpeed *= 1.0 + (0.2 * amplifier);
		}
		return baseSpeed;
	}
}