package dev.windhook.module.modules.movement;

import dev.windhook.event.events.PushBlockEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import org.lwjgl.input.Keyboard;

public class NoPush extends Module {

    public NoPush() {
        super("NoPush", "Stops the server from pushing you!", Keyboard.KEY_NONE, Category.MOVEMENT);
    }

    @Override
    public void onPushBlock(PushBlockEvent event) {
        event.setCancelled(true);
    }
}
