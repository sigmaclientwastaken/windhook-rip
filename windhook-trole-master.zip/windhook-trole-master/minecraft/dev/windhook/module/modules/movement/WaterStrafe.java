package dev.windhook.module.modules.movement;

import dev.windhook.event.events.MoveEvent;
import dev.windhook.event.events.PushBlockEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import org.lwjgl.input.Keyboard;

public class WaterStrafe extends Module {

    public WaterStrafe() {
        super("WaterStrafe", "Makes moving through water easier!", Keyboard.KEY_NONE, Category.MOVEMENT);
    }

    int waitTicks;

    @Override
    public void onMove(MoveEvent event) {
        if (mc.thePlayer.isInWater()) {
            waitTicks++;
            if (waitTicks == 4) {
                double forward = mc.thePlayer.movementInput.moveForward;
                double strafe = mc.thePlayer.movementInput.moveStrafe;
                float yaw = mc.thePlayer.rotationYaw;
                if ((forward == 0.0D) && (strafe == 0.0D)) {
                    event.setX(0.0D);
                    event.setZ(0.0D);
                } else {
                    if (forward != 0.0D) {
                        if (strafe > 0.0D) {
                            yaw += (forward > 0.0D ? -45 : 45);
                        } else if (strafe < 0.0D) {
                            yaw += (forward > 0.0D ? 45 : -45);
                        }
                        strafe = 0.0D;
                        if (forward > 0.0D) {
                            forward = 1;
                        } else if (forward < 0.0D) {
                            forward = -1;
                        }
                    }
                    final double var1 = Math.cos(Math.toRadians(yaw + 90.0F));
                    final double var2 = Math.sin(Math.toRadians(yaw + 90.0F));
                    event.setX(forward * 0.4000000059604645D * var1 + strafe * 0.4000000059604645D * var2);
                    event.setZ(forward * 0.4000000059604645D * var2 - strafe * 0.4000000059604645D * var1);
                }
            }
            if (waitTicks >= 5) {
                double forward = mc.thePlayer.movementInput.moveForward;
                double strafe = mc.thePlayer.movementInput.moveStrafe;
                float yaw = mc.thePlayer.rotationYaw;
                if ((forward == 0.0D) && (strafe == 0.0D)) {
                    event.setX(0.0D);
                    event.setZ(0.0D);
                } else {
                    if (forward != 0.0D) {
                        if (strafe > 0.0D) {
                            yaw += (forward > 0.0D ? -45 : 45);
                        } else if (strafe < 0.0D) {
                            yaw += (forward > 0.0D ? 45 : -45);
                        }
                        strafe = 0.0D;
                        if (forward > 0.0D) {
                            forward = 1;
                        } else if (forward < 0.0D) {
                            forward = -1;
                        }
                    }
                    final double var1 = Math.cos(Math.toRadians(yaw + 90.0F));
                    final double var2 = Math.sin(Math.toRadians(yaw + 90.0F));
                    event.setX(forward * 0.30000001192092896D * var1 + strafe * 0.30000001192092896D * var2);
                    event.setZ(forward * 0.30000001192092896D * var2 - strafe * 0.30000001192092896D * var1);
                }
                waitTicks = 0;
            }
        }
    }

    @Override
    public void onPushBlock(PushBlockEvent event) {
        event.setCancelled(true);
    }
}
