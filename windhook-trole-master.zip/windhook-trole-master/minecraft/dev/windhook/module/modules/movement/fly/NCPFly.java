package dev.windhook.module.modules.movement.fly;

import dev.windhook.BaseClient;
import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.utils.MovementUtil;
import dev.windhook.utils.Timer;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C03PacketPlayer;
import org.lwjgl.input.Keyboard;

public class NCPFly {

    // TODO: make fly modes system

    public BooleanSetting ncpVert = new BooleanSetting("NCP Vertical", false);

    Minecraft mc = Minecraft.getMinecraft();

    Timer vertTimer = new Timer();
    boolean clipped;

    public void onEnable() {

        ModuleManager.gameSpeed.setOverride(true);

        mc.timer.timerSpeed = 0.4f;

        clipped = false;

    }

    public void onUpdate(UpdateEvent event) {

        mc.thePlayer.onGround = true;

        if(!clipped) {
            if(mc.thePlayer.isCollided) {
                clipped = true;
                mc.timer.timerSpeed = 1f;
                BaseClient.chatMessage("Clipped (NCP Fly)");
            } else {
                mc.thePlayer.motionZ = 0;
                mc.thePlayer.motionX = 0;
                mc.thePlayer.motionY = 0;
            }
        }

        if(clipped) {

            mc.thePlayer.motionY = 0;

            if (MovementUtil.areMovementKeysPressed()) {
                MovementUtil.setSpeed((float) 0.125D);
            } else {
                mc.thePlayer.motionX = 0;
                mc.thePlayer.motionZ = 0;
            }

           // if(vertTimer.hasReached(5000)) {
           //     if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
           //         mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.5, mc.thePlayer.posZ);
           //         vertTimer.reset();
           //     } else if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
           //         mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.5, mc.thePlayer.posZ);
           //         vertTimer.reset();
           //     }
           // }

        }
    }

    public void onPacketSent(PacketSentEvent event) {

    }

    public void onDisable() {
        mc.timer.timerSpeed = 1f;
        ModuleManager.gameSpeed.setOverride(false);
    }

}
