package dev.windhook.module.modules.movement;

import dev.windhook.BaseClient;
import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.modules.combat.TargetStrafe;
import dev.windhook.module.modules.movement.fly.AirBoostFly;
import dev.windhook.module.modules.movement.fly.BlocksMCFastFly;
import dev.windhook.module.modules.movement.fly.NCPFly;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.utils.MovementUtil;
import dev.windhook.utils.Timer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.*;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import org.lwjgl.input.Keyboard;

import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;

import java.util.ArrayList;
import java.util.Queue;

public class Fly extends Module {

	// TODO: add vanilla fly.
	public ModeSetting mode = new ModeSetting("Mode", "Creative", "Creative", "Vanilla", "Dash",
												"TEST", "Verus", "NCP", "Air Low Hop", "Minemora", "Minemora Blink");
	public NumberSetting speed = new NumberSetting("Speed", 1.0D, 0.1D, 10D, 0.1D);
	public NumberSetting glide = new NumberSetting("Glide", 5D, 1D, 10D, 0.5D);

	ModeSetting damage = new ModeSetting("Damage", "3Packet", "3Packet", "2Packet", "VTP", "None");
	public BooleanSetting groundSpoof = new BooleanSetting("Ground Spoof", true);

	public BooleanSetting timerBoost = new BooleanSetting("Timer Boost", true);
	public NumberSetting timerSpeed = new NumberSetting("Boost Speed", 1.2, 1, 5, 0.05);
	public NumberSetting timerTicks = new NumberSetting("Boost Ticks", 15, 0, 80, 1);

	BooleanSetting minemoraDead = new BooleanSetting("Minemora Dead", false);

	double startingY;
	long startingTicksExisted; // TODO: dumbest code to ever be put in this client
	BlocksMCFastFly blocksMCFastFly = new BlocksMCFastFly();
	NCPFly ncpFly = new NCPFly();
	AirBoostFly airHopFly = new AirBoostFly();
	Timer dashTimer = new Timer();
	boolean blinking;
	boolean damaged;

	double x;
	double y;
	double z;

	ArrayList<Packet> packets = new ArrayList<>();

	public Fly() {
		super("Fly", "Reach the outer skies!", Keyboard.KEY_F, Category.MOVEMENT);
		settings.add(mode);
		settings.add(speed);
		settings.add(glide);
		settings.add(groundSpoof);
		settings.add(damage);
		settings.add(timerBoost);
		settings.add(timerSpeed);
//		settings.add(ncpFly.ncpVert);
	}

	private boolean isFlying;
	private boolean allowFlying;

	@Override
	public void setup() {
		this.color = Color.MOVEMENT;
	}

	@Override
	public void onEnable() {
		startingTicksExisted = mc.thePlayer.ticksExisted;
		startingY = mc.thePlayer.posY;
		this.isFlying = mc.thePlayer.capabilities.isFlying;
		this.allowFlying = mc.thePlayer.capabilities.allowFlying;

		if(mode.is("Dash")) {
			mc.thePlayer.setPosition(Math.rint(mc.thePlayer.posX),
					Math.rint(mc.thePlayer.posY),
					Math.rint(mc.thePlayer.posZ));
		}

		if(mode.is("Creative")) {
			mc.thePlayer.capabilities.allowFlying = true;
		}

		if(mode.is("TEST")) {
			blocksMCFastFly.onEnable();
		}

		if(mode.is("NCP")) {
			ncpFly.onEnable();
		}

		if(mode.is("Verus")) {
			if(damage.is("VTP")) {
				mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 2, mc.thePlayer.posZ, false));
				mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY - 2, mc.thePlayer.posZ, false));
			}
			if(damage.is("3Packet")) {
				mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 3.01, mc.thePlayer.posZ, false));
				mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false));
				mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, true));
			}
			if(damage.is("2Packet")) {
				mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 3.01, mc.thePlayer.posZ, false));
				mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY - 3, mc.thePlayer.posZ, true));
			}
		}

		if(mode.is("Minemora Blink")) {
			mc.timer.timerSpeed = 0.2f;
			blinking = true;

			EntityPlayerSP player = mc.thePlayer;
			x = player.posX;
			y = player.posY;
			z = player.posZ;

	//		mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 3.01, z, false));
	//		mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));
	//		mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, true));


		}

	}

	@Override
	public void onDisable() {
		mc.thePlayer.capabilities.allowFlying = allowFlying;
		mc.thePlayer.capabilities.isFlying = isFlying;

		mc.timer.timerSpeed = 1f;

		if(mode.is("NCP")) {
			ncpFly.onDisable();
		}

		if(mode.is("Minemora Blink")) {
			mc.timer.timerSpeed = 1;
			blinking = false;
			damaged = false;

	//		EntityPlayerSP player = mc.thePlayer;
	//		x = player.posX;
	//		y = player.posY;
	//		z = player.posZ;

			if(minemoraDead.isEnabled()){
				mc.thePlayer.isDead = true;
			}

			mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 3.01, z, false));
			mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));
			mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, true));

			for(Packet p : packets) {
//				if(!(p instanceof C00PacketKeepAlive ||
//				p instanceof C0FPacketConfirmTransaction)) {
					mc.thePlayer.sendQueue.addToSendQueue(p);
//				}
//				mc.thePlayer.setPositionAndUpdate(x, y, z);
			}
			packets.clear();

			if(minemoraDead.isEnabled()){
				mc.thePlayer.isDead = false;
			}
		}
	}

	@Override
	public void onUpdate(UpdateEvent event) {

		if(groundSpoof.isEnabled()) {
			mc.thePlayer.onGround = true;
		}

		if(mode.is("Creative")) {
			mc.thePlayer.capabilities.isFlying = true;
		}

		if(mode.is("TEST")) {
			blocksMCFastFly.onUpdate(event);
		}

		if(mode.is("Vanilla") || mode.is("Verus")) {
			if (MovementUtil.areMovementKeysPressed()) {
				MovementUtil.setSpeed((float) speed.getValue());
			} else {
				mc.thePlayer.motionX = 0;
				mc.thePlayer.motionZ = 0;
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
				mc.thePlayer.motionY = speed.getValue();
			} else if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
				mc.thePlayer.motionY = -speed.getValue();
			} else {
				mc.thePlayer.motionY = 0;
			}
		}

		if(mode.is("NCP")) {
			ncpFly.onUpdate(event);
		}

		if(mode.is("Air Low Hop")) {
			airHopFly.onUpdate(event);
		}

		if(mode.is("Dash")) {
			mc.thePlayer.onGround = true;
			noMotion();
			mc.thePlayer.setPosition(Math.rint(mc.thePlayer.posX),
									 mc.thePlayer.posY,
									 Math.rint(mc.thePlayer.posZ));

			if(timer.hasReached(500)) {
				double lowerY = speed.getValue() / glide.getValue();
				double angleA = Math.toRadians(normalizeAngle(mc.thePlayer.rotationYawHead - 90));
				double px = mc.thePlayer.posX - Math.cos(angleA) * speed.getValue();
				double pz = mc.thePlayer.posZ - Math.sin(angleA) * speed.getValue();
				mc.thePlayer.setPosition(Math.rint(px),
						mc.thePlayer.posY - lowerY,
						Math.rint(pz));
				timer.reset();
			}



		}

		if(mode.is("Minemora")) {


	//		mc.thePlayer.motionY = -0.005;



			if(mc.thePlayer.ticksExisted % 2 == 0) {
				mc.thePlayer.motionY = -0.07;
			} else {
				mc.thePlayer.motionY = 0.066381937;
			}

		}

		if(mode.is("Minemora Blink")) {
			if(damaged && blinking) {
				if (MovementUtil.areMovementKeysPressed()) {
					MovementUtil.setSpeed((float) speed.getValue());
				} else {
					mc.thePlayer.motionX = 0;
					mc.thePlayer.motionZ = 0;
				}

				if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
					mc.thePlayer.motionY = speed.getValue();
				} else if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
					mc.thePlayer.motionY = -speed.getValue();
				} else {
					mc.thePlayer.motionY = 0;
				}
			} else if(blinking) {

				mc.timer.timerSpeed = 0.9f;
				BaseClient.chatMessage("Blinked! COUNTER:"+packets.size());
				damaged = true;
			}
		}


	}

	@Override
	public void onPacketSent(PacketSentEvent event) {

		if(mode.is("TEST")) {
			blocksMCFastFly.onPacketSent(event);
		}

		if(mode.is("Minemora Blink")) {
			if(event.getPacket() instanceof C00PacketKeepAlive ||
			event.getPacket() instanceof C0FPacketConfirmTransaction)
				return;

			packets.add(event.getPacket());
			event.setCancelled(true);

		}

	}



	// TODO: optimize
	public double direction() {
		float rotationYaw = mc.thePlayer.rotationYaw;
		if(mc.thePlayer.moveForward < 0f)
			rotationYaw += 180f;
		float forward = 1f;
		if(mc.thePlayer.moveForward < 0f)
			forward = -0.5f;
		else if(mc.thePlayer.moveForward > 0f)
			forward = 0.5f;
		if (mc.thePlayer.moveStrafing > 0f) rotationYaw -= 90f * forward;
		if (mc.thePlayer.moveStrafing < 0f) rotationYaw += 90f * forward;
		return Math.toRadians(rotationYaw);
	}

	public void noMotion() {
		mc.thePlayer.motionY = 0;
		mc.thePlayer.motionX = 0;
		mc.thePlayer.motionZ = 0;
	}

	public static float normalizeAngle(float angle) {
		return (angle + 360) % 360;
	}

	private double getBaseMoveSpeed() {
		double baseSpeed = 0.2873;
		if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
			final int amplifier = mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
			baseSpeed *= 1.0 + (0.2 * amplifier);
		}
		return baseSpeed;
	}

	public float getMaxFallDist() {
		PotionEffect potioneffect = mc.thePlayer.getActivePotionEffect(Potion.jump);
		int f = potioneffect != null ? potioneffect.getAmplifier() + 1 : 0;
		return (float)(mc.thePlayer.getMaxFallHeight() + f);
	}

	@Override
	public String getAddon() {
		return mode.getMode();
	}
}