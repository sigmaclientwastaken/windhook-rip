package dev.windhook.module.modules.movement;

import dev.windhook.BaseClient;
import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

import java.awt.*;

public class GuiMove extends Module {

    ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Position");
    BooleanSetting jump = new BooleanSetting("Jump", false);
    BooleanSetting sprint = new BooleanSetting("Sprint", false);

    Vec3 startPos;

    public GuiMove() {
        super("InvMove", "Lets you move in GUIs.", Keyboard.KEY_NONE, Category.MOVEMENT);
        addSettings(mode, jump, sprint);
    }

    @Override
    public void onEnable() {
        startPos = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
    }

    @Override
    public void onMotion(MotionEvent event) {
        if (!(mc.currentScreen instanceof GuiChat || mc.currentScreen == null)) {
            mc.gameSettings.keyBindForward.pressed = GameSettings.isKeyDown(mc.gameSettings.keyBindForward);
            mc.gameSettings.keyBindBack.pressed = GameSettings.isKeyDown(mc.gameSettings.keyBindBack);
            mc.gameSettings.keyBindRight.pressed = GameSettings.isKeyDown(mc.gameSettings.keyBindRight);
            mc.gameSettings.keyBindLeft.pressed = GameSettings.isKeyDown(mc.gameSettings.keyBindLeft);

            if (jump.isEnabled())
                mc.gameSettings.keyBindJump.pressed = GameSettings.isKeyDown(mc.gameSettings.keyBindJump);

            if (sprint.isEnabled())
                mc.gameSettings.keyBindSprint.pressed = GameSettings.isKeyDown(mc.gameSettings.keyBindSprint);
        }

        if (mc.currentScreen != null && mode.is("Position")) {
            event.setX(startPos.xCoord);
            event.setY(startPos.yCoord);
            event.setZ(startPos.zCoord);
        }

    }

    @Override
    public void onRender2D(Render2DEvent event) {
        if (mc.currentScreen != null && mode.is("Position")) {
            ScaledResolution sr = new ScaledResolution(mc);
            BaseClient.getInstance().getFont().getFont(25).drawString(
                    "Desynced!", (sr.getScaledWidth() / 2) + 100, sr.getScaledHeight()
                            - BaseClient.getInstance().getFont().getFont(25).getStringHeight("Desynced") - 3,
                    new Color(215, 20, 20).getRGB());
        }
    }
}