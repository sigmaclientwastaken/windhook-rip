package dev.windhook.module.modules.movement;

import dev.windhook.BaseClient;
import dev.windhook.event.events.GuiRenderEvent;
import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;

public class Boost extends Module {

	NumberSetting slow = new NumberSetting("Slow Multi", 0.85, 0.1, 1, 0.05);
	NumberSetting fast = new NumberSetting("Fast Multi", 1.2, 1, 10, 0.05);
	BooleanSetting random = new BooleanSetting("Random", false);
	NumberSetting randomOffset = new NumberSetting("Random Offset", 0.05, 0.01, 0.1, 0.005);
															//					 				100 - 1000  (/10000)
	public Boost() {
		super("Boost", "Boosts your movement speed!", Keyboard.KEY_NONE, Category.MOVEMENT);
		addSettings(fast, slow);
	}

	long ticks;
	boolean boosting;

	@Override
	public void setup() {
		this.color = Color.MOVEMENT;
	}

	@Override
	public void onEnable() {
		ticks = 0;
	}

	@Override
	public void onDisable() {

	}

	@Override
	public void onUpdate(UpdateEvent event) {

		boosting = mc.gameSettings.keyBindJump.isKeyDown();

		if(boosting) {
			mc.timer.timerSpeed = (float) fast.getValue();
			ticks--;
		} else {
			mc.timer.timerSpeed = (float) slow.getValue();
			ticks++;
		}

	}

	@Override
	public void onGuiRender(GuiRenderEvent event) {
		ScaledResolution sr = new ScaledResolution(mc);
		BaseClient.getInstance().getFont().getFont(25).drawString("Boost: " + ticks, sr.getScaledWidth() +
				BaseClient.getInstance().getFont().getFont(25).getStringWidth("Boost: "+ticks) + 3, sr.getScaledHeight() - 30, -1, true);
	}


}