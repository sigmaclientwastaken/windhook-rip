package dev.windhook.module.modules.movement;

import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.MoveEvent;
import dev.windhook.event.events.PacketReceivedEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.modules.combat.TargetStrafe;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.utils.MovementUtil;
import dev.windhook.utils.Timer;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Keyboard;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Speed extends Module {

	public static Speed instance;

	ModeSetting mode = new ModeSetting("Mode", "Legit", "Legit", "Strafe", "OldHypixel", "OnGround", "AAC", "BHop", "NCP", "Mineplex", "PacketHop", "VHop", "Minemora", "Lowhop");
	NumberSetting speed = new NumberSetting("Speed", 1.2, 0.5, 10.0, 0.1);
	NumberSetting hop = new NumberSetting("LowHop Motion", 0.2, 0, 1, 0.01);
	NumberSetting slowdown = new NumberSetting("LowHop Slowdown", 0.3, 0.1, 0.7, 0.01);
	BooleanSetting lagbackCheck = new BooleanSetting("Lagback Check", true);
	NumberSetting lagbackDelay = new NumberSetting("Lagback Delay", 200, 10, 500, 1);

	Timer lagbackTimer = new Timer();

	public double moveSpeed;
	private double lastDist;
	private double y;
	private int stage;
	private int hops;

	public Speed() {
		super("Speed", "Makes you move faster!", Keyboard.KEY_NONE, Category.MOVEMENT);
		addSettings(mode, speed, hop, slowdown);
		instance = this;
	}

	@Override
	public void onMotion(MotionEvent event) {
		if(event.getEventType() == MotionEvent.Type.PRE) {
			return;
		}

		if (isInLiquid()) {
			return;
		}

		if(mode.is("Minemora")) {
			boolean boost = (Math.abs(this.mc.thePlayer.rotationYawHead - this.mc.thePlayer.rotationYaw) < 90.0F);
			if (mc.thePlayer.isMoving()&& this.mc.thePlayer.hurtTime < 5)
				if (this.mc.thePlayer.onGround) {
					// mc.timer.timerSpeed = 1F;
					float f = getDirection();
					if(!ModuleManager.scaffold.isToggled()) {
						this.mc.thePlayer.motionX -= (MathHelper.sin(f) * 0.2F);
						this.mc.thePlayer.motionZ += (MathHelper.cos(f) * 0.2F);
					}
				} else {
					//  mc.timer.timerSpeed = 1F;
					double currentSpeed = Math.sqrt(
							this.mc.thePlayer.motionX * this.mc.thePlayer.motionX + this.mc.thePlayer.motionZ * this.mc.thePlayer.motionZ);
					double speed1 = 1.0074D;
					double direction = getDirection();
					this.mc.thePlayer.motionX = -Math.sin(direction) * speed1 * currentSpeed;
					this.mc.thePlayer.motionZ = Math.cos(direction) * speed1 * currentSpeed;
				}
		}

		EntityPlayerSP player = mc.thePlayer;

		if (player.isMoving()) {
			if (mode.is("OldHypixel")) {
				if (player.isCollidedVertically) {
					event.setY(mc.thePlayer.posY + 7.435E-4D);
				}
			} else if (mode.is("Mineplex")) {
				mc.thePlayer.stepHeight = 0.0F;
				if (mc.thePlayer.isCollidedHorizontally) {
					this.moveSpeed = 0.0D;
					this.hops = 1;
				}
				if (mc.thePlayer.fallDistance < 8.0F) {
					mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.4D, mc.thePlayer.posZ);
					EntityPlayerSP var10000 = mc.thePlayer;
					var10000.motionY += 0.02D;
				} else {
					this.moveSpeed = 0.0D;
					this.hops = 1;
					mc.thePlayer.motionY = -1.0D;
				}
			} else if (mode.is("OnGround") && canSpeed()) {
				event.setGround(this.stage == 5);
				event.setY(mc.thePlayer.posY + this.y + 7.435E-4D);
			}
		}

		if(mode.is("Lowhop")) {
			if(mc.thePlayer.isMoving()) {
				if(mc.thePlayer.onGround) {
					mc.thePlayer.motionY = hop.getValue();
				}
				float yaw = direction();
				mc.thePlayer.motionX = -Math.sin(yaw) * (mc.thePlayer.motionY < slowdown.getValue()? speed.getValue()*0.95 : speed.getValue());
				mc.thePlayer.motionZ = Math.cos(yaw) * (mc.thePlayer.motionY < slowdown.getValue()? speed.getValue()*0.95 : speed.getValue());
			}
		}

		double xDist = player.posX - player.prevPosX;
		double zDist = player.posZ - player.prevPosZ;
		this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
	}

	@Override
	public void onMove(MoveEvent event) {
		EntityPlayerSP player = mc.thePlayer;
		if (!isInLiquid()) {
			if (player.isMoving()) {
				double rounded;
				double difference;
				label184:
				switch(mode.getMode()) {
					case "NCP":
						switch(this.stage) {
							case 2:
								if (player.onGround && player.isCollidedVertically) {
									event.y = player.motionY = getJumpBoostModifier(0.41999998688697815D);
									this.moveSpeed *= 2.149D;
									mc.timer.timerSpeed = 1.4F;
								}
								break label184;
							case 3:
								rounded = 0.86D * (this.moveSpeed - getBaseMoveSpeed());
								this.moveSpeed = this.lastDist - rounded;
								break label184;
						}

						if (mc.theWorld.getCollidingBoundingBoxes(player, player.getEntityBoundingBox().offset(0.0D, player.motionY, 0.0D)).size() > 0 || player.isCollidedVertically && player.onGround) {
							this.stage = 1;
						}

						mc.timer.timerSpeed = 1.0F;
						break;
					case "OldHypixel":
						switch(this.stage) {
							case 2:
								if (player.onGround && player.isCollidedVertically) {
									mc.timer.timerSpeed = 1.0F;
									event.y = player.motionY = getJumpBoostModifier(0.41999998688697815D);
									this.moveSpeed = getBaseMoveSpeed() * 1.5D;
								}
								break;
							case 3:
								rounded = 0.6200000047683716D * (this.lastDist - getBaseMoveSpeed());
								this.moveSpeed = this.lastDist + rounded;
								break;
							default:
								if (mc.theWorld.getCollidingBoundingBoxes(player, player.getEntityBoundingBox().offset(0.0D, player.motionY, 0.0D)).size() > 0 || player.isCollidedVertically && player.onGround) {
									this.stage = 1;
									mc.timer.timerSpeed = 1.085F;
									++this.hops;
								}

								this.moveSpeed = this.lastDist - this.lastDist / 149.0D;
						}

						this.moveSpeed = Math.max(this.moveSpeed, getBaseMoveSpeed());
						break;
					case "PacketHop":
						switch(this.stage) {
							case 2:
								mc.timer.timerSpeed = 2.0F;
								this.moveSpeed = 0.0D;
								break label184;
							case 3:
								mc.timer.timerSpeed = 1.0F;
								if (player.onGround && player.isCollidedVertically) {
									event.y = player.motionY = getJumpBoostModifier(0.41999998688697815D);
									this.moveSpeed = getBaseMoveSpeed() * 2.149D;
								}
								break label184;
							case 4:
								rounded = 0.5600000023841858D * (this.lastDist - getBaseMoveSpeed());
								this.moveSpeed = this.lastDist - rounded;
								break label184;
						}

						if (mc.theWorld.getCollidingBoundingBoxes(player, player.getEntityBoundingBox().offset(0.0D, player.motionY, 0.0D)).size() > 0 || player.isCollidedVertically && player.onGround) {
							this.stage = 1;
							mc.timer.timerSpeed = 1.085F;
						}

						if (player.motionY < 0.0D) {
							player.motionY *= 1.1D;
						}

						this.moveSpeed = this.lastDist - this.lastDist / 50.0D;
						break;
					case "Mineplex":
						switch(this.stage) {
							case 2:
								if (player.onGround && player.isCollidedVertically) {
									this.moveSpeed = 0.0D;
								}

								mc.timer.timerSpeed = 2.5F;
								break;
							case 3:
								mc.timer.timerSpeed = 1.0F;
								this.moveSpeed = Math.min(0.3D * (double)this.hops, 0.97D);
								break;
							default:
								if (mc.theWorld.getCollidingBoundingBoxes(player, player.getEntityBoundingBox().offset(0.0D, player.motionY, 0.0D)).size() > 0 || player.isCollidedVertically && player.onGround) {
									this.stage = 1;
									++this.hops;
								}

								this.moveSpeed -= 0.01D;
						}

						if (this.stage != 2) {
							this.moveSpeed = Math.max(this.moveSpeed, getBaseMoveSpeed());
						}
						break;
					case "VHop":
						rounded = round(player.posY - (double)((int)player.posY), 3.0D);
						if (rounded == round(0.4D, 3.0D)) {
							event.y = player.motionY = 0.31D;
						} else if (rounded == round(0.71D, 3.0D)) {
							event.y = player.motionY = 0.04D;
						} else if (rounded == round(0.75D, 3.0D)) {
							event.y = player.motionY = -0.2D;
						} else if (rounded == round(0.55D, 3.0D)) {
							event.y = player.motionY = -0.14D;
						} else if (rounded == round(0.41D, 3.0D)) {
							event.y = player.motionY = -0.2D;
						}

						switch(this.stage) {
							case 0:
								if (player.onGround && player.isCollidedVertically) {
									this.moveSpeed = getBaseMoveSpeed() * 1.3D;
								}
								break;
							case 1:
							default:
								if (mc.theWorld.getCollidingBoundingBoxes(player, player.getEntityBoundingBox().offset(0.0D, player.motionY, 0.0D)).size() > 0 || player.isCollidedVertically && player.onGround) {
									this.stage = 1;
								}

								this.moveSpeed = this.lastDist - this.lastDist / 159.0D;
								break;
							case 2:
								if (player.onGround && player.isCollidedVertically) {
									event.y = player.motionY = getJumpBoostModifier(0.40001D);
									this.moveSpeed *= 1.8D;
								}

								mc.timer.timerSpeed = 1.2F;
								break;
							case 3:
								mc.timer.timerSpeed = 1.0F;
								difference = 0.72D * (this.lastDist - getBaseMoveSpeed());
								this.moveSpeed = this.lastDist - difference;
						}

						this.moveSpeed = Math.max(this.moveSpeed, getBaseMoveSpeed());
						break;
					case "OnGround":
						if (this.canSpeed()) {
							switch(this.stage) {
								case 1:
									mc.timer.timerSpeed = 1.0F;
									this.y = getJumpBoostModifier(0.40001D);
									this.moveSpeed = getBaseMoveSpeed() * 2.149D;
									break label184;
								case 2:
									this.y = getJumpBoostModifier(0.381D);
									difference = 0.66D * (this.lastDist - getBaseMoveSpeed());
									this.moveSpeed = this.lastDist - difference;
									break label184;
								case 3:
									this.y = getJumpBoostModifier(0.22D);
									this.moveSpeed = this.lastDist - this.lastDist / 159.0D;
									break label184;
								case 4:
									this.y = getJumpBoostModifier(0.11D);
									this.moveSpeed = this.lastDist - this.lastDist / 159.0D;
									break label184;
								case 5:
									mc.timer.timerSpeed = 2.0F;
									this.y = 0.0D;
									this.moveSpeed = this.lastDist - this.lastDist / 159.0D;
									this.stage = 0;
							}
						} else {
							this.y = 0.0D;
							this.moveSpeed = getBaseMoveSpeed();
							this.stage = 0;
							mc.timer.timerSpeed = 1.0F;
						}
						break;
					case "BHop":
						if (player.onGround && player.isCollidedVertically) {
							event.y = player.motionY = getJumpBoostModifier(0.41999998688697815D);
							this.moveSpeed = speed.getValue() * getBaseMoveSpeed();
						} else {
							this.moveSpeed = this.lastDist - this.lastDist / 159.0D;
						}

						this.moveSpeed = Math.max(this.moveSpeed, getBaseMoveSpeed());
				}

				if (!ModuleManager.ts.canStrafe()) {
					setSpeed(event, this.moveSpeed);
				}

				++this.stage;
			}

		}
	}

	@Override
	public void onDisable() {
		mc.gameSettings.keyBindJump.setPressed(Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode()));
		mc.timer.timerSpeed = 1f;
		mc.thePlayer.stepHeight = 0.625F;
	}

	@Override
	public void onEnable() {
		this.y = 0.0D;
		this.hops = 1;
		this.moveSpeed = getBaseMoveSpeed();
		this.lastDist = 0.0D;
		this.stage = 0;
	}

	@Override
	public void onPacketReceived(PacketReceivedEvent event) {
		if(event.getPacket() instanceof S08PacketPlayerPosLook) {
			lastDist = 0;
		}
	}

	public boolean lagbackCheck() {
		return (!lagbackCheck.isEnabled()) || (lagbackTimer.hasReached(lagbackDelay.getValue()));
	}

	public float getSpeed() {
		return (float) Math.sqrt(mc.thePlayer.motionX * mc.thePlayer.motionX + mc.thePlayer.motionZ * mc.thePlayer.motionZ);
	}

	public void strafe(float speed) {
		if (!isMoving()) return;
		float yaw = direction();
		mc.thePlayer.motionX = -Math.sin(yaw) * speed;
		mc.thePlayer.motionZ = Math.cos(yaw) * speed;
	}

	public float direction() {
		float rotationYaw = mc.thePlayer.rotationYaw;
		if(mc.thePlayer.moveForward < 0f)
			rotationYaw += 180f;
		float forward = 1f;
		if(mc.thePlayer.moveForward < 0f)
			forward = -0.5f;
		else if(mc.thePlayer.moveForward > 0f)
			forward = 0.5f;
		if (mc.thePlayer.moveStrafing > 0f) rotationYaw -= 90f * forward;
		if (mc.thePlayer.moveStrafing < 0f) rotationYaw += 90f * forward;
		return (float) Math.toRadians(rotationYaw);
	}

	public boolean isMoving() {
		return mc.thePlayer != null && (mc.thePlayer.movementInput.moveForward != 0f || mc.thePlayer.movementInput.moveStrafe != 0f);
	}

	public float getRotationFromPosition(final double x, final double z) {
		final double xDiff = x - mc.thePlayer.posX;
		final double zDiff = z - mc.thePlayer.posZ;
		return (float) (Math.atan2(zDiff, xDiff) * 180.0D / Math.PI) - 90.0f;
	}

	public boolean inVoid() {
		for (int i = (int) Math.ceil(mc.thePlayer.posY); i >= 0; i--) {
			if (mc.theWorld.getBlockState(new BlockPos(mc.thePlayer.posX, i, mc.thePlayer.posZ)).getBlock() != Blocks.air) {
				return false;
			}
		}
		return true;
	}

	private double[] getDirectionalSpeed(final double speed) {
		float forward = mc.thePlayer.movementInput.moveForward;
		float side = mc.thePlayer.movementInput.moveStrafe;
		float yaw = mc.thePlayer.prevRotationYaw + (mc.thePlayer.rotationYaw - mc.thePlayer.prevRotationYaw) * mc.timer.renderPartialTicks;
		if (forward != 0.0f) {
			if (side > 0.0f) {
				yaw += ((forward > 0.0f) ? -45 : 45);
			} else if (side < 0.0f) {
				yaw += ((forward > 0.0f) ? 45 : -45);
			}
			side = 0.0f;
			if (forward > 0.0f) {
				forward = 1.0f;
			} else if (forward < 0.0f) {
				forward = -1.0f;
			}
		}
		final double sin = Math.sin(Math.toRadians(yaw + 90.0f));
		final double cos = Math.cos(Math.toRadians(yaw + 90.0f));
		final double posX = forward * speed * cos + side * speed * sin;
		final double posZ = forward * speed * sin - side * speed * cos;
		return new double[]{posX, posZ};
	}

	public double getBaseMoveSpeed() {
		double baseSpeed = 0.2873;
		if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
			final int amplifier = mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
			baseSpeed *= 1.0 + (0.2 * amplifier);
		}
		return baseSpeed;
	}

	public double roundToPlace(final double value, final int places) {
		if (places < 0) {
			throw new IllegalArgumentException();
		}
		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}


	public boolean isInLiquid() {
		boolean inLiquid = false;
		AxisAlignedBB playerBB = mc.thePlayer.getEntityBoundingBox();
		int y = (int)playerBB.minY;

		for(int x = MathHelper.floor_double(playerBB.minX); x < MathHelper.floor_double(playerBB.maxX) + 1; ++x) {
			for(int z = MathHelper.floor_double(playerBB.minZ); z < MathHelper.floor_double(playerBB.maxZ) + 1; ++z) {
				Block block = mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
				if (block != null && !(block instanceof BlockAir)) {
					if (!(block instanceof BlockLiquid)) {
						return false;
					}

					inLiquid = true;
				}
			}
		}

		return inLiquid;
	}

	public void setSpeed(MoveEvent moveEvent, double moveSpeed) {
		setSpeed(moveEvent, moveSpeed, mc.thePlayer.rotationYaw, (double)mc.thePlayer.movementInput.moveStrafe, (double)mc.thePlayer.movementInput.moveForward);
	}

	public void setSpeed(MoveEvent moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
		double forward = pseudoForward;
		double strafe = pseudoStrafe;
		float yaw = pseudoYaw;
		if (pseudoForward != 0.0D) {
			if (pseudoStrafe > 0.0D) {
				yaw = pseudoYaw + (float)(pseudoForward > 0.0D ? -45 : 45);
			} else if (pseudoStrafe < 0.0D) {
				yaw = pseudoYaw + (float)(pseudoForward > 0.0D ? 45 : -45);
			}

			strafe = 0.0D;
			if (pseudoForward > 0.0D) {
				forward = 1.0D;
			} else if (pseudoForward < 0.0D) {
				forward = -1.0D;
			}
		}

		if (strafe > 0.0D) {
			strafe = 1.0D;
		} else if (strafe < 0.0D) {
			strafe = -1.0D;
		}

		double mx = Math.cos(Math.toRadians((double)(yaw + 90.0F)));
		double mz = Math.sin(Math.toRadians((double)(yaw + 90.0F)));
		moveEvent.x = forward * moveSpeed * mx + strafe * moveSpeed * mz;
		moveEvent.z = forward * moveSpeed * mz - strafe * moveSpeed * mx;
	}

	private boolean canSpeed() {
		Block blockBelow = mc.theWorld.getBlockState(new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1.0D, mc.thePlayer.posZ)).getBlock();
		return mc.thePlayer.onGround && !mc.gameSettings.keyBindJump.isPressed() && blockBelow != Blocks.stone_stairs && blockBelow != Blocks.oak_stairs && blockBelow != Blocks.sandstone_stairs && blockBelow != Blocks.nether_brick_stairs && blockBelow != Blocks.spruce_stairs && blockBelow != Blocks.stone_brick_stairs && blockBelow != Blocks.birch_stairs && blockBelow != Blocks.jungle_stairs && blockBelow != Blocks.acacia_stairs && blockBelow != Blocks.brick_stairs && blockBelow != Blocks.dark_oak_stairs && blockBelow != Blocks.quartz_stairs && blockBelow != Blocks.red_sandstone_stairs && mc.theWorld.getBlockState(new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY + 2.0D, mc.thePlayer.posZ)).getBlock() == Blocks.air;
	}

	public double getJumpBoostModifier(double baseJumpHeight) {
		if (mc.thePlayer.isPotionActive(Potion.jump)) {
			int amplifier = mc.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier();
			baseJumpHeight += (double)((float)(amplifier + 1) * 0.1F);
		}

		return baseJumpHeight;
	}

	public double round(double num, double increment) {
		if (increment < 0.0D) {
			throw new IllegalArgumentException();
		} else {
			BigDecimal bd = new BigDecimal(num);
			bd = bd.setScale((int)increment, RoundingMode.HALF_UP);
			return bd.doubleValue();
		}
	}

	public float getDirection() {

		float var1 = mc.thePlayer.rotationYaw;

		if (mc.thePlayer.moveForward < 0.0F) {
			var1 += 180.0F;
		}

		float forward = 1.0F;

		if (mc.thePlayer.moveForward < 0.0F) {
			forward = -0.5F;
		} else if (mc.thePlayer.moveForward > 0.0F) {
			forward = 0.5F;
		}

		if (mc.thePlayer.moveStrafing > 0.0F) {
			var1 -= 90.0F * forward;
		}

		if (mc.thePlayer.moveStrafing < 0.0F) {
			var1 += 90.0F * forward;
		}

		var1 *= 0.017453292F;
		return var1;
	}

}

