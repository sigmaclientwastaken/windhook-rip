package dev.windhook.module.modules.movement;

import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import org.lwjgl.input.Keyboard;

public class Sprint extends Module {

	public boolean override;
	ModeSetting mode = new ModeSetting("Mode", "Legit", "Legit", "Omni");

	public Sprint() {
		super("Sprint", "Automatically sprints for you!", Keyboard.KEY_NONE, Category.MOVEMENT);
		settings.add(mode);
	}

	@Override
	public void setup() {
		this.color = Color.MOVEMENT;
	}

	@Override
	public void onEnable() {
	}

	@Override
	public void onDisable() {
		if(!mc.gameSettings.keyBindSprint.isKeyDown()) {
			mc.thePlayer.setSprinting(false);
		}
	}

	@Override
	public void onUpdate(UpdateEvent event) {

		if(!override) {
			if (mode.is("Omni")) {
				if (mc.thePlayer.moveForward > 0) {
					mc.thePlayer.setSprinting(true);
				}
			}

			if (mode.is("Legit")) {
				if (mc.thePlayer.moveForward > 0 && !mc.thePlayer.isCollidedHorizontally && !mc.thePlayer.isSneaking() && !mc.thePlayer.isUsingItem()) {
					mc.thePlayer.setSprinting(true);
				}
			}
		}

	}

	@Override
	public void onMotion(MotionEvent event) {

	}
}