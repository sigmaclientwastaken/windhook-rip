package dev.windhook.module.modules.movement;

import org.lwjgl.input.Keyboard;

import dev.windhook.event.events.PacketReceivedEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;

public class TestModule extends Module {

	public TestModule() {
		super("TestModule", "This is a test module...", Keyboard.KEY_NONE, Category.MOVEMENT);
	}

	@Override
	public void setup() {
		this.color = Color.MOVEMENT;
	}

	@Override
	public void onEnable() {
	}

	@Override
	public void onDisable() {
	}

	@Override
	public void onUpdate(UpdateEvent event) {
	}

	@Override
	public void onPacketReceived(PacketReceivedEvent event) {
	}

}