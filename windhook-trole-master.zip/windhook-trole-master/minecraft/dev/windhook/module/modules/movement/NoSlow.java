package dev.windhook.module.modules.movement;

import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.SlowDownEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.utils.Timer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.lwjgl.input.Keyboard;

public class NoSlow extends Module {

    public static NoSlow instance;

    ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "NCP", "AAC", "OldHypixel");

    public NoSlow() {
        super("NoSlow", "Prevents items slowing you down!", Keyboard.KEY_NONE, Category.MOVEMENT);
        addSettings(mode);
        instance = this;
    }

    Timer timer = new Timer();

    @Override
    public void onMotion(MotionEvent event) {
        switch (mode.getMode()) {

            case "NCP": {
                if(mc.thePlayer.isBlocking() && isMoving() && isOnGround(0.42) && ModuleManager.newAura.kTarget == null){
                    if (event.isPre()) {
                        mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                    } else if (event.isPost()) {
                        mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));

                    }
                }

            }
            break;
            case "OldHypixel": {
                if(mc.thePlayer.isBlocking() && isMoving() && isOnGround(0.42) && ModuleManager.newAura.kTarget == null){
                    if (event.isPre()) {
                        mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                    } else if (event.isPost()) {
                        mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(getHypixelBlockpos(mc.getSession().getUsername()), 255, mc.thePlayer.inventory.getCurrentItem(), 0,0,0));

                    }
                }

            }
            break;

            case "AAC":{
                if(mc.thePlayer.isBlocking() && isMoving()){
                    if (event.isPre()) {
                        if(mc.thePlayer.onGround || isOnGround(0.5))
                            mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                    } else if (event.isPost()) {
                        if(timer.delay(65)){
                            mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
                            timer.reset();
                        }
                    }
                }
            }
            break;
        }
    }

    @Override
    public void onSlowDown(SlowDownEvent event) {

        if(mode.is("Vanilla")) {
            event.setCancelled(true);
        }

        if(mode.is("AAC")) {
            event.setSlowDownMultiplier((float) ((71-mc.thePlayer.itemInUseCount) * 0.008));
        }

    }

    public boolean isMoving() {
        if ((!mc.thePlayer.isCollidedHorizontally) && (!mc.thePlayer.isSneaking())) {
            return ((mc.thePlayer.movementInput.moveForward != 0.0F || mc.thePlayer.movementInput.moveStrafe != 0.0F));
        }
        return false;
    }

    public boolean isOnGround(double height) {
        return !mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0.0D, -height, 0.0D)).isEmpty();
    }

    public BlockPos getHypixelBlockpos(String str){
        int val = 89;
        if(str != null && str.length() > 1){
            char[] chs = str.toCharArray();

            for (char ch : chs)
                val += (int) ch * str.length() * str.length() + (int) str.charAt(0) + (int) str.charAt(1);
            val/=str.length();
        }
        return new BlockPos(val, -val%255, val);
    }

}
