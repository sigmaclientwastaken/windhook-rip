package dev.windhook.module.modules.movement.fly;

import dev.windhook.BaseClient;
import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.modules.movement.Fly;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C03PacketPlayer;

public class BlocksMCFastFly {

    // TODO: recode this
    // ModuleManager.fly.

    Minecraft mc = Minecraft.getMinecraft();
    BlocksMCFastFlyPhase blocksFastFlyPhase = BlocksMCFastFlyPhase.OFF;
    int blocksFastFlyTicks = 0;
    boolean damaged;

    public void onEnable() {
        blocksFastFlyPhase = BlocksMCFastFlyPhase.PRE;
        blocksFastFlyTicks = 0;
        if(!ModuleManager.pingSpoof.isToggled() || !ModuleManager.pingSpoof.mode.is("BlocksMC")){
            BaseClient.chatMessage("BlocksMC PingSpoof is recommended for this fly!");
        }
        ModuleManager.gameSpeed.setOverride(true);
    }

    public void onUpdate(UpdateEvent event) {
        if(blocksFastFlyPhase == BlocksMCFastFlyPhase.POST) {

       //     if(blocksFastFlyTicks < ModuleManager.fly.timerTicks.getValue()) {
       //         mc.timer.timerSpeed = (float) ModuleManager.fly.timerSpeed.getValue();
       //     } else {
       //         mc.timer.timerSpeed = 1f;
       //     }

            float yaw = (float) ModuleManager.fly.direction();
            mc.thePlayer.motionX = -Math.sin(yaw) * ModuleManager.fly.speed.getValue();
            mc.thePlayer.motionZ = Math.cos(yaw) * ModuleManager.fly.speed.getValue();
            mc.thePlayer.motionY = 0;

            blocksFastFlyTicks++;
        }

        if(blocksFastFlyPhase == BlocksMCFastFlyPhase.DAMAGE && !damaged) {
            mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 3.01, mc.thePlayer.posZ, false));
            mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false));
            mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, true));
            blocksFastFlyPhase = BlocksMCFastFlyPhase.POST;
            blocksFastFlyTicks = 0;
            damaged = true;
        }

        if(blocksFastFlyPhase == BlocksMCFastFlyPhase.DAMAGE || blocksFastFlyPhase == BlocksMCFastFlyPhase.PRE || blocksFastFlyPhase == BlocksMCFastFlyPhase.OFF) {

            mc.thePlayer.motionY = 0;
            mc.thePlayer.motionZ = 0;
            mc.thePlayer.motionX = 0;

        }
    }

    public void onPacketSent(PacketSentEvent event) {
        if(blocksFastFlyTicks >= 3) {
            blocksFastFlyPhase = BlocksMCFastFlyPhase.DAMAGE;
        }

        if(blocksFastFlyPhase == BlocksMCFastFlyPhase.PRE && event.getPacket() instanceof C03PacketPlayer) {
            event.setCancelled(true);
            blocksFastFlyTicks++;
            BaseClient.chatMessage("t");
        }
    }

    public void onDisable() {
        ModuleManager.gameSpeed.setOverride(false);
    }

    // TODO: this is dumb
    private enum BlocksMCFastFlyPhase {
        PRE,
        DAMAGE,
        POST,
        OFF
    }

}
