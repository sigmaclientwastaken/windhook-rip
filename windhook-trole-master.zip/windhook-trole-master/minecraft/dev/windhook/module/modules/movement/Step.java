package dev.windhook.module.modules.movement;

import dev.windhook.BaseClient;
import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

import java.awt.*;

public class Step extends Module {

    ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Intave", "NCP", "AAC3", "Legit", "Spartan");
    NumberSetting stepHeight = new NumberSetting("Step Height", 4, 1, 90, 0.5);

    public Step() {
        super("Step", "Allows you to step up blocks.", Keyboard.KEY_NONE, Category.MOVEMENT);
        addSettings(mode, stepHeight);
    }

    private boolean notGround = false;

    @Override
    public void onDisable() {
        mc.thePlayer.stepHeight = 0.5F;
        mc.timer.timerSpeed = 1.0f;
    }

    @Override
    public void onMotion(MotionEvent event) {
        double yaw = Math.toRadians(mc.thePlayer.rotationYaw);

        if(!(mc.thePlayer.onGround && mc.thePlayer.isCollidedHorizontally)) {
            return;
        }

        if(mode.is("Vanilla")) {
            mc.thePlayer.stepHeight = (float) stepHeight.value;
        }

        if(mode.is("Intave")) {
            if (mc.thePlayer.onGround) {
                mc.thePlayer.jump();
            } else {
                if (mc.thePlayer.motionY < 0.03) {
                    mc.thePlayer.motionY += 0.08;
                }
            }
            if (mc.thePlayer.motionY > 0.03) {

                mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.001, mc.thePlayer.posZ);
                mc.thePlayer.onGround = true;
                mc.thePlayer.motionX = -Math.sin(yaw) * 0.14;
                mc.thePlayer.motionZ = Math.cos(yaw) * 0.14;

            }
        }

        if(mode.is("Spartan")) {
            mc.timer.timerSpeed = 1F;
            mc.thePlayer.stepHeight = 0.1f;

            if (!mc.thePlayer.isCollidedHorizontally) {
                mc.timer.timerSpeed = 1F;
            } else {
                mc.timer.timerSpeed = 0.2F;
            }
            if (mc.thePlayer.isCollidedHorizontally && mc.thePlayer.onGround) {
                mc.thePlayer.jump();
            } else if (mc.thePlayer.isCollidedHorizontally && !mc.thePlayer.onGround
                    && mc.thePlayer.ticksExisted % 2 == 1) {
                mc.thePlayer.onGround = true;
                mc.thePlayer.jump();
            }
        }

        if(mode.is("AAC3")) {
            if (mc.thePlayer.onGround) {
                mc.thePlayer.jump();
            } else {
                if (mc.thePlayer.motionY < 0.03) {
                    mc.thePlayer.motionY += 0.08;
                }
            }
            if (mc.thePlayer.motionY > 0.03) {

                mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.001, mc.thePlayer.posZ);
                mc.thePlayer.onGround = true;
                mc.thePlayer.motionX = -Math.sin(yaw) * -0.05;
                mc.thePlayer.motionZ = Math.cos(yaw) * -0.05;
            }
        }

        if(mode.is("Legit")) {
            mc.thePlayer.jump();
        }

        if(mode.is("NCP")) {
            if (mc.thePlayer.isCollidedHorizontally && isMoving()) {
                if (mc.thePlayer.onGround) {
                    mc.thePlayer.motionY += .45;
                    notGround = false;
                }
            } else {
                mc.thePlayer.stepHeight = .6F;
                if (!notGround) {
                    if (mc.thePlayer.fallDistance >= .5) {
                        return;
                    }
                    mc.thePlayer.motionY += -10F;
                    notGround = true;
                }
            }
            mc.thePlayer.stepHeight = .5F;
            setSpeed(.4);
        }

    }

    public void setSpeed(double speed) {
        EntityPlayerSP player = Minecraft.getMinecraft().thePlayer;
        double yaw = (double) player.rotationYaw;
        boolean isMoving = player.moveForward != 0.0F || player.moveStrafing != 0.0F;
        boolean isMovingForward = player.moveForward > 0.0F;
        boolean isMovingBackward = player.moveForward < 0.0F;
        boolean isMovingRight = player.moveStrafing > 0.0F;
        boolean isMovingLeft = player.moveStrafing < 0.0F;
        boolean isMovingSideways = isMovingLeft || isMovingRight;
        boolean isMovingStraight = isMovingForward || isMovingBackward;
        if (isMoving) {
            if (isMovingForward && !isMovingSideways) {
                yaw += 0.0D;
            } else if (isMovingBackward && !isMovingSideways) {
                yaw += 180.0D;
            } else if (isMovingForward && isMovingLeft) {
                yaw += 45.0D;
            } else if (isMovingForward) {
                yaw -= 45.0D;
            } else if (!isMovingStraight && isMovingLeft) {
                yaw += 90.0D;
            } else if (!isMovingStraight && isMovingRight) {
                yaw -= 90.0D;
            } else if (isMovingBackward && isMovingLeft) {
                yaw += 135.0D;
            } else if (isMovingBackward) {
                yaw -= 135.0D;
            }

            yaw = Math.toRadians(yaw);
            player.motionX = -Math.sin(yaw) * speed;
            player.motionZ = Math.cos(yaw) * speed;
        }

    }

    public boolean isMoving() {
        return mc.thePlayer != null
                && (mc.thePlayer.movementInput.moveForward != 0F || mc.thePlayer.movementInput.moveStrafe != 0F);
    }

}