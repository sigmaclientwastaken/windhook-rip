package dev.windhook.module.modules.movement.fly;

import dev.windhook.BaseClient;
import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.utils.MovementUtil;
import dev.windhook.utils.Timer;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class AirBoostFly {

    // TODO: make fly modes system

    Minecraft mc = Minecraft.getMinecraft();

    public void onUpdate(UpdateEvent event) {
        if (mc.thePlayer.ticksExisted % 4 == 0) {
            mc.thePlayer.onGround = true;
            mc.thePlayer.motionY = 0.1;
        } else {
            mc.thePlayer.onGround = false;
        }
    }

}
