package dev.windhook.module.modules.render;

import dev.windhook.BaseClient;
import dev.windhook.event.events.GuiRenderEvent;
import dev.windhook.event.events.PreRender3DEvent;
import dev.windhook.event.events.RenderLivingLabelEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.modules.client.StreamerMode;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.utils.GLUtil;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

import javax.vecmath.Vector3d;
import javax.vecmath.Vector4d;
import java.awt.*;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL11.GL_BLEND;

public class ESP extends Module {

    public static ESP instance;

    ModeSetting mode = new ModeSetting("Mode", "2D", "2D", "MoonX");
    ModeSetting mode2d = new ModeSetting("2D Mode", "Box", "Box", "Corners");

    BooleanSetting outline = new BooleanSetting("Outline", true);
    BooleanSetting tag = new BooleanSetting("Tag", false);
    BooleanSetting health = new BooleanSetting("Health", true);
    BooleanSetting armor = new BooleanSetting("Armor", true);

    BooleanSetting localPlayer = new BooleanSetting("Bypass Value", true);

    BooleanSetting player = new BooleanSetting("Players", true);
    BooleanSetting invisible = new BooleanSetting("Invisible", true);
    BooleanSetting chest = new BooleanSetting("Chests", true);
    BooleanSetting item = new BooleanSetting("Items", false);

    NumberSetting chestWidth = new NumberSetting("Chest Line Width", 1.0, 0.2, 2, 0.1);
    NumberSetting chestAlpha = new NumberSetting("Chest Alpha", 255, 1, 255, 1);

    public ESP() {
        super("ESP", "Lets you see players.", Keyboard.KEY_NONE, Category.RENDER);
        addSettings(mode, mode2d, outline, tag, health, armor, localPlayer, player, invisible, chest, item);
        instance = this;
        this.collectedEntities = new ArrayList<>();
        this.viewport = GLAllocation.createDirectIntBuffer(16);
        this.modelview = GLAllocation.createDirectFloatBuffer(16);
        this.projection = GLAllocation.createDirectFloatBuffer(16);
        this.vector = GLAllocation.createDirectFloatBuffer(4);
        this.color = Color.WHITE.getRGB();
        this.backgroundColor = (new Color(0, 0, 0, 120)).getRGB();
        this.black = Color.BLACK.getRGB();
    }

    public final List<EntityLivingBase> collectedEntities;
    private final IntBuffer viewport;
    private final FloatBuffer modelview;
    private final FloatBuffer projection;
    private final FloatBuffer vector;
    private final int color;
    private final int backgroundColor;
    private final int black;

    @Override
    public void onRenderLivingLabel(RenderLivingLabelEvent event) {
        if (this.isValid(event.getEntity()) && this.tag.isEnabled()) {
            event.setCancelled(true);
        }
    }

    @Override
    public void onPreRender3D(PreRender3DEvent event) {

        if(mode.is("MoonX")) {
            if (chest.isEnabled()) {
                for (TileEntity tile : mc.theWorld.loadedTileEntityList) {
                    double posX = tile.getPos().getX() - mc.getRenderManager().getRenderPosX();
                    double posY = tile.getPos().getY() - mc.getRenderManager().getRenderPosY();
                    double posZ = tile.getPos().getZ() - mc.getRenderManager().getRenderPosZ();
                    if (tile instanceof TileEntityChest) {

                        AxisAlignedBB bb = new AxisAlignedBB(0.0625, 0.0, 0.0625, 0.94, 0.875, 0.94).offset(posX, posY, posZ);
                        TileEntityChest adjacent = null;
                        if (((TileEntityChest) tile).adjacentChestXNeg != null)
                            adjacent = ((TileEntityChest) tile).adjacentChestXNeg;
                        if (((TileEntityChest) tile).adjacentChestXPos != null)
                            adjacent = ((TileEntityChest) tile).adjacentChestXPos;
                        if (((TileEntityChest) tile).adjacentChestZNeg != null)
                            adjacent = ((TileEntityChest) tile).adjacentChestZNeg;
                        if (((TileEntityChest) tile).adjacentChestZPos != null)
                            adjacent = ((TileEntityChest) tile).adjacentChestZPos;
                        if (adjacent != null)
                            bb = bb.union(new AxisAlignedBB(0.0625, 0.0, 0.0625, 0.94, 0.875, 0.94).offset(adjacent.getPos().getX() - mc.getRenderManager().getRenderPosX(), adjacent.getPos().getY() - mc.getRenderManager().getRenderPosY(), adjacent.getPos().getZ() - mc.getRenderManager().getRenderPosZ()));

                        if (((TileEntityChest) tile).getChestType() == 1) {
                            drawBlockESP(bb, 255f, 91f, 86f, 255f, 1f);
                        } else {
                            drawBlockESP(bb, 255f, 227f, 0f, 255f, 1f);
                        }

                    }
                    if (tile instanceof TileEntityEnderChest) {
                        drawBlockESP(new AxisAlignedBB(0.0625, 0.0, 0.0625, 0.94, 0.875, 0.94).offset(posX, posY, posZ), 78f, 197f, 255f, (float) chestAlpha.getValue(), (float) chestWidth.getValue());
                    }
                }
            }
        }

        if(mode.is("MoonX")) {
            for(EntityPlayer entity : mc.theWorld.playerEntities) {
                if(entity == mc.thePlayer)
                    return;

                final double x = interpolate(entity.posX, entity.lastTickPosX, event.getPartialTicks());
                final double y = interpolate(entity.posY, entity.lastTickPosY, event.getPartialTicks());
                final double z = interpolate(entity.posZ, entity.lastTickPosZ, event.getPartialTicks());
                drawEntityESP(x - mc.getRenderManager().getRenderPosX(), y + entity.height + 0.1 - entity.height - mc.getRenderManager().getRenderPosY(), z - mc.getRenderManager().getRenderPosZ(), entity.height, 0.65,
                        (BaseClient.instance.getFriendsManager().isFriend(entity.getName())?
                                new Color(66, 255, 135) : new Color(196, 196, 196)));
            }
        }

    }

    @Override
    public void onGuiRender(GuiRenderEvent event) {

        if(mode.is("2D")) {
            GL11.glPushMatrix();
            this.collectEntities();
            float partialTicks = event.partialTicks;
            ScaledResolution scaledResolution = new ScaledResolution(mc);
            int scaleFactor = scaledResolution.getScaleFactor();
            double scaling = (double) scaleFactor / Math.pow(scaleFactor, 2.0D);
            GL11.glScaled(scaling, scaling, scaling);
            int black = this.black;
            int color = this.color;
            int background = this.backgroundColor;
            float scale = 0.65F;
            float upscale = 1.0F / scale;
            FontRenderer fr = mc.fontRendererObj;
            RenderManager renderMng = mc.getRenderManager();
            EntityRenderer entityRenderer = mc.entityRenderer;

            List<EntityLivingBase> collectedEntities = this.collectedEntities;
            int i = 0;

            for (int collectedEntitiesSize = collectedEntities.size(); i < collectedEntitiesSize; ++i) {
                EntityLivingBase entity = collectedEntities.get(i);
                if (this.isValid(entity) && isInViewFrustrum(entity)) {
                    double x = interpolate(entity.posX, entity.lastTickPosX, partialTicks);
                    double y = interpolate(entity.posY, entity.lastTickPosY, partialTicks);
                    double z = interpolate(entity.posZ, entity.lastTickPosZ, partialTicks);
                    double width = (double) entity.width / 1.5D;
                    double height = (double) entity.height + (entity.isSneaking() ? -0.3D : 0.2D);
                    AxisAlignedBB aabb = new AxisAlignedBB(x - width, y, z - width, x + width, y + height, z + width);
                    List<Vector3d> vectors = Arrays.asList(new Vector3d(aabb.minX, aabb.minY, aabb.minZ), new Vector3d(aabb.minX, aabb.maxY, aabb.minZ), new Vector3d(aabb.maxX, aabb.minY, aabb.minZ), new Vector3d(aabb.maxX, aabb.maxY, aabb.minZ), new Vector3d(aabb.minX, aabb.minY, aabb.maxZ), new Vector3d(aabb.minX, aabb.maxY, aabb.maxZ), new Vector3d(aabb.maxX, aabb.minY, aabb.maxZ), new Vector3d(aabb.maxX, aabb.maxY, aabb.maxZ));
                    entityRenderer.setupCameraTransform(partialTicks, 0);
                    Vector4d position = null;

                    for (Vector3d o : vectors) {
                        Vector3d vector = o;
                        vector = this.project2D(scaleFactor, vector.x - renderMng.viewerPosX, vector.y - renderMng.viewerPosY, vector.z - renderMng.viewerPosZ);
                        if (vector != null && vector.z >= 0.0D && vector.z < 1.0D) {
                            if (position == null) {
                                position = new Vector4d(vector.x, vector.y, vector.z, 0.0D);
                            }

                            position.x = Math.min(vector.x, position.x);
                            position.y = Math.min(vector.y, position.y);
                            position.z = Math.max(vector.x, position.z);
                            position.w = Math.max(vector.y, position.w);
                        }
                    }

                    if (position != null) {
                        entityRenderer.setupOverlayRendering();
                        double posX = position.x;
                        double posY = position.y;
                        double endPosX = position.z;
                        double endPosY = position.w;
                        if (outline.isEnabled()) {
                            if (mode2d.is("Box")) {
                                Gui.drawRect(posX - 1.0D, posY, posX + 0.5D, endPosY + 0.5D, black);
                                Gui.drawRect(posX - 1.0D, posY - 0.5D, endPosX + 0.5D, posY + 0.5D + 0.5D, black);
                                Gui.drawRect(endPosX - 0.5D - 0.5D, posY, endPosX + 0.5D, endPosY + 0.5D, black);
                                Gui.drawRect(posX - 1.0D, endPosY - 0.5D - 0.5D, endPosX + 0.5D, endPosY + 0.5D, black);
                                Gui.drawRect(posX - 0.5D, posY, posX + 0.5D - 0.5D, endPosY, color);
                                Gui.drawRect(posX, endPosY - 0.5D, endPosX, endPosY, color);
                                Gui.drawRect(posX - 0.5D, posY, endPosX, posY + 0.5D, color);
                                Gui.drawRect(endPosX - 0.5D, posY, endPosX, endPosY, color);
                            } else {
                                Gui.drawRect(posX + 0.5D, posY, posX - 1.0D, posY + (endPosY - posY) / 4.0D + 0.5D, black);
                                Gui.drawRect(posX - 1.0D, endPosY, posX + 0.5D, endPosY - (endPosY - posY) / 4.0D - 0.5D, black);
                                Gui.drawRect(posX - 1.0D, posY - 0.5D, posX + (endPosX - posX) / 3.0D + 0.5D, posY + 1.0D, black);
                                Gui.drawRect(endPosX - (endPosX - posX) / 3.0D - 0.5D, posY - 0.5D, endPosX, posY + 1.0D, black);
                                Gui.drawRect(endPosX - 1.0D, posY, endPosX + 0.5D, posY + (endPosY - posY) / 4.0D + 0.5D, black);
                                Gui.drawRect(endPosX - 1.0D, endPosY, endPosX + 0.5D, endPosY - (endPosY - posY) / 4.0D - 0.5D, black);
                                Gui.drawRect(posX - 1.0D, endPosY - 1.0D, posX + (endPosX - posX) / 3.0D + 0.5D, endPosY + 0.5D, black);
                                Gui.drawRect(endPosX - (endPosX - posX) / 3.0D - 0.5D, endPosY - 1.0D, endPosX + 0.5D, endPosY + 0.5D, black);
                                Gui.drawRect(posX, posY, posX - 0.5D, posY + (endPosY - posY) / 4.0D, color);
                                Gui.drawRect(posX, endPosY, posX - 0.5D, endPosY - (endPosY - posY) / 4.0D, color);
                                Gui.drawRect(posX - 0.5D, posY, posX + (endPosX - posX) / 3.0D, posY + 0.5D, color);
                                Gui.drawRect(endPosX - (endPosX - posX) / 3.0D, posY, endPosX, posY + 0.5D, color);
                                Gui.drawRect(endPosX - 0.5D, posY, endPosX, posY + (endPosY - posY) / 4.0D, color);
                                Gui.drawRect(endPosX - 0.5D, endPosY, endPosX, endPosY - (endPosY - posY) / 4.0D, color);
                                Gui.drawRect(posX, endPosY - 0.5D, posX + (endPosX - posX) / 3.0D, endPosY, color);
                                Gui.drawRect(endPosX - (endPosX - posX) / 3.0D, endPosY - 0.5D, endPosX - 0.5D, endPosY, color);
                            }
                        }

                        EntityLivingBase entityLivingBase;
                        float armorValue;
                        float itemDurability;
                        double durabilityWidth;
                        double textWidth;
                        float tagY;
                        entityLivingBase = entity;
                        if (health.isEnabled()) {
                            armorValue = entityLivingBase.getHealth();
                            itemDurability = entityLivingBase.getMaxHealth();
                            if (armorValue > itemDurability) {
                                armorValue = itemDurability;
                            }

                            durabilityWidth = armorValue / itemDurability;
                            textWidth = (endPosY - posY) * durabilityWidth;
                            Gui.drawRect(posX - 3.5D, posY - 0.5D, posX - 1.5D, endPosY + 0.5D, background);
                            if (armorValue > 0.0F) {
                                int healthColor = getHealthColor(armorValue, itemDurability).getRGB();
                                Gui.drawRect(posX - 3.0D, endPosY, posX - 2.0D, endPosY - textWidth, healthColor);
                                tagY = entityLivingBase.getAbsorptionAmount();
                                if (tagY > 0.0F) {
                                    Gui.drawRect(posX - 3.0D, endPosY, posX - 2.0D, endPosY - (endPosY - posY) / 6.0D * (double) tagY / 2.0D, (new Color(Potion.absorption.getLiquidColor())).getRGB());
                                }
                            }
                        }

                        if (tag.isEnabled()) {
                            float scaledHeight = 10.0F;
                            String name = entity.getName();

                            String prefix = "";
                            if (entity instanceof EntityPlayer) {
                                prefix = this.isFriendly((EntityPlayer) entity) ? "§a" : "§c";
                            }

                            if (StreamerMode.instance.isToggled()) {
                                name = "Enemy";
                                if (prefix.equals("§a")) {
                                    name = "Friend";
                                } else if (entity instanceof EntityPlayerSP) {
                                    name = "You";
                                }
                            }

                            durabilityWidth = (endPosX - posX) / 2.0D;
                            textWidth = (float) fr.getStringWidth(name) * scale;
                            float tagX = (float) ((posX + durabilityWidth - textWidth / 2.0D) * (double) upscale);
                            tagY = (float) (posY * (double) upscale) - scaledHeight;
                            GL11.glPushMatrix();
                            GL11.glScalef(scale, scale, scale);
                            Gui.drawRect(tagX - 2.0F, tagY - 2.0F, (double) tagX + textWidth * (double) upscale + 2.0D, tagY + 9.0F, (new Color(0, 0, 0, 140)).getRGB());

                            fr.drawStringWithShadow(prefix + name, tagX, tagY, -1);
                            GL11.glPopMatrix();
                        }

                        if (armor.isEnabled()) {
                            double right = posX - 0.5D + endPosX - posX + 1.0D;
                            armorValue = (float) entityLivingBase.getTotalArmorValue();
                            double armorWidth = (endPosX - posX) * (double) armorValue / 20.0D;
                            Gui.drawRect(posX - 0.5D, endPosY + 1.5D, right, endPosY + 1.5D + 2.0D, background);
                            if (armorValue > 0.0F) {
                                Gui.drawRect(posX, endPosY + 2.0D, posX + armorWidth, endPosY + 3.0D, 16777215);
                            }
                        }
                    }
                }
            }

            GL11.glPopMatrix();
            GlStateManager.enableBlend();
            entityRenderer.setupOverlayRendering();
        }


    }

    private boolean isFriendly(EntityPlayer player) {
        return isOnSameTeam(player) || BaseClient.instance.getFriendsManager().isFriend(player.getName());
    }

    private void collectEntities() {
        this.collectedEntities.clear();
        List<Entity> playerEntities = mc.theWorld.loadedEntityList;
        int i = 0;

        for(int playerEntitiesSize = playerEntities.size(); i < playerEntitiesSize; ++i) {
            Entity entity = playerEntities.get(i);
            if (this.isValid(entity)) {
                this.collectedEntities.add((EntityLivingBase) entity);
            }
        }

    }

    private Vector3d project2D(int scaleFactor, double x, double y, double z) {
        GL11.glGetFloat(2982, this.modelview);
        GL11.glGetFloat(2983, this.projection);
        GL11.glGetInteger(2978, this.viewport);
        return GLU.gluProject((float)x, (float)y, (float)z, this.modelview, this.projection, this.viewport, this.vector) ? new Vector3d(this.vector.get(0) / (float)scaleFactor, ((float)Display.getHeight() - this.vector.get(1)) / (float)scaleFactor, this.vector.get(2)) : null;
    }

    private boolean isValid(Entity entity) {
        if (entity != mc.thePlayer || this.localPlayer.isEnabled() && mc.gameSettings.thirdPersonView != 0) {
            if (entity.isDead) {
                return false;
            } else if (!this.invisible.isEnabled() && entity.isInvisible()) {
                return false;
            } else if (this.item.isEnabled() && entity instanceof EntityItem && mc.thePlayer.getDistanceToEntity(entity) < 10.0F) {
                return true;
            } else return this.player.isEnabled() && entity instanceof EntityPlayer;
        } else {
            return false;
        }
    }

    public boolean isOnSameTeam(EntityPlayer entity) {
        if (entity.getTeam() != null && mc.thePlayer.getTeam() != null) {
            char c1 = entity.getDisplayName().getFormattedText().charAt(1);
            char c2 = mc.thePlayer.getDisplayName().getFormattedText().charAt(1);
            return c1 == c2;
        } else {
            return false;
        }
    }

    public boolean isInViewFrustrum(Entity entity) {
        return isInViewFrustrum(entity.getEntityBoundingBox()) || entity.ignoreFrustumCheck;
    }

    private boolean isInViewFrustrum(AxisAlignedBB bb) {
        Frustum frustrum = new Frustum();
        Entity current = mc.getRenderViewEntity();
        frustrum.setPosition(current.posX, current.posY, current.posZ);
        return frustrum.isBoundingBoxInFrustum(bb);
    }

    public static double interpolate(double current, double old, double scale) {
        return old + (current - old) * scale;
    }

    public static Color getHealthColor(float health, float maxHealth) {
        float[] fractions = new float[]{0.0F, 0.5F, 1.0F};
        Color[] colors = new Color[]{new Color(108, 0, 0), new Color(255, 51, 0), Color.GREEN};
        float progress = health / maxHealth;
        return blendColors(fractions, colors, progress).brighter();
    }

    public static Color blendColors(float[] fractions, Color[] colors, float progress) {
        if (fractions.length == colors.length) {
            int[] indices = getFractionIndices(fractions, progress);
            float[] range = new float[]{fractions[indices[0]], fractions[indices[1]]};
            Color[] colorRange = new Color[]{colors[indices[0]], colors[indices[1]]};
            float max = range[1] - range[0];
            float value = progress - range[0];
            float weight = value / max;
            return blend(colorRange[0], colorRange[1], 1.0F - weight);
        } else {
            throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
        }
    }

    public static int[] getFractionIndices(float[] fractions, float progress) {
        int[] range = new int[2];

        int startPoint;
        for(startPoint = 0; startPoint < fractions.length && fractions[startPoint] <= progress; ++startPoint) {
        }

        if (startPoint >= fractions.length) {
            startPoint = fractions.length - 1;
        }

        range[0] = startPoint - 1;
        range[1] = startPoint;
        return range;
    }

    public static Color blend(Color color1, Color color2, double ratio) {
        float r = (float)ratio;
        float ir = 1.0F - r;
        float[] rgb1 = color1.getColorComponents(new float[3]);
        float[] rgb2 = color2.getColorComponents(new float[3]);
        float red = rgb1[0] * r + rgb2[0] * ir;
        float green = rgb1[1] * r + rgb2[1] * ir;
        float blue = rgb1[2] * r + rgb2[2] * ir;
        if (red < 0.0F) {
            red = 0.0F;
        } else if (red > 255.0F) {
            red = 255.0F;
        }

        if (green < 0.0F) {
            green = 0.0F;
        } else if (green > 255.0F) {
            green = 255.0F;
        }

        if (blue < 0.0F) {
            blue = 0.0F;
        } else if (blue > 255.0F) {
            blue = 255.0F;
        }

        Color color3 = null;

        try {
            color3 = new Color(red, green, blue);
        } catch (IllegalArgumentException ignored) {
        }

        return color3;
    }

    private void drawBlockESP(AxisAlignedBB bb, float red, float green, float blue, float alpha,float width) {
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glDisable(3553);
        GL11.glEnable(2848);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glColor4f(red / 255f, green / 255f, blue / 255f, (alpha / 255) * 0.2f);
        drawBoundingBox(bb);
        GL11.glLineWidth(width);
        GL11.glColor4f(red / 255f, green / 255f, blue / 255f, alpha / 255f);
        drawOutlinedBoundingBox(bb);
        GL11.glDisable(2848);
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glPopMatrix();
        GL11.glColor4f(1f, 1f, 1f, 1f);
    }

    public static void drawOutlinedBoundingBox(AxisAlignedBB aa) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        worldRenderer.begin(3, DefaultVertexFormats.POSITION);
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(3, DefaultVertexFormats.POSITION);
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(1, DefaultVertexFormats.POSITION);
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        tessellator.draw();

    }

    public static void drawBoundingBox(AxisAlignedBB aa) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        tessellator.draw();
    }

    private void drawEntityESP(double x, double y, double z, double height, double width, Color color) {
        GL11.glPushMatrix();
        GLUtil.setGLCap(3042, true);
        GLUtil.setGLCap(3553, false);
        GLUtil.setGLCap(2896, false);
        GLUtil.setGLCap(2929, false);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1.8f);
        GL11.glBlendFunc(770, 771);
        GLUtil.setGLCap(2848, true);
        GL11.glDepthMask(true);
        BB(new AxisAlignedBB(x - width + 0.25, y, z - width + 0.25, x + width - 0.25, y + height, z + width - 0.25), new Color(color.getRed(), color.getGreen(), color.getBlue(), 120).getRGB());
        OutlinedBB(new AxisAlignedBB(x - width + 0.25, y, z - width + 0.25, x + width - 0.25, y + height, z + width - 0.25), 1, color.getRGB());
        GLUtil.revertAllCaps();
        GL11.glPopMatrix();
        GL11.glColor4f(1, 1, 1, 1);
    }

    public void OutlinedBB(AxisAlignedBB bb, float width, int color) {
        enable3D();
        glLineWidth(width);
        color(color);
        drawOutlinedBoundingBox(bb);
        disable3D();
    }

    public void BB(AxisAlignedBB bb, int color) {
        enable3D();
        color(color);
        drawBoundingBox(bb);
        disable3D();
    }

    public void enable3D() {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_TEXTURE_2D);
        glEnable(GL_LINE_SMOOTH);
        glDisable(GL_DEPTH_TEST);
        glDepthMask(false);
    }

    public void disable3D() {
        glDisable(GL_LINE_SMOOTH);
        glEnable(GL_TEXTURE_2D);
        glEnable(GL_DEPTH_TEST);
        glDepthMask(true);
        glDisable(GL_BLEND);
    }

    public void color(int color) {
        GL11.glColor4f((color >> 16 & 0xFF) / 255f, (color >> 8 & 0xFF) / 255f, (color & 0xFF) / 255f, (color >> 24 & 0xFF) / 255f);
    }

}
