package dev.windhook.module.modules.render;

import dev.windhook.module.Category;
import dev.windhook.module.Module;
import org.lwjgl.input.Keyboard;

public class AntiOverlay extends Module {

    public AntiOverlay() {
        super("AntiOverlay", "Removes the vignette overlay.", Keyboard.KEY_NONE, Category.RENDER);
    }

}
