package dev.windhook.module.modules.render;

import dev.windhook.event.events.Render2DEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;

public class Animations extends Module {

    public ModeSetting mode = new ModeSetting("Mode", "1.7", "1.7", "Astro", "Exhi", "Slide", "Fanta", "Flux",
                                                "Astolfo", "Sigma");
    public NumberSetting    x = new NumberSetting("X", 0, -0.5, 0.5, 0.05),
                            y = new NumberSetting("Y", 0, -0.5, 0.5, 0.05),
                            z = new NumberSetting("Scale", 0, -0.5, 0.5, 0.05);

    public Animations() {
        super("Animations", "Modifies how your held item looks.", Keyboard.KEY_NONE, Category.RENDER);
        addSettings(mode, x, y, z);
    }

}
