package dev.windhook.module.modules.render;

import dev.windhook.event.events.HurtcamEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import org.lwjgl.input.Keyboard;

public class NoHurtcam extends Module {

    public NoHurtcam() {
        super("NoHurtcam", "Removes the vignette overlay.", Keyboard.KEY_NONE, Category.RENDER);
    }

    @Override
    public void onHurtcam(HurtcamEvent event) {
        event.setCancelled(true);
    }
}
