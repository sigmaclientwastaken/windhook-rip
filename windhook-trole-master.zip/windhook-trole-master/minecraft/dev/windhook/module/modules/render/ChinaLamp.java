package dev.windhook.module.modules.render;

import dev.windhook.event.events.Render3DEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.utils.Timer;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class ChinaLamp extends Module {

    ModeSetting mode = new ModeSetting("Quality", "High", "High", "Low", "wtf");
    BooleanSetting firstPerson = new BooleanSetting("First Person", false);
    BooleanSetting lamp = new BooleanSetting("Lamp", true);
    BooleanSetting byebye = new BooleanSetting("Bye Bye", true);

    Timer byebyetimer = new Timer();

    public ChinaLamp() {
        super("ChinaLamp", "china lamp china lamp", Keyboard.KEY_NONE, Category.RENDER);
        settings.add(mode);
        settings.add(firstPerson);
        settings.add(lamp);
        settings.add(byebye);
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if(mc.gameSettings.thirdPersonView == 0 && !firstPerson.isEnabled()) return;

        if(byebyetimer.hasReached(5000))
            byebyetimer.reset();

        float radius = 0.75F;
        for(int i = 0; i < (mode.is("wtf")? 1 : (mode.is("High")? 360*2 : 360)); i++) {
            float dX = radius*(float) Math.cos(Math.toRadians(i));
            float dZ = radius*(float) Math.sin(Math.toRadians(i));
            float minus = mc.thePlayer.isSneaking() ? 0.3F : 0;
            float lampoffset = lamp.isEnabled() ? (float) 0.2 : 0;
            float byebyeoffset = byebye.isEnabled()? byebyetimer.getTimePassed()/2000f : 0;
            GlStateManager.pushMatrix();
            draw3dLine(0, 2.25 - minus + byebyeoffset + (lamp.isEnabled()? 1 : 0), 0, dX, 1.9 - minus - (lamp.isEnabled()? 0.5 : 0) + byebyeoffset, dZ, getColorAlpha(rainBowEffectWithOffset(i, 3600), 110));
            GlStateManager.popMatrix();
        }


    }

    public static Color rainBowEffectWithOffset(int offset, float custom) {
        long l = System.currentTimeMillis() - (offset * 10L);
        int i = Color.HSBtoRGB(l % (int) custom / custom, 1F, 1F);
        return (new Color(i));
    }

    public static Color getColorAlpha(Color color, int alpha) {
        return getColorAlpha(color.getRGB(), alpha);
    }

    public static Color getColorAlpha(int color, int alpha) {
        return new Color(new Color(color).getRed(), new Color(color).getGreen(), new Color(color).getBlue(),
                alpha);
    }

    public static void draw3dLine(double x, double y, double z, double x1, double y1, double z1, Color color) {
        GlStateManager.pushMatrix();
        if (true) {
            GL11.glDepthMask(false);
            GL11.glDisable(2929);
        }
        GL11.glDisable(3008);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glLineWidth(1.0F);
        glColor(color.getRGB());
        GL11.glBegin(1);
        GL11.glVertex3d(x, y, z);
        GL11.glVertex3d(x1, y1, z1);
        GL11.glEnd();
        if (true) {
            GL11.glDepthMask(true);
            GL11.glEnable(2929);
        }
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glEnable(3008);
        GL11.glDisable(2848);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.popMatrix();
    }

    public static void glColor(int hex) {
        float alpha = (float) (hex >> 24 & 255) / 255F;
        float red = (float) (hex >> 16 & 255) / 255F;
        float green = (float) (hex >> 8 & 255) / 255F;
        float blue = (float) (hex & 255) / 255F;
        GL11.glColor4f(red, green, blue, alpha);
    }

}
