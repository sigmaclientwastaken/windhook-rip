package dev.windhook.module.modules.render;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.function.Function;

import com.google.common.collect.Lists;
import dev.windhook.BaseClient;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ListSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.module.settings.Setting;
import org.lwjgl.input.Keyboard;

import dev.windhook.event.events.BlockBrightnessRequestEvent;
import dev.windhook.event.events.BlockRenderEvent;
import dev.windhook.event.events.FluidRenderEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;

public class XRay extends Module {

	public NumberSetting opacity = new NumberSetting("Opacity", 100, 1, 255, 1);
	BooleanSetting exceptions = new BooleanSetting("Exceptions", false);

	private static final HashSet<Integer> blockIDs = new HashSet<Integer>();
	public ArrayList<Integer> KEY_IDS;

	public XRay() {
		super("XRay", "See only specific blocks", Keyboard.KEY_X, Category.RENDER);
		addSettings(opacity, exceptions);
		this.KEY_IDS = Lists.newArrayList(10, 11, 8, 9, 14, 15, 16, 21, 41, 42, 46, 48, 52, 56, 57, 61, 62, 73, 74, 84, 89, 103, 116, 117, 118, 120, 129, 133, 137, 145, 152, 153, 154);
	}

	@Override
	public void setup() {
		this.color = Color.RENDER;
	}

	@Override
	public void onEnable() {
		mc.renderGlobal.loadRenderers();
		blockIDs.clear();
		try {
			blockIDs.addAll(this.KEY_IDS);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onDisable() {
		mc.renderGlobal.loadRenderers();
	}

	public boolean containsID(int id) {
		return exceptions.isEnabled() && blockIDs.contains(id);
	}


	public ArrayList<Integer> get() {
		return KEY_IDS;
	}


}
