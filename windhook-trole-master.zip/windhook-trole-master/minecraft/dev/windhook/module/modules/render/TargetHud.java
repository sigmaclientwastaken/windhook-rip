package dev.windhook.module.modules.render;

import dev.windhook.BaseClient;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.modules.combat.Aura;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.utils.RenderUtils;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

import java.awt.*;
import java.util.ArrayList;

public class TargetHud extends Module {

    public ModeSetting mode = new ModeSetting("Mode", "HvH", "HvH", "Normal");
    BooleanSetting absorption = new BooleanSetting("Absorption", false);

    public TargetHud() {
        super("TargetHUD", "Shows information about your current target(s).", Keyboard.KEY_NONE, Category.RENDER);
        addSettings(mode);
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        ScaledResolution sr = new ScaledResolution(mc);
        EntityLivingBase target = Aura.target;


        if(mode.is("HvH")) {

            if(target == null) {
                return;
            }

            Gui.drawRect(sr.getScaledWidth() / 2 + 3, sr.getScaledHeight() / 2 + 2, (int) ((sr.getScaledWidth() / 2 + 3) + target.getHealth() * 5), sr.getScaledHeight() / 2 + 17, 0xaadd1010);
        }

        if(mode.is("Normal")) {

            int x = sr.getScaledWidth() / 2 + 15;
            int y = sr.getScaledHeight() / 2 - 25;

            drawRoundedRect(x, y, 200, 50, 7, new Color(34, 34, 34).getRGB());

            EntityLivingBase displayTarget = target == null? mc.thePlayer : target;

            UnicodeFontRenderer fr = BaseClient.getInstance().getFont().getFont(26);

            fr.drawString(displayTarget.getName(),
                    x + (100 - (fr.getStringWidth(displayTarget.getName())/2)),
                    y + 6, -1, true);

            // Health main
            /// Health check
            if(displayTarget.getHealth() < 0) {
                //// NULL

                // Health background
                drawRoundedRect(x + 10, y + 25, 180, 20, 10, new Color(236, 107, 107).getRGB());
            } else {
                //// NOT NULL

                // Health background
                drawRoundedRect(x + 10, y + 25, 180, 20, 10, new Color(236, 107, 107).getRGB());


                double flag = absorption.isEnabled() ? (displayTarget.getHealth() + displayTarget.getAbsorptionAmount()) / (displayTarget.getMaxHealth() + displayTarget.getAbsorptionAmount()) : displayTarget.getHealth() / displayTarget.getMaxHealth();
                drawRoundedRect(x + 10, y + 25, (float) (180*flag), 20, 10, new Color(196, 34, 34).getRGB());
            }

        }

    }

    private final int NORMAL_TARGETHUD_HEIGHT = 80;
    private void drawNormalTargetHud(int x, int y, EntityLivingBase target) {


    }

    private enum Amount {
        NONE,
        SINGLE,
        DOUBLE
    }

    public static void drawRoundedRect(float x, float y, float width, float height, int roundFactor, int color) {
        GlStateManager.pushMatrix();
        drawCircle(x + height / roundFactor, y + height / roundFactor, height / roundFactor, color);
        drawCircle(x + height / roundFactor, y + height - height / roundFactor, height / roundFactor, color);
        drawCircle(x + width - height / roundFactor, y + height / roundFactor, height / roundFactor, color);
        drawCircle(x + width - height / roundFactor, y + height - height / roundFactor, height / roundFactor, color);
        Gui.drawRect( (int) x, (int) (y + height / roundFactor), (int) (x + width), (int) (y + height - height / roundFactor), color);
        Gui.drawRect((int) (x + height / roundFactor), (int) y, (int) (x + width - height / roundFactor), (int) (y + height), color);
        GlStateManager.popMatrix();
    }

    public static void drawCircle(double x, double y, double radius, int color) {
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBegin(GL11.GL_POLYGON);
        glColor(color);
        for (int i = 0; i <= 360; i++) {
            double x2 = Math.sin(((i * Math.PI) / 180)) * radius;
            double y2 = Math.cos(((i * Math.PI) / 180)) * radius;
            GL11.glVertex2d(x + x2, y + y2);
        }
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
    }

    public static void glColor(int hex) {
        float alpha = (float) (hex >> 24 & 255) / 255F;
        float red = (float) (hex >> 16 & 255) / 255F;
        float green = (float) (hex >> 8 & 255) / 255F;
        float blue = (float) (hex & 255) / 255F;
        GL11.glColor4f(red, green, blue, alpha);
    }

}
