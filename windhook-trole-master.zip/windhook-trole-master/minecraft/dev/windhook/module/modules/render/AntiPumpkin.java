package dev.windhook.module.modules.render;

import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import org.lwjgl.input.Keyboard;

public class AntiPumpkin extends Module {

    public AntiPumpkin() {
        super("AntiPumpkin", "Removes the pumpkin overlay.", Keyboard.KEY_NONE, Category.RENDER);
    }

}
