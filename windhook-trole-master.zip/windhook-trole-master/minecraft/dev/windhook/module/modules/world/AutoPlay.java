package dev.windhook.module.modules.world;

import dev.windhook.BaseClient;
import dev.windhook.event.events.MessageReceivedEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;

public class AutoPlay extends Module {

    BooleanSetting minemoraRejoin = new BooleanSetting("Minemora AP", true);
    ModeSetting autoregister = new ModeSetting("Auto Register", "None", "None", "Minemora");

    public AutoPlay() {
        super("AutoPlay", "description", 0, Category.WORLD);
        addSettings(minemoraRejoin, autoregister);
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if(event.getMessage().toUpperCase().contains("NUEVA PARTIDA") && minemoraRejoin.isEnabled()) {
            BaseClient.chatMessage("Rejoined!");
            mc.thePlayer.sendChatMessage("/join");
        }

        if(event.getMessage().toLowerCase().contains("/register") && autoregister.is("Minemora")) {
            mc.thePlayer.sendChatMessage("/register WindHook WindHook");
            BaseClient.chatMessage("Registered! PASS: WindHook");

        }
    }

}
