package dev.windhook.module.modules.world;

import dev.windhook.BaseClient;
import dev.windhook.event.events.MessageReceivedEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;

public class Alerter extends Module {

    BooleanSetting hunterRequeue = new BooleanSetting("Hunter Requeue", false);

    public Alerter() {
        super("Alerter", "description", 0, Category.WORLD);
        addSettings(hunterRequeue);
    }

    boolean inGame = false;

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if(event.getMessage().toLowerCase().contains("hunter171") || event.getMessage().toLowerCase().contains("hunter")) {
            BaseClient.chatMessage("ALERT");

            if(hunterRequeue.isEnabled() && inGame) {
                inGame = false;
                mc.thePlayer.sendChatMessage("/leave");
            }
        }

        if(event.getMessage().toLowerCase().contains("wind")) {
            BaseClient.chatMessage("ALERT");
        }

        if(!inGame) {
            if(event.getMessage().toLowerCase().contains("adquiere rango")) {
                inGame = true;
                return;
            }

            if(hunterRequeue.isEnabled()) {
                mc.thePlayer.sendChatMessage("/join");
            }
        }
    }

}
