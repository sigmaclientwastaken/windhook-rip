package dev.windhook.module.modules.world;

import dev.windhook.BaseClient;
import dev.windhook.command.commands.NamesCommand;
import dev.windhook.event.events.*;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.utils.Strings;
import dev.windhook.utils.Timer;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.play.server.S02PacketChat;
import org.lwjgl.input.Keyboard;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class KillSults extends Module {

	ModeSetting mode = new ModeSetting("Mode", "Autumn", "Autumn");
	BooleanSetting antiSpam = new BooleanSetting("AntiSpam", false);

	String last;

	Timer delay = new Timer();

	final String[] autumn = {"%s go eat estrogen femtard", "%s, KANKER AAP",
			"how did %s even hit the launch game button", "report me %s im really scared",
			"why is this fat retard %s begging me to turn off my hacks", "sorry %s, this bypass value is exclusive",
			"%s seriously? go back to cubecraft monkey brain", "Stop crying %s or ill put you back in your cage",
			"%s how big are your balls? bet they aren't as big as recons"};

	public KillSults() {
		super("KillSults", "Hide players names", Keyboard.KEY_NONE, Category.WORLD);
		addSettings(mode, antiSpam);
	}

	@Override
	public void onMessageReceived(MessageReceivedEvent event) {
		if(isKill(event.getMessage())) {
			if(delay() || last == null)
				return;

			if(mode.is("Autumn")) {
				mc.thePlayer.sendChatMessage(get(autumn));
			}

			delay.reset();
			last = null;

		}
	}

	@Override
	public void onUpdate(UpdateEvent event) {
		if(ModuleManager.newAura.kTarget != null && (ModuleManager.newAura.kTarget.getHealth() < 5 || ModuleManager.newAura.kTarget.isDead)) {
			last = ModuleManager.newAura.kTarget.getName();
		}
	}

	public boolean isKill(String txt) {
		return txt.contains(mc.thePlayer.getName());
	}

	public String getRandom(String[] array) {
		int rnd = new Random().nextInt(array.length);
		return array[rnd];
	}

	public String get(String[] array) {
		return getRandom(array).replaceAll("%s", last);
	}

	public boolean delay() {
		return (!antiSpam.isEnabled()) || (delay.hasReached(3000, false));
	}
}