package dev.windhook.module.modules.world;

import dev.windhook.BaseClient;
import dev.windhook.command.commands.NamesCommand;
import dev.windhook.event.events.*;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.utils.MovementUtil;
import dev.windhook.utils.Strings;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

import java.util.HashMap;
import java.util.Map;

public class SetPosition extends Module {

	public Vec3 POSITION;

	public SetPosition() {
		super("SetPosition", "Hide players names", Keyboard.KEY_NONE, Category.WORLD);
	}

	Vec3 position;
	boolean ground;

	@Override
	public void onEnable() {
		mc.thePlayer.setSprinting(false);
		position = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
		ground = mc.thePlayer.onGround;
	}

	@Override
	public void onDisable() {
		POSITION = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
		mc.thePlayer.setPositionAndUpdate(position.xCoord, position.yCoord, position.zCoord);
		position = null;
	}

	@Override
	public void onPacketSent(PacketSentEvent event) {
		if(position != null) {

			if(event.getPacket() instanceof C0BPacketEntityAction){
				if(((C0BPacketEntityAction) event.getPacket()).getAction() == C0BPacketEntityAction.Action.START_SPRINTING || ((C0BPacketEntityAction) event.getPacket()).getAction() == C0BPacketEntityAction.Action.STOP_SPRINTING) {
					event.setCancelled(true);
				}
			}

			if(!event.isCancelled()) {
				if(event.getPacket() instanceof C03PacketPlayer) {
					((C03PacketPlayer) event.getPacket()).y = position.yCoord;
					((C03PacketPlayer) event.getPacket()).x = position.xCoord;
					((C03PacketPlayer) event.getPacket()).z = position.zCoord;
					((C03PacketPlayer) event.getPacket()).moving = false;
					((C03PacketPlayer) event.getPacket()).onGround = ground;
				}
			}

		}
	}

	@Override
	public void onMotion(MotionEvent event) {
		if(position != null) {
			if (MovementUtil.areMovementKeysPressed()) {
				MovementUtil.setSpeed((float) 2);
			} else {
				mc.thePlayer.motionX = 0;
				mc.thePlayer.motionZ = 0;
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
				mc.thePlayer.motionY = 2;
			} else if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
				mc.thePlayer.motionY = -2;
			} else {
				mc.thePlayer.motionY = 0;
			}
		}
	}
}