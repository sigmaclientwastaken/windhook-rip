package dev.windhook.module.modules.ghost;

import dev.windhook.BaseClient;
import dev.windhook.event.events.*;
import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.modules.combat.AutoGapple;
import dev.windhook.module.modules.combat.AutoHeal;
import dev.windhook.module.modules.combat.Criticals;
import dev.windhook.module.modules.movement.Speed;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.utils.GLUtil;
import dev.windhook.utils.Timer;
import net.minecraft.block.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.potion.Potion;
import net.minecraft.util.*;
import optfine.Reflector;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.List;

import static org.lwjgl.opengl.GL11.*;

public class LegitAura extends Module {

    public static LegitAura instance;

    public static EntityLivingBase target;
    private List<EntityLivingBase> targets = new ArrayList<>();
    
    NumberSetting cps = new NumberSetting("CPS", 1, 1, 20, 7);
    NumberSetting range = new NumberSetting("Range", 4.2, 1.0, 7.0, 0.1);
    NumberSetting blockrange = new NumberSetting("Block Range", 7.0, 1.0, 15.0, 0.1);
    NumberSetting maxTargets = new NumberSetting("Max Targets", 3, 1, 5, 1);
    NumberSetting switchSpeed = new NumberSetting("Switch Speed", 300, 100, 1000, 50);
    BooleanSetting players = new BooleanSetting("Players", true);
    BooleanSetting animals = new BooleanSetting("Animals", false);
    BooleanSetting monsters = new BooleanSetting("Monsters", false);
    BooleanSetting invisibles = new BooleanSetting("Invisibles", false);
    BooleanSetting autoblock = new BooleanSetting("AutoBlock", true);
    BooleanSetting dynamic = new BooleanSetting("Dynamic", true);
    BooleanSetting targetesp = new BooleanSetting("Target ESP", true);
    BooleanSetting targethud = new BooleanSetting("Target HUD", true);
    BooleanSetting teams = new BooleanSetting("Teams", false);
    ModeSetting sortMode = new ModeSetting("Sort Mode", "FOV", "FOV", "Health", "Distance");
    ModeSetting mode = new ModeSetting("Mode", "Single", "Single", "Switch", "Multi", "AAC", "Tick", "Experimental", "Smooth");
    BooleanSetting dura = new BooleanSetting("HvH", false);
    NumberSetting multitargets = new NumberSetting("MultiTargets", 3, 1, 10, 1);
    NumberSetting multifov = new NumberSetting("MultiFOV", 75, 1, 180, 1);
    Timer timerUtil = new Timer();
    Timer switchTimer = new Timer();
    long time;
    boolean groundTicks;
    float[] serverAngles = new float[2];
    float[] prevRotations = new float[2];
    int switchI;
    float oldYaw;
    UnicodeFontRenderer otherfont;

    public LegitAura() {
        super("LegitAura", "description", 0, Category.GHOST);
        addSettings(cps, range, blockrange, maxTargets, switchSpeed, players, animals, monsters, invisibles, autoblock, dynamic, targetesp, targethud, teams, sortMode, mode, dura, multitargets, multifov);
        instance = this;
    }

    @Override
    public void onEnable() {
        otherfont = BaseClient.instance.font2.getFont(12);
    }

    @Override
    public void onUpdate(UpdateEvent event) {
        dura.visible = mode.is("Tick");
        multifov.visible = mode.is("Multi");
        multitargets.visible = mode.is("Multi");
    }

    @Override
    public void onDisable() {
        target = null;
        switchI = 0;
        mc.timer.timerSpeed = 1f;
    }

    @Override
    public void onMotion(MotionEvent event) {
        final Criticals criticals = Criticals.instance;
        final long ping = mc.getCurrentServerData() == null ? 0 : Math.min(50, Math.max(mc.getCurrentServerData().pingToServer, 110));
        final int pingDelay = Math.round(ping / 10f);
        if (AutoHeal.doSoup || AutoHeal.healing || AutoGapple.doingStuff || mc.thePlayer.isSpectator()) return;
        if (event.isPre()) {
            event.setPitch(mc.thePlayer.rotationPitch);
        }
        target = null;
        switch (mode.getMode()) {
            case "Experimental":
                target = getTarget();
                int attackKey = mc.gameSettings.keyBindAttack.getKeyCode();
                int blockKey = mc.gameSettings.keyBindUseItem.getKeyCode();
                if (event.isPre()) {
                    if (target != null) {
                        final float[] rots = getRotationsToEnt(target, mc.thePlayer);
                        float sens = getSensitivityMultiplier();
                        float yaw = rots[0] + getRandomInRange(-0.55F, 0.55F);
                        float pitch = rots[1] + getRandomInRange(-1.5F, 1.5F);
                        float yawGCD = (Math.round(yaw / sens) * sens);
                        float pitchGCD = (Math.round(pitch / sens) * sens);
                        if (Math.abs(pitchGCD) > 90) {
                            pitchGCD = 90;
                        }
                        if (Math.abs(pitchGCD) == Math.round(Math.abs(pitchGCD))) {
                            pitchGCD += (Math.round(Math.random() * 2 / sens) * sens);
                        }
                        event.setYaw(yawGCD);
                        event.setPitch(pitchGCD);
                        if (!mc.thePlayer.isBlocking()) {
                            if (mc.thePlayer.ticksExisted % (1 + getRandomInRange(1, 2)) == 0 && target.hurtResistantTime <= 17) {
                                if (timerUtil.delay(1000 / getCPS())) {
                                    KeyBinding.setKeyBindState(attackKey, true);
                                    KeyBinding.setKeyBindState(attackKey, false);
                                    KeyBinding.onTick(attackKey);
                                }
                            }
                        }
                        if (canBlock() && autoblock.isEnabled() && (mc.thePlayer.ticksExisted % (1 + getRandomInRange(1, 2)) != 0 || mc.thePlayer.hurtResistantTime <= 15) && mc.thePlayer.getDistanceToEntity(target) < 5) {
                            KeyBinding.setKeyBindState(blockKey, true);
                            KeyBinding.setKeyBindState(blockKey, false);
                            KeyBinding.onTick(blockKey);
                        }
                    } else timerUtil.reset();
                }
                break;
            case "AAC":
                target = getTarget();
                if (event.isPre()) {
                    if (target != null) {
                        final float[] rots = getRotationsToEnt(target, mc.thePlayer);
                        float sens = getSensitivityMultiplier();
                        float yaw = rots[0] + getRandomInRange(-0.15F, 0.15F);
                        float pitch = rots[1] + getRandomInRange(-0.15F, 0.15F);
                        float yawGCD = (Math.round(yaw / sens) * sens);
                        float pitchGCD = (Math.round(pitch / sens) * sens);
                        if (Math.abs(pitchGCD) == Math.round(Math.abs(pitchGCD))) {
                            pitchGCD += (Math.round(Math.random() * 2 / sens) * sens);
                        }
                        if (Math.abs(pitchGCD) > 90) {
                            pitchGCD = 90;
                        }
                        if (mc.thePlayer.onGround && !mc.gameSettings.keyBindJump.isKeyDown() && mc.thePlayer.motionY <= 0) {
                            if (mc.thePlayer.isSprinting() && Math.abs(mc.thePlayer.rotationYaw - yawGCD) > 45) {
                                mc.thePlayer.motionX /= 1.3F;
                                mc.thePlayer.motionZ /= 1.3F;
                            }
                            mc.thePlayer.setSprinting(false);
                        }
                        event.setYaw(yawGCD);
                        event.setPitch(pitchGCD);
                        Object[] rayTarget = getEntityCustom(pitchGCD, yawGCD, range.getValue(), 0.05, 0);
                        if (rayTarget != null) {
                            if (rayTarget[0] == target) {
                                if (timerUtil.delay(newgetCPS()) && target.hurtResistantTime < 17 && switchTimer.delay(75)) {
                                    attackEntity(target, false);
                                } else {
                                    if (canBlock() && nearbyTargets(true) && mc.thePlayer.ticksExisted % 5 == 0) {
                                        mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
                                    }
                                }
                            }
                        }
                    } else timerUtil.reset();
                }
                break;
            case "Single":
                target = getTarget();
                if (event.isPre()) {
                    if (target != null) {
                        final float[] rots = getRotationsToEnt(target, mc.thePlayer);
                        event.setYaw(rots[0]);
                        event.setPitch(rots[1]);
                    } else timerUtil.reset();
                } else {
                    if (target != null) {
                        if (dynamic.isEnabled()) {
                            if (target.hurtResistantTime == 0) {
                                if (timerUtil.delay(ping * 3)) attackEntity(target, false);
                            } else if (target.hurtResistantTime <= 9 + pingDelay) attackEntity(target, false);
                        } else if (timerUtil.delay(1000 / getCPS())) attackEntity(target, false);
                    } else timerUtil.reset();
                    if (canBlock() && nearbyTargets(true))
                        mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
                }
                break;
            case "Tick":
                target = getTarget();
                if (event.isPre()) {
                    lowerTicks();
                    if (target != null) {
                        final float[] rots = getRotationsToEnt(target, mc.thePlayer);
                        event.setYaw(rots[0]);
                        event.setPitch(rots[1]);
                    }
                } else {
                    if (target != null) {
                        if (isValidTicks(target)) {
                            if (!dura.isEnabled()) {
                                mc.thePlayer.swingItem();
                                mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK));
                                mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK));
                                mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
                                mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK));
                                target.auraticks = 10;
                            } else {
                                mc.thePlayer.swingItem();
                                swap(9, mc.thePlayer.inventory.currentItem);
                                attackEntity(target, false);
                                crit();
                                attackEntity(target, true);
                                swap(9, mc.thePlayer.inventory.currentItem);
                                attackEntity(target, false);
                                crit();
                                attackEntity(target, true);
                                final ItemStack[] items = target.getInventory();
                                ItemStack helm = null;
                                if (items[3] != null) {
                                    helm = items[3];
                                }
                                if (helm != null) {
                                    final float oldDura = helm.getMaxDamage();
                                    final float newDura = helm.getItemDamage();
                                    final float ey = oldDura - newDura;
                                    final float damagedone = oldDura - ey;
                                }
                                target.auraticks = 10;
                            }
                        }
                    }
                    if (canBlock() && nearbyTargets(true)) {
                        mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
                    }
                }
                break;
            case "Switch":
                if (event.isPre()) {
                    if (target != null) {
                        final float[] rots = getRotationsToEnt(target, mc.thePlayer);
                        event.setYaw(rots[0]);
                        event.setPitch(rots[1]);
                    }
                }
                if (!event.isPre()) {
                    final ArrayList<EntityLivingBase> targs = new ArrayList<>();
                    mc.theWorld.getLoadedEntityList().stream().filter(entity -> entity instanceof EntityLivingBase).filter(entity -> isTargetable((EntityLivingBase) entity, mc.thePlayer, false)).forEach(potentialTarget -> {
                        if (targs.size() < maxTargets.getValue()) {
                            targs.add((EntityLivingBase) potentialTarget);
                        }
                    });
                    if (switchTimer.delay(switchSpeed.getValue()) && !targs.isEmpty()) {
                        if (switchI + 1 > targs.size() - 1 || targs.size() < 2) {
                            switchI = 0;
                        } else {
                            switchI++;
                        }
                    }
                    if (!targs.isEmpty()) target = targs.get(Math.min(switchI, targs.size() - 1));
                    if (target != null) {
                        if (!isTargetable(target, mc.thePlayer, false)) target = null;
                    }
                    if (target != null && mc.thePlayer != null) {
                        final float[] rots = getRotationsToEnt(target, mc.thePlayer);
                        event.setYaw(rots[0]);
                        event.setPitch(rots[1]);
                        if (dynamic.isEnabled()) {
                            if (target.hurtResistantTime == 0) {
                                if (timerUtil.hasReached(ping * 3)) attackEntity(target, false);
                            } else if (target.hurtResistantTime <= 9 + pingDelay) attackEntity(target, false);
                        } else if (timerUtil.hasReached(1000 / getCPS())) attackEntity(target, false);
                    } else {
                        timerUtil.reset();
                    }
                }
                if (!event.isPre() && canBlock() && nearbyTargets(true)) {
                    mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
                }
                break;
            case "Multi":
                target = findMostCrowdedEntity();
                if (event.isPre()) {
                    if (target != null) {
                        final float[] rotations = getRotationsToEnt(target, mc.thePlayer);
                        event.setYaw(rotations[0]);
                        event.setPitch(rotations[1]);
                        oldYaw = event.getYaw();
                    }
                } else {
                    if (target != null) {
                        targets = getMultiTargets();
                        if (timerUtil.delay(1000 / getCPS() + (targets.size() - 1) * pingDelay)) {
                            attackEntity(target, false);
                            targets.stream().filter(t -> t.hurtResistantTime <= 9 + pingDelay).forEach(t -> {
                                if (t != target) {
                                    final float[] rotations = getRotationsToEnt(t, mc.thePlayer);
                                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(rotations[0], rotations[1], event.isGround()));
                                    attackEntity(t, false);
                                }
                            });
                        }
                    }
                    if (canBlock() && nearbyTargets(true)) {
                        mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
                    }
                }
                break;
            case "Smooth":
                target = getTarget();
                if (event.isPre()) {
                    if (target != null) {
                        if (criticals.isToggled() && mc.thePlayer.onGround && !isInsideBlock()) {
                            event.setY(event.getY() + 0.01);
                            event.setGround(false);
                        }
                        final float[] dstAngle = getRotationsToEnt(target, mc.thePlayer);
                        final float[] srcAngle = new float[]{serverAngles[0], serverAngles[1]};
                        serverAngles = smoothAngle(dstAngle, srcAngle);
                        event.setYaw(serverAngles[0]);
                        event.setPitch(serverAngles[1]);
                        if (getDistance(prevRotations) < 16 && !mc.thePlayer.isBlocking()) {
                            if (dynamic.isEnabled()) {
                                if (target.hurtResistantTime == 0) {
                                    if (timerUtil.delay(ping * 3)) attackEntity(target, false);
                                } else if (target.hurtResistantTime <= 9 + pingDelay) attackEntity(target, false);
                            } else if (timerUtil.delay(1000 / getCPS())) attackEntity(target, false);
                        }
                    } else {
                        serverAngles[0] = (mc.thePlayer.rotationYaw);
                        serverAngles[1] = (mc.thePlayer.rotationPitch);
                        timerUtil.reset();
                    }
                }
                break;
        }
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        ScaledResolution sr = new ScaledResolution(mc);

        float x = (sr.getScaledWidth() >> 1) - 5;
        float y = (sr.getScaledHeight() >> 1) + 120;
        if (targethud.isEnabled() && target != null) {
            if (mc.thePlayer != null && target instanceof EntityPlayer) {
                NetworkPlayerInfo networkPlayerInfo = mc.getNetHandler().getPlayerInfo(target.getUniqueID());
                final String ping = "Ping: " + (Objects.isNull(networkPlayerInfo) ? "0ms" : networkPlayerInfo.getResponseTime() + "ms");
                final String playerName = "Name: " + net.minecraft.util.StringUtils.stripControlCodes(target.getName());
                drawBorderedRect(x, y, 140, 45, 0.5, new Color(0, 0, 0, 255).getRGB(), new Color(0, 0, 0, 90).getRGB());
                drawRect(x, y, 45, 45, new Color(0, 0, 0).getRGB());
                otherfont.drawString(playerName, (int) (x + 46.5), (int) y + 4, -1, true);
                otherfont.drawString("Distance: " + round(mc.thePlayer.getDistanceToEntity(target), 2), (int) (x + 46.5), (int) y + 12, -1, true);
                otherfont.drawString(ping, (int) (x + 46.5), (int) y + 28, new Color(0x5D5B5C).getRGB(), true);
                otherfont.drawString("Health: " + round((Float.isNaN(target.getHealth()) ? 20 : target.getHealth()) / 2, 2), (int) (x + 46.5), (int) y + 20, getHealthColor(target), true);
                drawFace((int) (x + 0.5), (int) (y + 0.5), 8, 8, 8, 8, 44, 44, 64, 64, (AbstractClientPlayer) target);
                drawBorderedRect(x + 46, y + 45 - 10, 92, 8, 0.5, new Color(0).getRGB(), new Color(35, 35, 35).getRGB());
                double inc = 91 / target.getMaxHealth();
                double end = inc * (Math.min(target.getHealth(), target.getMaxHealth()));
                drawRect(x + 46.5, y + 45 - 9.5, end, 7, getHealthColor(target));
            }
        }
    }

    @Override
    public void onPreRender3D(PreRender3DEvent event) {
        if (targetesp.isEnabled()) {
            if (mode.is("Multi")) {
                targets.forEach(target2 -> {
                    if (isTargetable(target2, mc.thePlayer, false)) {
                        final double x = interpolate(target2.posX, target2.lastTickPosX, event.getPartialTicks());
                        final double y = interpolate(target2.posY, target2.lastTickPosY, event.getPartialTicks());
                        final double z = interpolate(target2.posZ, target2.lastTickPosZ, event.getPartialTicks());
                        drawEntityESP(x - mc.getRenderManager().getRenderPosX(), y + target2.height + 0.1 - target2.height - mc.getRenderManager().getRenderPosY(), z - mc.getRenderManager().getRenderPosZ(), target2.height, 0.65, new Color(target2.hurtTime > 0 ? 0xE33726 : getRainbow(4000, 0, 0.85f)));
                    }
                });
            } else if (target != null) {
                final double x = interpolate(target.posX, target.lastTickPosX, event.getPartialTicks());
                final double y = interpolate(target.posY, target.lastTickPosY, event.getPartialTicks());
                final double z = interpolate(target.posZ, target.lastTickPosZ, event.getPartialTicks());
                drawEntityESP(x - mc.getRenderManager().getRenderPosX(), y + target.height + 0.1 - target.height - mc.getRenderManager().getRenderPosY(), z - mc.getRenderManager().getRenderPosZ(), target.height, 0.65, new Color(target.hurtTime > 0 ? 0xE33726 : getRainbow(4000, 0, 0.85f)));
            }
        }
    }

    @Override
    public void onPacketSent(PacketSentEvent event) {
        final Criticals criticals = Criticals.instance;
        if ((event.getPacket() instanceof C03PacketPlayer)) {
            if (groundTicks) {
                event.setCancelled(true);
                groundTicks = false;
            }
        }
        if (event.getPacket() instanceof C03PacketPlayer) {
            prevRotations[0] = ((C03PacketPlayer) event.getPacket()).getYaw();
            prevRotations[1] = ((C03PacketPlayer) event.getPacket()).getPitch();
        }
        if ((event.getPacket() instanceof C0APacketAnimation)) {
            if (criticals.isToggled() && target != null && !criticals.mode.is("Area51") && !(mode.is("Tick") && dura.isEnabled()))
                crit();
        }
    }

    private List<EntityLivingBase> getMultiTargets() {
        final List<EntityLivingBase> entities = new ArrayList<>();
        int targets = 0;
        for (Entity entity : mc.theWorld.getLoadedEntityList()) {
            if (targets >= multitargets.getValue()) {
                break;
            }
            if (entity instanceof EntityLivingBase) {
                final EntityLivingBase living = (EntityLivingBase) entity;
                if (isTargetable(living, mc.thePlayer, false) && isWithinFOV(living, oldYaw, multifov.getValue())) {
                    entities.add(living);
                    ++targets;
                }
            }
        }
        return entities;
    }

    private EntityLivingBase findMostCrowdedEntity() {
        List<EntityLivingBase> entities = new ArrayList();
        for (Entity entity : mc.theWorld.getLoadedEntityList()) {
            if (entity instanceof EntityLivingBase) {
                entities.add((EntityLivingBase) entity);
            }
        }
        EntityLivingBase best = null;
        int numBestEntities = -1;
        for (EntityLivingBase e : entities) {
            if (isTargetable(e, mc.thePlayer, false)) {
                int closeEntities = 0;
                final float yaw = getRotationsToEnt(e, mc.thePlayer)[0];
                for (EntityLivingBase e1 : entities) {
                    if (isTargetable(e1, mc.thePlayer, false) && isWithinFOV(e1, yaw, multifov.getValue())) {
                        ++closeEntities;
                    }
                }
                if (closeEntities > numBestEntities) {
                    numBestEntities = closeEntities;
                    best = e;
                }
            }
        }
        return best;
    }

    private boolean isWithinFOV(EntityLivingBase entity, final float yaw, final double fov) {
        final float[] rotations = getRotationsToEnt(entity, mc.thePlayer);
        final float yawDifference = getYawDifference(yaw % 360.0f, rotations[0]);
        return yawDifference < fov && yawDifference > -fov;
    }

    private float getYawDifference(final float currentYaw, final float neededYaw) {
        float yawDifference = neededYaw - currentYaw;
        if (yawDifference > 180.0f) {
            yawDifference = -(360.0f - neededYaw + currentYaw);
        } else if (yawDifference < -180.0f) {
            yawDifference = 360.0f - currentYaw + neededYaw;
        }
        return yawDifference;
    }


    public boolean isTeammate(EntityPlayer target) {
        if (!teams.isEnabled()) return false;
        boolean teamChecks = false;
        EnumChatFormatting myCol = null;
        EnumChatFormatting enemyCol = null;
        if (target != null) {
            for (EnumChatFormatting col : EnumChatFormatting.values()) {
                if (col == EnumChatFormatting.RESET)
                    continue;
                if (mc.thePlayer.getDisplayName().getFormattedText().contains(col.toString()) && myCol == null) {
                    myCol = col;
                }
                if (target.getDisplayName().getFormattedText().contains(col.toString()) && enemyCol == null) {
                    enemyCol = col;
                }
            }
            try {
                if (myCol != null && enemyCol != null) {
                    teamChecks = myCol != enemyCol;
                } else {
                    if (mc.thePlayer.getTeam() != null) {
                        teamChecks = !mc.thePlayer.isOnSameTeam(target);
                    } else {
                        if (mc.thePlayer.inventory.armorInventory[3].getItem() instanceof ItemBlock) {
                            teamChecks = !ItemStack.areItemStacksEqual(mc.thePlayer.inventory.armorInventory[3], target.inventory.armorInventory[3]);
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
        return teamChecks;
    }

    private void drawFace(int x, int y, float u, float v, int uWidth, int vHeight, int width, int height, float tileWidth, float tileHeight, AbstractClientPlayer target) {
        try {
            ResourceLocation skin = target.getLocationSkin();
            mc.getTextureManager().bindTexture(skin);
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glColor4f(1, 1, 1, 1);
            Gui.drawScaledCustomSizeModalRect(x, y, u, v, uWidth, vHeight, width, height, tileWidth, tileHeight);
            GL11.glDisable(GL11.GL_BLEND);
        } catch (Exception ignored) {
        }
    }

    private int getHealthColor(EntityLivingBase player) {
        float f = player.getHealth();
        float f1 = player.getMaxHealth();
        float f2 = Math.max(0.0F, Math.min(f, f1) / f1);
        return Color.HSBtoRGB(f2 / 3.0F, 1.0F, 0.75F) | 0xFF000000;
    }

    private void drawEntityESP(double x, double y, double z, double height, double width, Color color) {
        GL11.glPushMatrix();
        GLUtil.setGLCap(3042, true);
        GLUtil.setGLCap(3553, false);
        GLUtil.setGLCap(2896, false);
        GLUtil.setGLCap(2929, false);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1.8f);
        GL11.glBlendFunc(770, 771);
        GLUtil.setGLCap(2848, true);
        GL11.glDepthMask(true);
        BB(new AxisAlignedBB(x - width + 0.25, y, z - width + 0.25, x + width - 0.25, y + height, z + width - 0.25), new Color(color.getRed(), color.getGreen(), color.getBlue(), 120).getRGB());
        OutlinedBB(new AxisAlignedBB(x - width + 0.25, y, z - width + 0.25, x + width - 0.25, y + height, z + width - 0.25), 1, color.getRGB());
        GLUtil.revertAllCaps();
        GL11.glPopMatrix();
        GL11.glColor4f(1, 1, 1, 1);
    }

    private List<EntityLivingBase> loadedLivingLowTicks() {
        List<EntityLivingBase> toreturn = new ArrayList();
        for (Entity entity : mc.theWorld.getLoadedEntityList()) {
            if (entity instanceof EntityLivingBase) {
                toreturn.add((EntityLivingBase) entity);
            }
        }
        toreturn.sort(Comparator.comparingInt(e -> e.auraticks));
        return toreturn;
    }

    private boolean nearbyTargets(boolean block) {
        for (Object e : mc.theWorld.loadedEntityList) {
            if (e instanceof EntityLivingBase && isTargetable((EntityLivingBase) e, mc.thePlayer, block)) {
                return true;
            }
        }
        return false;
    }

    private boolean canBlock() {
        return autoblock.isEnabled() && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword;
    }


    private void crit() {
        final Criticals criticals = Criticals.instance;
        final double[] HYPIXELOFFSETS = {0.062f + 1.0E-5F, 0.001f + 1.0E-5F, 0.062f + 1.0E-5F, 0.051f};
        final float[] NCPOFFSETS = {0.0624f, 0.0f, 1.13E-4F, 0.0f};

        if (!(getBlockUnderPlayer(mc.thePlayer, 0.06) instanceof BlockStairs) && canCrit() && !(getBlockUnderPlayer(mc.thePlayer, 0.06) instanceof BlockSlab)) {
            if (criticals.mode.is("Hypixel")) {
                double delay = 95;
                if (target.hurtResistantTime == 0) {
                    delay = 425;
                }
                if (System.currentTimeMillis() - time >= delay && target.hurtResistantTime <= 12) {
                    for (double offset : HYPIXELOFFSETS) {
                        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + offset, mc.thePlayer.posZ, false));
                    }
                    groundTicks = true;
                    time = System.currentTimeMillis();
                }
            } else if (criticals.mode.is("NCP")) {
                if (canCrit() && target.hurtResistantTime <= 13) {
                    for (double offset : NCPOFFSETS) {
                        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + offset, mc.thePlayer.posZ, false));
                    }
                }
            }
        }
    }

    private float[] smoothAngle(float[] dst, float[] src) {
        float[] smoothedAngle = new float[2];
        smoothedAngle[0] = (src[0] - dst[0]);
        smoothedAngle[1] = (src[1] - dst[1]);
        smoothedAngle = constrainAngle(smoothedAngle);
        smoothedAngle[0] = (src[0] - smoothedAngle[0] / 100 * getRandomInRange(14, 24));
        smoothedAngle[1] = (src[1] - smoothedAngle[1] / 100 * getRandomInRange(3, 8));
        return smoothedAngle;
    }

    private float getDistance(float[] original) {
        final float yaw = MathHelper.wrapAngleTo180_float(serverAngles[0]) - MathHelper.wrapAngleTo180_float(original[0]);
        final float pitch = MathHelper.wrapAngleTo180_float(serverAngles[1]) - MathHelper.wrapAngleTo180_float(original[1]);
        return (float) Math.sqrt(yaw * yaw + pitch * pitch);
    }

    private void attackEntity(Entity entity, boolean dura) {
        if (canBlock()) {
            mc.playerController.syncCurrentPlayItem();
            mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        }
        if (dura) {
            mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
            mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK));
        } else {
            mc.thePlayer.swingItem();
            mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));
        }
        float f1 = 0.0f;
        final boolean flag = mc.thePlayer.fallDistance > 0.0f && !mc.thePlayer.onGround && !mc.thePlayer.isOnLadder() && !mc.thePlayer.isInWater() && !mc.thePlayer.isPotionActive(Potion.blindness) && mc.thePlayer.ridingEntity == null && target != null;
        if (target != null) {
            f1 = EnchantmentHelper.func_152377_a(mc.thePlayer.getHeldItem(), target.getCreatureAttribute());
        } else {
            f1 = EnchantmentHelper.func_152377_a(mc.thePlayer.getHeldItem(), EnumCreatureAttribute.UNDEFINED);
        }
        if (flag) {
            mc.thePlayer.onCriticalHit(target);
        }
        if (f1 > 0.0f) {
            mc.thePlayer.onEnchantmentCritical(target);
        }
    }

    private boolean canCrit() {
        return mc.thePlayer.onGround && !Speed.instance.isToggled() && !mc.gameSettings.keyBindJump.isKeyDown() && mc.thePlayer.fallDistance == 0;
    }

    private int newgetCPS() {
        double range = getRandomInRange((float) cps.getValue()-1, (float) cps.getValue()+1);
        range = 20 / range;
        if (mc.thePlayer.ticksExisted % 3 != 0) {
            range += Math.round(getRandomInRange((float) -1.75, 1.75f));
        }
        if (mc.thePlayer.ticksExisted % 27 == 0) {
            range += getRandomInRange(1, 6);
        }
        range = Math.round(Math.max(range, 1));
        return (int) range * 50;
    }

    private int getCPS() {
        return (int) getRandomInRange((float) cps.getValue()-1, (float) cps.getValue()+1);
    }

    private void swap(final int slot, final int hotbarNum) {
        mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, hotbarNum, 2, mc.thePlayer);
    }

    private EntityLivingBase getTarget() {
        targets.clear();
        double Dist = Double.MAX_VALUE;
        if (mc.theWorld != null) {
            for (Object object : mc.theWorld.loadedEntityList) {
                if ((object instanceof EntityLivingBase)) {
                    EntityLivingBase e = (EntityLivingBase) object;
                    if ((mc.thePlayer.getDistanceToEntity(e) < Dist)) {
                        if (isTargetable(e, mc.thePlayer, false)) {
                            targets.add(e);
                        }
                    }
                }
            }
        }
        if (targets.isEmpty()) return null;
        switch (sortMode.getMode()) {
            case "FOV":
                targets.sort(Comparator.comparingDouble(target -> yawDist((EntityLivingBase) target)));
                break;
            case "Health":
                targets.sort(Comparator.comparingDouble(target -> ((EntityLivingBase) target).getHealth()));
                break;
            case "Distance":
                targets.sort(Comparator.comparingDouble(target -> mc.thePlayer.getDistanceToEntity(target)));
                break;
        }
        return targets.get(0);
    }

    private boolean isValidTicks(EntityLivingBase target) {
        return target.auraticks == 0 && isTargetable(target, mc.thePlayer, false);
    }

    private void lowerTicks() {
        mc.theWorld.getLoadedEntityList().forEach(e -> {
            if (e instanceof EntityLivingBase) {
                final EntityLivingBase living = (EntityLivingBase) e;
                if (living.auraticks > 0) {
                    --living.auraticks;
                }
            }
        });
    }

    private double yawDist(EntityLivingBase e) {
        if (e != null) {
            final Vec3 difference = e.getPositionVector().addVector(0.0, e.getEyeHeight() / 2.0f, 0.0).subtract(mc.thePlayer.getPositionVector().addVector(0.0, mc.thePlayer.getEyeHeight(), 0.0));
            final double d = Math.abs(mc.thePlayer.rotationYaw - (Math.toDegrees(Math.atan2(difference.zCoord, difference.xCoord)) - 90.0f)) % 360.0f;
            return (d > 180.0f) ? (360.0f - d) : d;
        }
        return 0;
    }

    private float[] getRotationsToEnt(Entity ent, EntityPlayerSP playerSP) {
        final double differenceX = ent.posX - playerSP.posX;
        final double differenceY = (ent.posY + ent.height) - (playerSP.posY + playerSP.height);
        final double differenceZ = ent.posZ - playerSP.posZ;
        final float rotationYaw = (float) (Math.atan2(differenceZ, differenceX) * 180.0D / Math.PI) - 90.0f;
        final float rotationPitch = (float) (Math.atan2(differenceY, playerSP.getDistanceToEntity(ent)) * 180.0D / Math.PI);
        final float finishedYaw = playerSP.rotationYaw + MathHelper.wrapAngleTo180_float(rotationYaw - playerSP.rotationYaw);
        final float finishedPitch = playerSP.rotationPitch + MathHelper.wrapAngleTo180_float(rotationPitch - playerSP.rotationPitch);
        return new float[]{finishedYaw, -finishedPitch};
    }

    private boolean isTargetable(EntityLivingBase entity, EntityPlayerSP clientPlayer, boolean b) {
        return entity.getUniqueID() != clientPlayer.getUniqueID() && entity.isEntityAlive() && !(entity instanceof EntityPlayer && isTeammate((EntityPlayer) entity)) /* && !AntiBot.getBots().contains(entity) */ && !BaseClient.instance.getFriendsManager().isFriend(entity.getName()) && !(entity.isInvisible() && !invisibles.isEnabled()) && (clientPlayer.getDistanceToEntity(entity) <= (b ? blockrange.getValue() : range.getValue()) || mode.is("AAC") && clientPlayer.getDistanceToEntity(entity) <= (b ? blockrange.getValue() : 6)) && (entity instanceof EntityPlayer && players.isEnabled() || (entity instanceof EntityMob || entity instanceof EntityGolem) && monsters.isEnabled() || ((entity instanceof EntityVillager || entity instanceof EntityAnimal) && animals.isEnabled()));
    }

    private boolean isInsideBlock() {
        for (int x = MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().minX); x < MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().maxX) + 1; x++) {
            for (int y = MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().minY); y < MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().maxY) + 1; y++) {
                for (int z = MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().minZ); z < MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().maxZ) + 1; z++) {
                    Block block = mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                    if ((block != null) && (!(block instanceof BlockAir))) {
                        AxisAlignedBB boundingBox = block.getCollisionBoundingBox(mc.theWorld, new BlockPos(x, y, z), mc.theWorld.getBlockState(new BlockPos(x, y, z)));
                        if ((block instanceof BlockHopper)) {
                            boundingBox = new AxisAlignedBB(x, y, z, x + 1, y + 1, z + 1);
                        }
                        if ((boundingBox != null) && (mc.thePlayer.getEntityBoundingBox().intersectsWith(boundingBox))) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public float getSensitivityMultiplier() {
        float f = Minecraft.getMinecraft().gameSettings.mouseSensitivity * 0.6F + 0.2F;
        return (f * f * f * 8.0F) * 0.15F;
    }

    public float getRandomInRange(float min, float max) {
        Random random = new Random();
        float range = max - min;
        float scaled = random.nextFloat() * range;
        return scaled + min;
    }

    public static Object[] getEntityCustom(float pitch, float yaw, final double distance, final double expand, final float partialTicks) {
        Minecraft mc = Minecraft.getMinecraft();
        final Entity var2 = mc.getRenderViewEntity();
        Entity entity = null;
        if (var2 == null || mc.theWorld == null) {
            return null;
        }
        mc.mcProfiler.startSection("pick");
        final net.minecraft.util.Vec3 var3 = var2.getPositionEyes(0.0f);
        final net.minecraft.util.Vec3 var4 = var2.getLookCustom(pitch, yaw , 0.0f);
        final net.minecraft.util.Vec3 var5 = var3.addVector(var4.xCoord * distance, var4.yCoord * distance, var4.zCoord * distance);
        net.minecraft.util.Vec3 var6 = null;
        final float var7 = 1.0f;
        final List var8 = mc.theWorld.getEntitiesWithinAABBExcludingEntity(var2, var2.getEntityBoundingBox().addCoord(var4.xCoord * distance, var4.yCoord * distance, var4.zCoord * distance).expand(var7, var7, var7));
        double var9 = distance;
        for (Object o : var8) {
            final Entity var11 = (Entity) o;
            if (var11.canBeCollidedWith()) {
                final float var12 = var11.getCollisionBorderSize();

                AxisAlignedBB var13 = var11.getEntityBoundingBox().expand(var12, var12, var12);
                var13 = var13.expand(expand, expand, expand);
                final MovingObjectPosition var14 = var13.calculateIntercept(var3, var5);
                if (var13.isVecInside(var3)) {
                    if (0.0 < var9 || var9 == 0.0) {
                        entity = var11;
                        var6 = ((var14 == null) ? var3 : var14.hitVec);
                        var9 = 0.0;
                    }
                } else if (var14 != null) {
                    final double var15 = var3.distanceTo(var14.hitVec);
                    if (var15 < var9 || var9 == 0.0) {
                        boolean canRiderInteract = false;
                        if (Reflector.ForgeEntity_canRiderInteract.exists()) {
                            canRiderInteract = Reflector.callBoolean(var11, Reflector.ForgeEntity_canRiderInteract);
                        }
                        if (var11 == var2.ridingEntity && !canRiderInteract) {
                            if (var9 == 0.0) {
                                entity = var11;
                                var6 = var14.hitVec;
                            }
                        } else {
                            entity = var11;
                            var6 = var14.hitVec;
                            var9 = var15;
                        }
                    }
                }
            }
        }
        if (var9 < distance && !(entity instanceof EntityLivingBase) && !(entity instanceof EntityItemFrame)) {
            entity = null;
        }
        mc.mcProfiler.endSection();
        if (entity == null || var6 == null) {
            return null;
        }
        return new Object[] { entity, var6 };
    }

    public double interpolate(double current, double old, double scale) {
        return old + (current - old) * scale;
    }

    public void OutlinedBB(AxisAlignedBB bb, float width, int color) {
        enable3D();
        glLineWidth(width);
        color(color);
        drawOutlinedBoundingBox(bb);
        disable3D();
    }

    public void BB(AxisAlignedBB bb, int color) {
        enable3D();
        color(color);
        drawBoundingBox(bb);
        disable3D();
    }

    public void enable3D() {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_TEXTURE_2D);
        glEnable(GL_LINE_SMOOTH);
        glDisable(GL_DEPTH_TEST);
        glDepthMask(false);
    }

    public void disable3D() {
        glDisable(GL_LINE_SMOOTH);
        glEnable(GL_TEXTURE_2D);
        glEnable(GL_DEPTH_TEST);
        glDepthMask(true);
        glDisable(GL_BLEND);
    }

    public void color(int color) {
        GL11.glColor4f((color >> 16 & 0xFF) / 255f, (color >> 8 & 0xFF) / 255f, (color & 0xFF) / 255f, (color >> 24 & 0xFF) / 255f);
    }

    public void drawOutlinedBoundingBox(AxisAlignedBB aa) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        worldRenderer.begin(3, DefaultVertexFormats.POSITION);
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(3, DefaultVertexFormats.POSITION);
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(1, DefaultVertexFormats.POSITION);
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        tessellator.draw();

    }

    public void drawBoundingBox(AxisAlignedBB aa) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        tessellator.draw();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
        worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
        tessellator.draw();
    }

    public void drawBorderedRect(double x, double y, double width, double height, double lineSize, int borderColor, int color) {
        Gui.drawRect(x, y, x + width, y + height, color);
        Gui.drawRect(x, y, x + width, y + lineSize, borderColor);
        Gui.drawRect(x, y, x + lineSize, y + height, borderColor);
        Gui.drawRect(x + width, y, x + width - lineSize, y + height, borderColor);
        Gui.drawRect(x, y + height, x + width, y + height - lineSize, borderColor);
    }

    public void drawRect(double x, double y, double width, double height, int color) {
        float f = (color >> 24 & 0xFF) / 255.0F;
        float f1 = (color >> 16 & 0xFF) / 255.0F;
        float f2 = (color >> 8 & 0xFF) / 255.0F;
        float f3 = (color & 0xFF) / 255.0F;
        GL11.glColor4f(f1, f2, f3, f);
        Gui.drawRect(x, y, x + width, y + height, color);
    }

    public double round(final double value, final int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }
        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    public int getRainbow(int speed, int offset, float s) {
        float hue = (System.currentTimeMillis() + offset) % speed;
        hue /= speed;
        return Color.getHSBColor(hue, s, 1f).getRGB();
    }

    public Block getBlockUnderPlayer(EntityPlayer inPlayer, double height) {
        return Minecraft.getMinecraft().theWorld.getBlockState(new BlockPos(inPlayer.posX, inPlayer.posY - height, inPlayer.posZ)).getBlock();
    }

    public float[] constrainAngle(float[] vector) {

        vector[0] = (vector[0] % 360F);
        vector[1] = (vector[1] % 360F);

        while (vector[0] <= -180) {
            vector[0] = (vector[0] + 360);
        }

        while (vector[1] <= -180) {
            vector[1] = (vector[1] + 360);
        }

        while (vector[0] > 180) {
            vector[0] = (vector[0] - 360);
        }

        while (vector[1] > 180) {
            vector[1] = (vector[1] - 360);
        }

        return vector;

    }

    public static int getRandomInRange(int min, int max) {
        Random rand = new Random();
        return rand.nextInt((max - min) + 1) + min;
    }

}
