package dev.windhook.module.modules.player;

import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.utils.Timer;
import net.minecraft.network.play.client.C03PacketPlayer;
import org.lwjgl.input.Keyboard;

import java.util.Objects;

public class AntiStuck extends Module {

    Timer timer = new Timer();

    ModeSetting mode = new ModeSetting("Mode", "Clip", "Clip", "Cancel", "Rotate");

    public AntiStuck() {
        super("AntiStuck", "Prevents you from getting stuck!", Keyboard.KEY_NONE, Category.PLAYER);
        settings.add(mode);
    }

    String enableMode;
    boolean noRotateEnabled;

    @Override
    public void onDisable() {
        if(Objects.equals(enableMode, "Rotate")) {
            ModuleManager.noRotate.setToggled(noRotateEnabled);
        }
    }

    @Override
    public void onEnable() {
        timer.reset();
        enableMode = mode.getMode();

        if(Objects.equals(enableMode, "Rotate")) {
            noRotateEnabled = ModuleManager.noRotate.isToggled();
            ModuleManager.noRotate.setToggled(false);
        }

        if(Objects.equals(enableMode, "Clip")) {
            mc.thePlayer.setPositionAndUpdate(mc.thePlayer.posX, mc.thePlayer.posY - 0.1, mc.thePlayer.posZ);
            setToggled(false);
        }

    }

    @Override
    public void onPacketSent(PacketSentEvent event) {
        if(Objects.equals(enableMode, "Cancel")) {
            if (event.getPacket() instanceof C03PacketPlayer) {
                event.setCancelled(true);
            }
        }
    }

    @Override
    public void onUpdate(UpdateEvent event) {
        if(timer.hasReached(500, false)) {
            setToggled(false);
        }
    }

}
