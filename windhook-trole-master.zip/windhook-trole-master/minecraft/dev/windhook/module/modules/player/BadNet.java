package dev.windhook.module.modules.player;

import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import net.minecraft.network.Packet;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class BadNet extends Module {

	private boolean paused;

	public BadNet() {
		super("BadNet", "Acts like you turned off your internet!", Keyboard.KEY_NONE, Category.PLAYER);
	}

	@Override
	public void setup() {
		this.color = Color.PLAYER;
	}

	@Override
	public void onDisable() {
		paused = false;
	}

	@Override
	public void onEnable() {
		paused = true;
	}

	@Override
	public void onPacketSent(PacketSentEvent event) {
		if(paused) {
			event.setCancelled(true);
		}
	}

}