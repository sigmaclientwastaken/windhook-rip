package dev.windhook.module.modules.player;

import dev.windhook.BaseClient;
import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

public class Gamespeed extends Module {

    ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Moving", "Minemora", "OFF");
    NumberSetting speed = new NumberSetting("Speed", 1.5, 0.1, 10, 0.05);
    NumberSetting desyncTolerance = new NumberSetting("Desync Tolerance", 5, 1, 15, 1);

    public Gamespeed() {
        super("GameSpeed", "Increases the speed of the entire game, client-side!", Keyboard.KEY_NONE, Category.PLAYER);
        settings.add(speed);
        settings.add(mode);
        settings.add(desyncTolerance);
    }

    ArrayList<C03PacketPlayer> minemora = new ArrayList<>();
    Vec3 minemoraDesync;

    @Override
    public void onEnable() {
        minemoraDesync = position();
    }

    @Override
    public void onDisable() {
        if(!mode.is("OFF"))
            mc.timer.timerSpeed = 1.0f;

        for(C03PacketPlayer c03 : minemora) {
            mc.thePlayer.sendQueue.addToSendQueue(c03);
        }

        minemora.clear();
    }

    @Override
    public void onUpdate(UpdateEvent event) {
        if(mode.is("Vanilla")) {
            mc.timer.timerSpeed = (float) speed.getValue();
        }
        if(mode.is("Moving")) {
            if(mc.thePlayer.moveForward != 0) {
                mc.timer.timerSpeed = (float) speed.getValue();
            } else {
                mc.timer.timerSpeed = 1.0f;
            }
        }

        if(mode.is("Minemora")) {
            mc.timer.timerSpeed = (float) speed.getValue();

            if(mc.thePlayer.ticksExisted % 60 == 0 || within((minemoraDesync == null? position() : minemoraDesync), position())) {
                for(C03PacketPlayer c03 : minemora) {
                    mc.thePlayer.sendQueue.addToSendQueue(c03);
                }
                BaseClient.chatMessage("Undesynced! [GAMESPEED]");
                minemora.clear();
            }
        }
    }

    @Override
    public void onPacketSent(PacketSentEvent event) {
        if(mode.is("Minemora") && !event.isCancelled()) {
            if(event.getPacket() instanceof C03PacketPlayer) {
                minemora.add((C03PacketPlayer) event.getPacket());
                event.setCancelled(true);
            }
        }
    }

    String pre;

    public void setOverride(boolean set) {
        if(set) {
            pre = mode.getMode();
            mode.set("OFF");
        }
        if(!set) {
            mode.set(pre);
        }
    }

    public boolean isOverride() { return mode.is("OFF"); }

    public Vec3 position() {
        return new Vec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
    }

    public boolean within(Vec3 posOld, Vec3 posCur) {
        double x = Math.abs(posOld.xCoord - posCur.xCoord);
        double y = Math.abs(posOld.yCoord - posCur.yCoord);
        double z = Math.abs(posOld.zCoord - posCur.zCoord);
        double all = Math.sqrt(x * x + y * y + z * z);
        return all <= desyncTolerance.getValue();
    }

    @Override
    public String getAddon() {
        return mode.getMode() + " - " + speed.getValue();
    }
}
