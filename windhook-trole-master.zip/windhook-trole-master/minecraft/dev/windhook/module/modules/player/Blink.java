package dev.windhook.module.modules.player;

import dev.windhook.event.events.PacketReceivedEvent;
import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.event.events.PreRender3DEvent;
import dev.windhook.event.events.Render3DEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.utils.Timer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.network.Packet;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.login.client.C00PacketLoginStart;
import net.minecraft.network.login.client.C01PacketEncryptionResponse;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Blink extends Module {

    public static Blink instance;

    BooleanSetting breadcrumbs = new BooleanSetting("Breadcrumbs", true);

    public Blink() {
        super("Blink", "Pauses your connection.", 0, Category.PLAYER);
        addSettings(breadcrumbs);
        instance = this;
    }

    private final List<Packet> packets = new CopyOnWriteArrayList<>();
    private final List<Vec3> crumbs = new CopyOnWriteArrayList<>();
    Timer timer = new Timer();

    @Override
    public void onEnable() {
        crumbs.clear();
    }

    @Override
    public void onDisable() {
        crumbs.clear();
        for (Packet packet : packets) {
            mc.getNetHandler().getNetworkManager().sendPacket(packet);
        }
        packets.clear();
    }

    @Override
    public void onPacketSent(PacketSentEvent event) {
        packets.add(event.getPacket());
        event.setCancelled(true);
    }

    @Override
    public void onPreRender3D(PreRender3DEvent event) {
        if(breadcrumbs.isEnabled()) {
            if (timer.delay(50)) {
                crumbs.add(new Vec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ));
                timer.reset();
            }
            if (!crumbs.isEmpty() && crumbs.size() > 2) {
                for (int i = 1; i < crumbs.size(); i++) {
                    Vec3 vecBegin = crumbs.get(i - 1);
                    Vec3 vecEnd = crumbs.get(i);
                    int color = getColor(164, 24, 188);
                    float beginX = (float) ((float) vecBegin.xCoord - RenderManager.renderPosX);
                    float beginY = (float) ((float) vecBegin.yCoord - RenderManager.renderPosY);
                    float beginZ = (float) ((float) vecBegin.zCoord - RenderManager.renderPosZ);
                    float endX = (float) ((float) vecEnd.xCoord - RenderManager.renderPosX);
                    float endY = (float) ((float) vecEnd.yCoord - RenderManager.renderPosY);
                    float endZ = (float) ((float) vecEnd.zCoord - RenderManager.renderPosZ);
                    final boolean bobbing = mc.gameSettings.viewBobbing;
                    mc.gameSettings.viewBobbing = false;
                    drawLine3D(beginX, beginY, beginZ, endX, endY, endZ, color);
                    mc.gameSettings.viewBobbing = bobbing;
                }
            }
        }
    }

    public static int getColor(int red, int green, int blue) {
        return getColor(red, green, blue, 255);
    }

    public static int getColor(int red, int green, int blue, int alpha) {
        int color = 0;
        color |= alpha << 24;
        color |= red << 16;
        color |= green << 8;
        color |= blue;
        return color;
    }

    public void drawLine3D(float x, float y, float z, float x1, float y1, float z1, int color) {
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glShadeModel(GL11.GL_SMOOTH);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDepthMask(false);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GL11.glLoadIdentity();
        Minecraft.getMinecraft().entityRenderer.orientCamera(Minecraft.getMinecraft().timer.renderPartialTicks);
        float var11 = (color >> 24 & 0xFF) / 255.0F;
        float var6 = (color >> 16 & 0xFF) / 255.0F;
        float var7 = (color >> 8 & 0xFF) / 255.0F;
        float var8 = (color & 0xFF) / 255.0F;
        GL11.glColor4f(var6, var7, var8, var11);
        GL11.glLineWidth(0.5f);
        GL11.glBegin(GL11.GL_LINE_STRIP);
        GL11.glVertex3d(x, y, z);
        GL11.glVertex3d(x1, y1, z1);
        GL11.glEnd();
        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
        GL11.glColor4f(1, 1, 1, 1);
    }

    @Override
    public String getAddon() {
        return crumbs.size() + "";
    }
}
