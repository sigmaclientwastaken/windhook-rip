package dev.windhook.module.modules.player;

import dev.windhook.event.events.MotionEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.ModeSetting;
import net.minecraft.block.BlockAir;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;

public class NoFall extends Module {

    public static NoFall instance;

    ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Packet", "Hypixel", "Damage", "Cubecraft");
    
    double fall;
    
    public NoFall() {
        super("NoFall", "Removes fall damage!", 0, Category.PLAYER);
        addSettings(mode);
        instance = this;
    }

    @Override
    public void onEnable(){
        if(mc.theWorld != null && mode.is("AAC")){
            C03PacketPlayer.C04PacketPlayerPosition p = new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, Double.NaN, mc.thePlayer.posZ, true);
            mc.thePlayer.sendQueue.addToSendQueue(p);
        }
        fall = 0;
    }

    @Override
    public void onMotion(MotionEvent event) {
        if(event.isPre()){
            switch(mode.getMode()){
                case"Vanilla":
                    if(isInAir(0.001) && mc.thePlayer.motionY < 0){
                        event.setGround(true);
                    }
                    break;

                case"Packet":
                    if(isInAir(0.0001) && mc.thePlayer.motionY < 0){
                        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
                    }
                    break;
                case"Hypixel":

                    if(isInAir(0.001)){
                        if(mc.thePlayer.motionY < -0.08)
                            fall -= mc.thePlayer.motionY;
                        if(fall > 2){
                            fall = 0;

                            event.setGround(true);
                        }
                    }else
                        fall = 0;
                    break;
                case"Cubecraft":
                    if(isInAir(0.001)){
                        if(mc.thePlayer.fallDistance > 2.69){
                            event.setGround(true);
                            mc.thePlayer.fallDistance = 0;
                        }
                        if (!mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0.0D, mc.thePlayer.motionY, 0.0D)).isEmpty()) {
                            if(!event.isGround() && mc.thePlayer.motionY < -0.6){
                                event.setGround(true);
                            }
                        }
                    }
                    break;
                case"Damage":
                    if(mc.thePlayer.fallDistance > 3.5){
                        event.setGround(true);
                    }
                    break;
                case"AAC":
                    if(mc.thePlayer.ticksExisted == 1){
                        C03PacketPlayer.C04PacketPlayerPosition p = new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, Double.NaN, mc.thePlayer.posZ, true);
                        mc.thePlayer.sendQueue.addToSendQueue(p);
                    }
                    break;
            }
        }
    }

    public boolean isInAir(double height) {
        return mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0.0D, -height, 0.0D)).isEmpty();
    }

    private boolean isBlockUnder() {
        for(int i = (int)(mc.thePlayer.posY - 1.0D); i > 0; --i) {
            BlockPos pos = new BlockPos(mc.thePlayer.posX, i, mc.thePlayer.posZ);
            if (!(mc.theWorld.getBlockState(pos).getBlock() instanceof BlockAir)) {
                return true;
            }
        }
        return false;
    }

}
