package dev.windhook.module.modules.player;

import dev.windhook.event.events.MotionEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.utils.Timer;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Clutch extends Module {

    BooleanSetting mlg = new BooleanSetting("AutoMLG", false);

    public Clutch() {
        super("Clutch", "Clutches for you!", Keyboard.KEY_NONE, Category.PLAYER);
        addSettings(mlg);
    }

    MLG mlgmod = new MLG();

    private final Timer timer = new Timer();
    private BlockData blockBelowData;
    private BlockPos lastBlockPos;
    private double fallStartY = 0;

    private final List<Block> blacklistedBlocks = Arrays.asList(
            Blocks.air, Blocks.water, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava,
            Blocks.enchanting_table, Blocks.carpet, Blocks.glass_pane, Blocks.stained_glass_pane, Blocks.iron_bars,
            Blocks.snow_layer, Blocks.ice, Blocks.packed_ice, Blocks.coal_ore, Blocks.diamond_ore, Blocks.emerald_ore,
            Blocks.chest, Blocks.torch, Blocks.anvil, Blocks.trapped_chest, Blocks.noteblock, Blocks.jukebox, Blocks.tnt,
            Blocks.gold_ore, Blocks.iron_ore, Blocks.lapis_ore, Blocks.lit_redstone_ore, Blocks.quartz_ore, Blocks.redstone_ore,
            Blocks.wooden_pressure_plate, Blocks.stone_pressure_plate, Blocks.light_weighted_pressure_plate, Blocks.heavy_weighted_pressure_plate,
            Blocks.stone_button, Blocks.wooden_button, Blocks.lever);

    @Override
    public void onMotion(MotionEvent event) {

        switch (event.getEventType()) {

            case PRE:
                if (!mc.thePlayer.onGround && mc.thePlayer.motionY > 0 && mc.gameSettings.keyBindJump.pressed && lastBlockPos != null && lastBlockPos.getX() == Math.floor(mc.thePlayer.posX) && lastBlockPos.getZ() == Math.floor(mc.thePlayer.posZ)) {
                    BlockPos blockBelow = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ);
                    IBlockState blockState = mc.theWorld.getBlockState(blockBelow);
                    if (blockState.getBlock() == Blocks.air && timer.delay(100)) {
                        blockBelowData = getBlockData(blockBelow);
                        if (blockBelowData != null) {
                            //Face in the center of the block
                            float[] rotations = getRotationsBlock(blockBelowData.position, blockBelowData.face);
                            event.setYaw(rotations[0]);
                            event.setPitch(rotations[1]);
                        }
                    }
                } else if (!mc.thePlayer.onGround && mc.thePlayer.motionY < 0) {

                    if (fallStartY < mc.thePlayer.posY) {
                        fallStartY = mc.thePlayer.posY;
                    }

                    if (fallStartY - mc.thePlayer.posY > 2) {
                        //Get block based off of movement
                        double x = mc.thePlayer.posX;
                        double y = mc.thePlayer.posY - 1.5;
                        double z = mc.thePlayer.posZ;

                        //Checks if the block below is a valid block + timer delay
                        BlockPos blockBelow = new BlockPos(x, y, z);
                        IBlockState blockState = mc.theWorld.getBlockState(blockBelow);

                        IBlockState underBlockState = mc.theWorld.getBlockState(new BlockPos(x, y - 1, z));

                        if (!underBlockState.getBlock().isBlockNormalCube() && !mc.thePlayer.isSneaking() && (blockState.getBlock() == Blocks.air ||
                                blockState.getBlock() == Blocks.snow_layer ||
                                blockState.getBlock() == Blocks.tallgrass) && timer.delay(100)) {
                            timer.reset();
                            //Grab the block data for the block below
                            lastBlockPos = blockBelow;
                            blockBelowData = getBlockData(blockBelow);
                            if (blockBelowData != null) {
                                //Face in the center of the block
                                float[] rotations = getRotationsBlock(blockBelowData.position, blockBelowData.face);
                                event.setYaw(rotations[0]);
                                event.setPitch(rotations[1]);
                            }
                        }
                    } else {
                        blockBelowData = null;
                    }

                } else {
                    fallStartY = 0;
                    blockBelowData = null;
                }
                break;

            case POST:
                if (blockBelowData != null) {
                    for (int i = 36; i < 45; i++) {
                        if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                            ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                            Item item = is.getItem();
                            if (item instanceof ItemBlock && !blacklistedBlocks.contains(((ItemBlock) item).getBlock()) && !((ItemBlock) item).getBlock().getLocalizedName().toLowerCase().contains("chest")) {
                                mc.rightClickDelayTimer = 2;
                                int currentItem = mc.thePlayer.inventory.currentItem;

                                //Swap to block.
                                mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(i - 36));
                                mc.thePlayer.inventory.currentItem = i - 36;
                                mc.playerController.updateController();

                                //Caused a null pointer for some reason, will look into soon.
                                try {
                                    if (mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, mc.thePlayer.inventory.getCurrentItem(), blockBelowData.position, blockBelowData.face, new Vec3(blockBelowData.position.getX(), blockBelowData.position.getY(), blockBelowData.position.getZ()))) {
                                        mc.thePlayer.swingItem();
                                    }
                                } catch (Exception ignored) {

                                }
                                blockBelowData = null;

                                //Reset to current hand.
                                mc.thePlayer.inventory.currentItem = currentItem;
                                mc.playerController.updateController();
                                return;
                            }
                        }
                    }
                }
                break;

        }

        if(mlg.isEnabled() && !NoFall.instance.isToggled()) {
            mlgmod.onMotion(event);
        }

    }

    private BlockData getBlockData(BlockPos pos) {
        if (!blacklistedBlocks.contains(mc.theWorld.getBlockState(pos.add(-1, 0, 0)).getBlock())) {
            return new BlockData(pos.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (!blacklistedBlocks.contains(mc.theWorld.getBlockState(pos.add(1, 0, 0)).getBlock())) {
            return new BlockData(pos.add(1, 0, 0), EnumFacing.WEST);
        }
        if (!blacklistedBlocks.contains(mc.theWorld.getBlockState(pos.add(0, 0, -1)).getBlock())) {
            return new BlockData(pos.add(0, 0, -1), EnumFacing.SOUTH);
        }
        if (!blacklistedBlocks.contains(mc.theWorld.getBlockState(pos.add(0, 0, 1)).getBlock())) {
            return new BlockData(pos.add(0, 0, 1), EnumFacing.NORTH);
        }
        return null;
    }

    public float[] getRotationsBlock(BlockPos block, EnumFacing face) {
        double x = block.getX() + 0.5 - mc.thePlayer.posX +  (double) face.getFrontOffsetX()/2;
        double z = block.getZ() + 0.5 - mc.thePlayer.posZ +  (double) face.getFrontOffsetZ()/2;
        double y = (block.getY() + 0.5);
        double d1 = mc.thePlayer.posY + mc.thePlayer.getEyeHeight() - y;
        double d3 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float) (Math.atan2(z, x) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) (Math.atan2(d1, d3) * 180.0D / Math.PI);
        if (yaw < 0.0F) {
            yaw += 360f;
        }
        return new float[]{yaw, pitch};
    }



}

class BlockData {
    public BlockPos position;
    public EnumFacing face;

    public BlockData(BlockPos position, EnumFacing face) {
        this.position = position;
        this.face = face;
    }
}

class MLG {

    private double fallStartY = 0;
    private final Timer timer = new Timer();
    private BlockData blockBelowData;
    private boolean nextPlaceWater = false;
    private boolean nextRemoveWater = false;

    Minecraft mc = Minecraft.getMinecraft();

    public void onMotion(MotionEvent event) {
        if (event.isPre()) {
            if (!mc.thePlayer.onGround && mc.thePlayer.motionY < 0) {

                if (fallStartY < mc.thePlayer.posY)
                    fallStartY = mc.thePlayer.posY;

                if (fallStartY - mc.thePlayer.posY > 2) {

                    //Get block based off of movement
                    double x = mc.thePlayer.posX + mc.thePlayer.motionX*1.25;
                    double y = mc.thePlayer.posY - mc.thePlayer.getEyeHeight();
                    double z = mc.thePlayer.posZ + mc.thePlayer.motionZ*1.25;

                    //Checks if the block below is a valid block + timer delay
                    BlockPos blockBelow = new BlockPos(x, y, z);
                    IBlockState blockState = mc.theWorld.getBlockState(blockBelow);
                    IBlockState underBlockState = mc.theWorld.getBlockState(blockBelow.down());

                    if (underBlockState.getBlock().isBlockNormalCube()
                            && !mc.thePlayer.isSneaking()
                            && (blockState.getBlock() == Blocks.air ||
                            blockState.getBlock() == Blocks.snow_layer ||
                            blockState.getBlock() == Blocks.tallgrass)
                            && timer.delay(100)) {
                        timer.reset();
                        blockBelowData = getBlockData(blockBelow);
                        if (blockBelowData != null) {
                            nextPlaceWater = true;
                            nextRemoveWater = false;

                            float[] rotations = getRotationsBlock(blockBelowData.position, blockBelowData.face);
                            event.setYaw(rotations[0]);
                            event.setPitch(rotations[1]);
                        }
                    }

                }
            } else {
                fallStartY = mc.thePlayer.posY;
            }
            if (blockBelowData != null && (mc.thePlayer.isInWater())) {
                nextRemoveWater = true;
                float[] rotations = getRotationsBlock(blockBelowData.position, blockBelowData.face);
                event.setYaw(rotations[0]);
                event.setPitch(rotations[1]);
            }
        } else {
            if (blockBelowData != null && nextPlaceWater) placeWater();
            else if (blockBelowData != null && nextRemoveWater) getWaterBack();
        }
    }

    /*
     * Swaps to item slot and returns the previous one
     */
    private int swapToItem(int item){
        mc.rightClickDelayTimer = 2;
        int currentItem = mc.thePlayer.inventory.currentItem;

        mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(item - 36));
        mc.thePlayer.inventory.currentItem = item - 36;

        mc.playerController.updateController();
        return currentItem;
    }

    /*
     * Places the water
     */
    private void placeWater() {
        for (Map.Entry<Integer, Item> item : getHotbarItems().entrySet()) {
            if (item.getValue().equals(Items.water_bucket)) {
                int currentItem = swapToItem(item.getKey());

                mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));

                //Reset to current hand.
                mc.thePlayer.inventory.currentItem = currentItem;
                mc.playerController.updateController();
                break;
            }
        }
        nextPlaceWater = false;
    }

    /*
     * Gets the water back
     */
    private void getWaterBack(){
        for (Map.Entry<Integer, Item> item : getHotbarItems().entrySet()) {
            if (item.getValue().equals(Items.bucket)) {
                int currentItem = swapToItem(item.getKey());

                mc.thePlayer.sendQueue.addToSendQueueNoEvent(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));

                //Reset to current hand.
                mc.thePlayer.inventory.currentItem = currentItem;
                mc.playerController.updateController();
                break;
            }
        }
        blockBelowData = null;
        nextRemoveWater = false;
    }

    /**
     * Return's a map with the current hotbar items
     *
     * @author Tomygames
     */
    private HashMap<Integer,Item> getHotbarItems(){
        HashMap<Integer,Item> items = new HashMap<>();

        for (int i = 36; i < 45; i++) {
            if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack itemStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                items.put(i, itemStack.getItem());
            }
        }

        return items;
    }

    private BlockData getBlockData(BlockPos pos) {
        if (!Arrays.asList(
                Blocks.air, Blocks.water, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava,
                Blocks.enchanting_table, Blocks.carpet, Blocks.glass_pane, Blocks.stained_glass_pane, Blocks.iron_bars,
                Blocks.snow_layer, Blocks.ice, Blocks.packed_ice, Blocks.coal_ore, Blocks.diamond_ore, Blocks.emerald_ore,
                Blocks.chest, Blocks.torch, Blocks.anvil, Blocks.trapped_chest, Blocks.noteblock, Blocks.jukebox, Blocks.tnt,
                Blocks.gold_ore, Blocks.iron_ore, Blocks.lapis_ore, Blocks.lit_redstone_ore, Blocks.quartz_ore, Blocks.redstone_ore,
                Blocks.wooden_pressure_plate, Blocks.stone_pressure_plate, Blocks.light_weighted_pressure_plate, Blocks.heavy_weighted_pressure_plate,
                Blocks.stone_button, Blocks.wooden_button, Blocks.lever).contains(mc.theWorld.getBlockState(pos.add(0, -1, 0)).getBlock())) {
            return new BlockData(pos.add(0, -1, 0), EnumFacing.UP);
        }
        return null;
    }

    public float[] getRotationsBlock(BlockPos block, EnumFacing face) {
        double x = block.getX() + 0.5 - mc.thePlayer.posX +  (double) face.getFrontOffsetX()/2;
        double z = block.getZ() + 0.5 - mc.thePlayer.posZ +  (double) face.getFrontOffsetZ()/2;
        double y = (block.getY() + 0.5);
        double d1 = mc.thePlayer.posY + mc.thePlayer.getEyeHeight() - y;
        double d3 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float) (Math.atan2(z, x) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) (Math.atan2(d1, d3) * 180.0D / Math.PI);
        if (yaw < 0.0F) {
            yaw += 360f;
        }
        return new float[]{yaw, pitch};
    }

}