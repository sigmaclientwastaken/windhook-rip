package dev.windhook.module.modules.semi_hidden;

import dev.windhook.module.Category;
import dev.windhook.module.Module;

public class TabGui extends Module {

	public TabGui() {
		super("TabGui", "This is the TabGui", 0, Category.SEMI_HIDDEN, false, true);
	}

}