package dev.windhook.module.modules.semi_hidden;

import dev.windhook.BaseClient;
import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.replay.Replay;
import dev.windhook.utils.Timer;
import net.arikia.dev.drpc.DiscordRPC;
import net.arikia.dev.drpc.DiscordRichPresence;
import net.minecraft.client.Minecraft;

public class Client extends Module {

	public Client() {
		super("Client", "Client background process.", 0, Category.SEMI_HIDDEN, false, true);
	}

	Timer rpcUpdateTimer = new Timer();

	@Override
	public void onMotion(MotionEvent event) {
		if(BaseClient.getInstance().isReplay){
			BaseClient.getInstance().replayManager.playReplay();
		}else if(BaseClient.getInstance().isRecording){
			Replay current = BaseClient.getInstance().replayManager.replays.get(0);
			current.recordSession(Minecraft.getMinecraft().theWorld,Minecraft.getMinecraft().thePlayer);
		}

		if(rpcUpdateTimer.hasReached(3000, true)) {

			DiscordRichPresence rich = new DiscordRichPresence.Builder("This is the current state.").setDetails("These are some details.").build();
			DiscordRPC.discordUpdatePresence(rich);

		}

	}


}