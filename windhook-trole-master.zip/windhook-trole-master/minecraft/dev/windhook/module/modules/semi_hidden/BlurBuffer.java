package dev.windhook.module.modules.semi_hidden;

import dev.windhook.BaseClient;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.gui.blur.BlurGraphics;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.utils.WaitTimer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.shader.ShaderGroup;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

public class BlurBuffer extends Module {

	public static Framebuffer blurBuffer;

	public static WaitTimer blurBufferTimer = new WaitTimer();
	public static ShaderGroup blurShaderGroup;

	public static boolean blurBufferRendered = false;

	public BlurBuffer() {
		super("BlurBuffer", "This is the blur buffer", Keyboard.KEY_NONE, Category.SEMI_HIDDEN, false, true);
	}


	@Override
	public void onRender2D(Render2DEvent event) {
		blurBuffer = new Framebuffer(mc.displayWidth, mc.displayHeight, false);
		blurBuffer.setFramebufferColor(0.0F, 0.0F, 0.0F, 0.0F);
		this.loadShader(BlurGraphics.blurShader, blurBuffer);
		blurBufferRendered = false;

		mc.entityRenderer.useShader = false;
		if(blurShaderGroup == null) {
			this.loadShader(BlurGraphics.blurShader, blurBuffer);
		}
	}

	public void loadShader(ResourceLocation resourceLocationIn, Framebuffer framebuffer)
	{
		if (OpenGlHelper.isFramebufferEnabled())
		{
			try {
				this.blurShaderGroup = new ShaderGroup(this.mc.getTextureManager(), this.mc.getResourceManager(), framebuffer, resourceLocationIn);
				this.blurShaderGroup.createBindFramebuffers(this.mc.displayWidth, this.mc.displayHeight);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
	}


	public static ShaderGroup getBlurShaderGroup() {
		return blurShaderGroup;
	}

	public static void setBlurBufferRendered() {
		BlurBuffer.blurBufferRendered = true;
	}

	public static void overrideTimer() {
		blurBufferTimer.time = 0;
	}

}