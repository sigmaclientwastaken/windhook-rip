package dev.windhook.module.modules.semi_hidden;

import dev.windhook.BaseClient;
import dev.windhook.gui.dropdowngui.DropdownGUI;
import org.lwjgl.input.Keyboard;

import dev.windhook.module.Category;
import dev.windhook.module.Module;

public class ClickGui extends Module {

	public ClickGui() {
		super("ClickGui", "This is the ClickGui", Keyboard.KEY_RSHIFT, Category.SEMI_HIDDEN, false);
	}

	@Override
	public void onEnable() {
		mc.displayGuiScreen(BaseClient.getInstance().getClickGui());
		super.toggle();
	}

}