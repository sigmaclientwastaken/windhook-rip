package dev.windhook.module.modules.semi_hidden;

import dev.windhook.BaseClient;
import dev.windhook.module.modules.client.TabGui;
import org.lwjgl.input.Keyboard;

import dev.windhook.event.events.UpdateEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;

public class AdvancedTabGui extends Module {

	/**
	 * -98 is the CUSTOM mouse wheel click code
	 */
	public AdvancedTabGui() {
		super("AdvancedTabGui", "Interact with the TabGui in an advanced way", Keyboard.KEY_NONE, Category.SEMI_HIDDEN);
	}

	@Override
	public void onUpdate(UpdateEvent event) {
		if (!(BaseClient.instance.getModuleManager().getModule(TabGui.class).isToggled()))
			toggle();
	}

}