package dev.windhook.module.modules.semi_hidden;

import dev.windhook.BaseClient;
import dev.windhook.event.events.GuiRenderEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.utils.Colors;
import dev.windhook.utils.RenderUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class Watermark extends Module {

    public Watermark() {
        super("Watermark", "description", Keyboard.KEY_NONE, Category.SEMI_HIDDEN, false, true);
    }

    @Override
    public void onGuiRender(GuiRenderEvent event) {
        String watermark = BaseClient.instance.getClientName();
        String version = BaseClient.instance.getClientVersion();
        String author = BaseClient.instance.getAuthor();

        RenderUtils.drawBlurredShadow(3, 3, 3 + 60, 3 + 20, 7);
        RenderUtils.blurSpot(3, 3, 3 + 60, 3 + 20, 20, 2);
        RenderUtils.drawBlurBuffer(3, 3, 3 + 60, 3 + 20, true);

        RenderUtils
                .drawString(String.format("%s %s", watermark, version, author), 5, 5,
                        ModuleManager.tabGui.rainbow.isEnabled() ? Colors.getRGBWave(10, 1, 0.7F, watermark.toCharArray().length)
                                : new Color(255, 255, 255).getRGB(),
                        BaseClient.instance.getFontRenderer().fontSizeLogo);

        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);

        GL11.glLineWidth(1f);
        GL11.glColor4f(0f, 0f, 0f, 0.5f);
    }
}
