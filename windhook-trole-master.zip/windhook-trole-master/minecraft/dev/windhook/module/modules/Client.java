package dev.windhook.module.modules;

import dev.windhook.event.EventListener;
import dev.windhook.event.events.ServerConnectingEvent;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.modules.player.Blink;
import dev.windhook.module.settings.ModeSetting;

public class Client extends EventListener {

    public static void launch() {
        ModuleManager.fly.setToggledSilent(false);
        Blink.instance.setToggled(false);
    }

}
