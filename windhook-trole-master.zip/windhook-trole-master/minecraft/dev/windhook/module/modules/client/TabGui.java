package dev.windhook.module.modules.client;

import dev.windhook.module.Color;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.NumberSetting;
import org.lwjgl.input.Keyboard;

import dev.windhook.module.Category;
import dev.windhook.module.Module;

public class TabGui extends Module {

	public BooleanSetting rainbow = new BooleanSetting("Rainbow", true);
	public BooleanSetting gradient = new BooleanSetting("Gradient", true);
	public NumberSetting speed = new NumberSetting("Speed", 20, 1, 50, 1);
	public NumberSetting offset = new NumberSetting("Offset", 1, 1, 30, 1);

	public TabGui() {
		super("TabGui", "This is the TabGui", Keyboard.KEY_NONE, Category.CLIENT, true);
		settings.add(rainbow);
		settings.add(gradient);
		settings.add(speed);
		settings.add(offset);
	}

	@Override
	public void setup() {
		this.color = Color.CLIENT;
	}

}