package dev.windhook.module.modules.client;

import dev.windhook.module.Category;
import dev.windhook.module.Module;

public class StreamerMode extends Module {

    public static StreamerMode instance;

    public StreamerMode() {
        super("StreamerMode", "Hides your name!", 0, Category.CLIENT, false);
        instance = this;
    }

}
