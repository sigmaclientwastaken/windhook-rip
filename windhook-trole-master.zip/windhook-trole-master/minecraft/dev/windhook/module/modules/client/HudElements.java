package dev.windhook.module.modules.client;

import dev.windhook.BaseClient;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.utils.Colors;
import dev.windhook.utils.RenderUtils;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

import java.awt.*;

public class HudElements extends Module {

    BooleanSetting watermark = new BooleanSetting("Watermark",true);
    ModeSetting watermarkMode = new ModeSetting("Watermark Mode", "Normal", "Normal", "GameSense", "Fancy");
    BooleanSetting speedCounter = new BooleanSetting("Speed", true);
    BooleanSetting speedY = new BooleanSetting("Speed Y", false);
    ModeSetting speedMode = new ModeSetting("Speed Mode", "Second", "Second", "Tick");

    public HudElements() {
        super("Hud Elements", "Elements of the client HUD.", Keyboard.KEY_NONE, Category.CLIENT, false);
        settings.add(watermark);
        settings.add(watermarkMode);
        settings.add(speedCounter);
        settings.add(speedY);
        settings.add(speedMode);
    }

    @Override
    public void onRender2D(Render2DEvent event) {

        ScaledResolution sr = new ScaledResolution(mc);
        UnicodeFontRenderer fr = RenderUtils.getFontRenderer().getFont(20);

        if(speedCounter.isEnabled()) {
            fr.drawString("Speed: " + getSpeed(), sr.getScaledWidth() - fr.getStringWidth("Speed: " + getSpeed()) - 3, sr.getScaledHeight() -fr.getStringHeight("Speed: " + getSpeed()), -1, true);
        }

        if(watermark.isEnabled()) {

            if(watermarkMode.is("Normal"))
                RenderUtils.drawString(BaseClient.getInstance().getClientName() + " " + BaseClient.getInstance().getClientVersion(), 5, 3, Colors.getRGBWave(3, 1, 1, 30), 30, true);

            if(watermarkMode.is("GameSense")) {

                Color LIGHT_GRAY = new Color(44, 44, 44, 255);
                Color MID_GRAY = new Color(23, 24, 24, 255);
                Color DARK_GRAY = new Color(16, 16, 17, 255);

           //     Gui.drawRect(2, 2, 220, 19, LIGHT_GRAY.getRGB());
           //     Gui.drawRect(4,4, 218, 17, MID_GRAY.getRGB());
           //     Gui.drawRect(5,5, 217, 16, DARK_GRAY.getRGB());


                String ver = BaseClient.getInstance().getClientVersion();

                String f = "wind";
                String g = "sense " + ver + " | FPS: " + mc.getDebugFPS() + " | " + mc.session.getUsername();
                float width = fr.getStringWidth(g);

                Gui.drawRect(2, 2, (int) (27 + 5 + width), 19, LIGHT_GRAY.getRGB());
                Gui.drawRect(4,4, (int) (27 + 3 + width), 17, MID_GRAY.getRGB());
                Gui.drawRect(5,5, (int) (27 + 2 + width), 16, DARK_GRAY.getRGB());

                RenderUtils.drawString(f, 6, 4, Colors.getRGBWave(20, 1f, 0.5f, 50), 20, true);
                RenderUtils.drawString(g, 27, 4, -1, 20, true);

            }
/*
            if(watermarkMode.is("Fancy")) {

                mc.getTextureManager().bindTexture(new ResourceLocation("wind/fancy.png"));

                GlStateManager.pushMatrix();
                GlStateManager.scale(0.125, 0.125, 1);

                Gui.drawModalRectWithCustomSizedTexture(4, 4,0, 0, 1024, 1024, 1024, 1024);

                GlStateManager.popMatrix();

            }
*/
        }

    }

    double getSpeed() {

        double val1 = 0;

        double xdif = Math.abs(mc.thePlayer.posX - mc.thePlayer.lastTickPosX);
        double ydif = Math.abs(mc.thePlayer.posY - mc.thePlayer.lastTickPosY);
        double zdif = Math.abs(mc.thePlayer.posZ - mc.thePlayer.lastTickPosZ);

        double alldif = Math.sqrt(xdif * xdif + ydif * ydif + zdif * zdif);
        double alldifnoy = Math.sqrt(xdif * xdif + zdif * zdif);

        val1 = speedMode.is("Tick") ? (speedY.isEnabled() ? alldif : alldifnoy) : (speedY.isEnabled() ? alldif : alldifnoy)  * 20;

        return roundAvoid(val1, 2);
    }

    double roundAvoid(double value, int places) {
        double scale = Math.pow(10, places);
        return Math.round(value * scale) / scale;
    }

}
