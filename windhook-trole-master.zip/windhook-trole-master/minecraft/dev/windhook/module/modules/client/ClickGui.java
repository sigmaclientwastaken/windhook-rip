package dev.windhook.module.modules.client;

import dev.windhook.BaseClient;
import dev.windhook.gui.dropdowngui.DropdownGUI;
import dev.windhook.module.Color;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.NumberSetting;
import org.lwjgl.input.Keyboard;

import dev.windhook.module.Category;
import dev.windhook.module.Module;

public class ClickGui extends Module {

	public BooleanSetting rainbow = new BooleanSetting("Rainbow", true);
	public BooleanSetting gradient = new BooleanSetting("Gradient", false);
	public NumberSetting offset = new NumberSetting("Offset", 1, 1, 20, 1);
	public NumberSetting speed = new NumberSetting("Speed", 10, 20, 50, 1);
	public NumberSetting spacing = new NumberSetting("Spacing", 5, 1, 15, 1);
	public NumberSetting scroll_speed = new NumberSetting("Scroll Speed", 10, 1, 20, 1);

	public ClickGui() {
		super("ClickGui", "This is the ClickGui", Keyboard.KEY_NONE, Category.CLIENT, true, false);
		settings.add(rainbow);
		settings.add(gradient);
		settings.add(offset);
		settings.add(speed);
		settings.add(spacing);
		settings.add(scroll_speed);
	}

	@Override
	public void setup() {
		this.color = Color.CLIENT;
	}

	@Override
	public void onEnable() {
		mc.displayGuiScreen(BaseClient.getInstance().getClickGui());
		super.toggle();
	}

}