package dev.windhook.module.modules.client;

import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import org.lwjgl.input.Keyboard;

public class HotbarOverlay extends Module {

	public ModeSetting mode = new ModeSetting("Mode", "OxideWavelength", "OxideWavelength", "None", "Clean");
	public BooleanSetting clear = new BooleanSetting("Clear", true);

	public HotbarOverlay() {
		super("Hotbar Overlay", "Modifies the hotbar.", Keyboard.KEY_NONE, Category.CLIENT, false, false);
		addSettings(mode);
	}

	@Override
	public void setup() {
		this.color = Color.CLIENT;
	}
}
