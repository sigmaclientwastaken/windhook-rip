package dev.windhook.module.modules.client;

import dev.windhook.module.Color;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import org.lwjgl.input.Keyboard;

import dev.windhook.module.Category;
import dev.windhook.module.Module;

public class ArrayList extends Module {

	public ModeSetting mode = new ModeSetting("Mode", "Old", "Old", "Broken", "New");
	public BooleanSetting rainbow = new BooleanSetting("Rainbow", true);
	public NumberSetting offset = new NumberSetting("Offset", 2, 1, 20, 1);
	public NumberSetting speed = new NumberSetting("Speed", 20, 1, 50, 1);
	public NumberSetting opacity = new NumberSetting("Opacity", 100, 1, 100, 1);
	public BooleanSetting gradient = new BooleanSetting("Gradient", false);
	public BooleanSetting match_module_color = new BooleanSetting("Match Module Color", false);
	public NumberSetting tab_size = new NumberSetting("Tab Size", 5, 1 ,20, 1);

	public ArrayList() {
		super("Array List", "Shows the list of toggled modules.", Keyboard.KEY_NONE, Category.CLIENT, false, true);
		addSettings(mode, rainbow, offset, speed, opacity, gradient, match_module_color, tab_size);
	}

	@Override
	public void setup() {
		this.color = Color.CLIENT;
	}
}
