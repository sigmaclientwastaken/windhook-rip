package dev.windhook.module.modules.client;

import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.NumberSetting;
import org.lwjgl.input.Keyboard;

public class Targets extends Module {

	public BooleanSetting 	players = new BooleanSetting("Players", true),
							mobs = new BooleanSetting("Mobs", false),
							animals = new BooleanSetting("Animals", false),
							villagers = new BooleanSetting("Villagers", false),
							invisible = new BooleanSetting("Invisible", false);

	public Targets() {
		super("Targets", "Shows the list of toggled modules.", Keyboard.KEY_NONE, Category.CLIENT, false, true);
		addSettings(players, mobs, animals, villagers, invisible);
	}

	@Override
	public void setup() {
		this.color = Color.CLIENT;
	}
}
