package dev.windhook.module.modules.client;

import dev.windhook.BaseClient;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import org.lwjgl.input.Keyboard;

public class Replay extends Module {

	boolean rec;

	public Replay() {
		super("Replay", "Replay recording, turn off to toggle.", Keyboard.KEY_NONE, Category.CLIENT, true, true);
	}

	@Override
	public void onEnable() {
		rec = !rec;
		BaseClient.getInstance().isRecording = rec;
	}

	@Override
	public void onDisable() {
		setToggled(true);
	}

	@Override
	public String getNameWithAddon() {
		return getName() + "  " + (rec? "&aON" : "&cOFF");
	}

	@Override
	public void setup() {
		this.color = Color.CLIENT;
	}
}
