package dev.windhook.module.modules.client;

import dev.windhook.BaseClient;
import dev.windhook.gui.astolfogui.AstolfoScreen;
import dev.windhook.gui.blockminergui.BMClickGui;
import dev.windhook.gui.lunagui.LunaClickGui;
import dev.windhook.gui.newgui.NewClickGui;
import dev.windhook.gui.radialgui.RadialClickGui;
import dev.windhook.module.Category;
import dev.windhook.module.Color;
import dev.windhook.module.Module;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import org.lwjgl.input.Keyboard;

public class ClickGuiNew extends Module {

	public ModeSetting theme = new ModeSetting("Theme", "Discord", "Custom Color", "Discord", "Chill Rainbow", "Rainbow");
	public ModeSetting mode = new ModeSetting("Mode", "Old", "Old", "New", "Radial", "Luna", "BlockMiner", "Astolfo");

	public NumberSetting 	offset = new NumberSetting("Offset", 2, 1, 15, 0.5),
							corners = new NumberSetting("Corners", 3, 1, 6, 1),
							red = new NumberSetting("Red", 1, 1, 255, 1),
							blue = new NumberSetting("Blue", 1, 1, 255, 1),
							green = new NumberSetting("Green", 1, 1, 255, 1),
							rainbowSpeed = new NumberSetting("Rainbow Speed", 30, 1, 100, 1);

	public BooleanSetting 	blur = new BooleanSetting("Blur [BROKEN]", false),
							custom = new BooleanSetting("Custom Tab", false);

	public ClickGuiNew() {
		super("ClickGui New", "This is the ClickGui", Keyboard.KEY_RSHIFT, Category.CLIENT, true, false);
		addSettings(mode, theme, offset, corners, red, green, blue, rainbowSpeed, custom);
	}

	public NewClickGui newGui = new NewClickGui();
	public static AstolfoScreen astolfoScreen;

	@Override
	public void setup() {
		this.color = Color.CLIENT;
	}

	@Override
	public void onEnable() {

		switch (mode.getMode()) {

			case "Old":
				mc.displayGuiScreen(BaseClient.instance.getDropdownGUI());
				break;

			case "New":
				mc.displayGuiScreen(newGui);
				break;

			case "Radial":
				mc.displayGuiScreen(new RadialClickGui());
				break;

			case "Luna":
				mc.displayGuiScreen(new LunaClickGui());
				break;

			case "BlockMiner":
				mc.displayGuiScreen(new BMClickGui());
				break;

			case "Astolfo":
				mc.displayGuiScreen(astolfoScreen);
				break;

		}

		super.toggle();
	}

}