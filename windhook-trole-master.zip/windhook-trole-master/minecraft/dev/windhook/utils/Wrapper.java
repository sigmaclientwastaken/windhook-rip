package dev.windhook.utils;

import java.awt.Font;

import org.newdawn.slick.util.FontUtils;

import dev.windhook.font.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class Wrapper {

	public static Minecraft mc = Minecraft.getMinecraft();
	public static FontRenderer fr = mc.fontRendererObj;
	public static Object getRenderArrayList() {
		
		return null;
	}
	public static WorldClient getWorld(){
		return mc.theWorld;
	}
	public static EntityLivingBase getPlayer() {
		// TODO Auto-generated method stub
		return null;
	}
}