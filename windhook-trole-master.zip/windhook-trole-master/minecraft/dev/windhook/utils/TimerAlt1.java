package dev.windhook.utils;

public class TimerAlt1 {
}
