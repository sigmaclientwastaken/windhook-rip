package dev.windhook.utils;

import dev.windhook.BaseClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.*;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashSet;

public class Player {

	private static Minecraft mc = Minecraft.getMinecraft();

	public static void sendMessage(String message) {
		sendMessage(message, false);
	}

	public static void sendMessage(String message, boolean prefix) {
		mc.ingameGUI.getChatGUI()
				.printChatMessage(new ChatComponentText(Strings
						.translateColors((prefix ? "[" + BaseClient.instance.getClientName() + "]" : "") + message)),
						false);
	}

	/**
	 * @param entityIn The entity to get the yaw change to.
	 * @return The total angle change between the center of your and the center of entityIn's bounding box.
	 */
	public static float getAngleChange(EntityLivingBase entityIn) {
		float yaw = getNeededRotations(entityIn)[0];
		float pitch = getNeededRotations(entityIn)[1];
		float playerYaw = mc.thePlayer.rotationYaw;
		float playerPitch = mc.thePlayer.rotationPitch;
		if (playerYaw < 0)
			playerYaw += 360;
		if (playerPitch < 0)
			playerPitch += 360;
		if (yaw < 0)
			yaw += 360;
		if (pitch < 0)
			pitch += 360;
		float yawChange = Math.max(playerYaw, yaw) - Math.min(playerYaw, yaw);
		float pitchChange = Math.max(playerPitch, pitch) - Math.min(playerPitch, pitch);
		return yawChange + pitchChange;
	}

	/**
	 * @param entityIn The entity to get rotations to.
	 * @return The needed rotations to entityIn.
	 */
	public static float[] getNeededRotations(EntityLivingBase entityIn) {
		double d0 = entityIn.posX - mc.thePlayer.posX;
		double d1 = entityIn.posZ - mc.thePlayer.posZ;
		double d2 = entityIn.posY + entityIn.getEyeHeight() - (mc.thePlayer.getEntityBoundingBox().minY + mc.thePlayer.getEyeHeight());

		double d3 = MathHelper.sqrt_double(d0 * d0 + d1 * d1);
		float f = (float) (MathHelper.func_181159_b(d1, d0) * 180.0D / Math.PI) - 90.0F;
		float f1 = (float) (-(MathHelper.func_181159_b(d2, d3) * 180.0D / Math.PI));
		return new float[]{f, f1};
	}

	/**
	 * @param entityIn     The entity to get rotations to.
	 * @param speed        How fast the rotations are.
	 * @return Rotations to entityIn with speed.
	 */
	public static float[] getRotations(EntityLivingBase entityIn, float speed) {
		float yaw = updateRotation(mc.thePlayer.rotationYaw,
				getNeededRotations(entityIn)[0],
				speed);
		float pitch = updateRotation(mc.thePlayer.rotationPitch,
				getNeededRotations(entityIn)[1],
				speed);
		return new float[]{yaw, pitch};
	}

	private static float updateRotation(float currentRotation, float intendedRotation, float increment) {
		float f = MathHelper.wrapAngleTo180_float(intendedRotation - currentRotation);

		if (f > increment)
			f = increment;

		if (f < -increment)
			f = -increment;

		return currentRotation + f;
	}

	private static MovingObjectPosition tracePath(final World world, final float x, final float y, final float z, final float tx, final float ty, final float tz, final float borderSize, final HashSet<Entity> excluded) {
		Vec3 startVec = new Vec3(x, y, z);
		Vec3 endVec = new Vec3(tx, ty, tz);
		final float minX = (x < tx) ? x : tx;
		final float minY = (y < ty) ? y : ty;
		final float minZ = (z < tz) ? z : tz;
		final float maxX = (x > tx) ? x : tx;
		final float maxY = (y > ty) ? y : ty;
		final float maxZ = (z > tz) ? z : tz;
		final AxisAlignedBB bb = new AxisAlignedBB(minX, minY, minZ, maxX, maxY, maxZ).expand(borderSize, borderSize, borderSize);
		final ArrayList<Entity> allEntities = (ArrayList<Entity>) world.getEntitiesWithinAABBExcludingEntity(null, bb);
		MovingObjectPosition blockHit = world.rayTraceBlocks(startVec, endVec);
		startVec = new Vec3(x, y, z);
		endVec = new Vec3(tx, ty, tz);
		Entity closestHitEntity = null;
		float closestHit = Float.POSITIVE_INFINITY;
		float currentHit;
		for (final Entity ent : allEntities) {
			if (ent.canBeCollidedWith() && !excluded.contains(ent)) {
				final float entBorder = ent.getCollisionBorderSize();
				AxisAlignedBB entityBb = ent.getEntityBoundingBox();
				if (entityBb == null) {
					continue;
				}
				entityBb = entityBb.expand(entBorder, entBorder, entBorder);
				final MovingObjectPosition intercept = entityBb.calculateIntercept(startVec, endVec);
				if (intercept == null) {
					continue;
				}
				currentHit = (float) intercept.hitVec.distanceTo(startVec);
				if (currentHit >= closestHit && currentHit != 0.0f) {
					continue;
				}
				closestHit = currentHit;
				closestHitEntity = ent;
			}
		}
		if (closestHitEntity != null) {
			blockHit = new MovingObjectPosition(closestHitEntity);
		}
		return blockHit;
	}

	private static MovingObjectPosition tracePathD(final World w, final double posX, final double posY, final double posZ, final double v, final double v1, final double v2, final float borderSize, final HashSet<Entity> exclude) {
		return tracePath(w, (float) posX, (float) posY, (float) posZ, (float) v, (float) v1, (float) v2, borderSize, exclude);
	}

	public static MovingObjectPosition rayCast(final EntityPlayerSP player, final double x, final double y, final double z) {
		final HashSet<Entity> excluded = new HashSet<>();
		excluded.add(player);
		return tracePathD(player.worldObj, player.posX, player.posY + player.getEyeHeight(), player.posZ, x, y, z, 1.0f, excluded);
	}

	public static float getDistanceToEntity(EntityLivingBase entityLivingBase) {
		return mc.thePlayer.getDistanceToEntity(entityLivingBase);
	}

	public static boolean isInLiquid() {
		return mc.thePlayer.isInWater() || mc.thePlayer.isInLava();
	}

}