package dev.windhook.utils.ts;

import net.minecraft.entity.Entity;

@FunctionalInterface
public interface ICheck {
    boolean validate(Entity var1);
}