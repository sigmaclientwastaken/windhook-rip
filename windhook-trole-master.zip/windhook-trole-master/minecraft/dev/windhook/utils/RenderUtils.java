package dev.windhook.utils;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;

import com.jhlabs.image.BoxBlurFilter;
import com.jhlabs.image.GaussianFilter;
import dev.windhook.BaseClient;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.modules.semi_hidden.BlurBuffer;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.TextureUtil;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

import dev.windhook.font.Font;
import dev.windhook.font.UnicodeFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;

public class RenderUtils {

	public static float partialTicks = 1f;

	public static Font getFontRenderer() {
		return BaseClient.instance.getFontRenderer();
	}

	public static void renderItem(int xPos, int yPos, ItemStack itemStack) {
		GuiIngame guiInGame = Minecraft.getMinecraft().ingameGUI;

		if (guiInGame == null)
			return;

		if (itemStack == null)
			return;

		RenderItem itemRenderer = guiInGame.itemRenderer;

		Minecraft.getMinecraft().getTextureManager().bindTexture(guiInGame.getWidgetsTexPath());

		GlStateManager.enableRescaleNormal();
		GlStateManager.enableBlend();
		GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
		RenderHelper.enableGUIStandardItemLighting();

		RenderHelper.enableGUIStandardItemLighting();
		itemRenderer.renderItemAndEffectIntoGUI(itemStack, xPos, yPos);

		itemRenderer.renderItemOverlayIntoGUI(Minecraft.getMinecraft().fontRendererObj, itemStack, xPos, yPos, "");
		RenderHelper.disableStandardItemLighting();

		RenderHelper.disableStandardItemLighting();
		GlStateManager.disableRescaleNormal();
		GlStateManager.disableBlend();
	}

	public static void drawString(String text, int x, int y, int color, boolean shadow, UnicodeFontRenderer font) {
		if (color == -1)
			color = Color.WHITE.getRGB();

		text = Strings.simpleTranslateColors(text);
		if (shadow)
			font.drawStringWithShadow(text, x, y, color);
		else
			font.drawString(text, x, y, color);
	}

	public static void drawString(String text, int x, int y, int color, int fontSize, boolean shadow) {
		drawString(text, x, y, color, shadow, getFontRenderer().getFont(fontSize));
	}

	public static void drawString(String text, int x, int y, int color, boolean shadow) {
		drawString(text, x, y, color, getFontRenderer().getFontSize(), shadow);
	}

	public static void drawString(String text, int x, int y, int color, int fontSize) {
		drawString(text, x, y, color, fontSize, true);
	}

	public static void drawString(String text, int x, int y, int color) {
		if (color == -1)
			color = Color.WHITE.getRGB();
		drawString(text, x, y, color, true);
	}

	public static void drawStringFromTopRight(String text, int x, int y, int color, int fontSize, boolean shadow) {
		drawString(text, getScaledResolution().getScaledWidth() - Strings.getStringWidthCFR(text) - x, y, color,
				shadow);
	}

	public static void drawStringFromTopRight(String text, int x, int y, int color, boolean shadow) {
		drawStringFromTopRight(text, x, y, color, getFontRenderer().getFontSize(), shadow);
	}

	public static void drawStringFromTopRight(String text, int x, int y, int color, int fontSize) {
		drawStringFromTopRight(text, x, y, color, fontSize, true);
	}

	public static void drawStringFromTopRight(String text, int x, int y, int color) {
		drawStringFromTopRight(text, x, y, color, getFontRenderer().getFontSize(), true);
	}

	public static void drawStringFromBottomRight(String text, int x, int y, int color, int fontSize, boolean shadow) {
		drawStringFromTopRight(text, x, getScaledResolution().getScaledHeight() - y * 2, color, fontSize, shadow);
	}

	public static void drawStringFromBottomRight(String text, int x, int y, int color, boolean shadow) {
		drawStringFromBottomRight(text, x, y, color, getFontRenderer().getFontSize(), true);
	}

	public static void drawStringFromBottomRight(String text, int x, int y, int color, int fontSize) {
		drawStringFromBottomRight(text, x, y, color, fontSize, true);
	}

	public static void drawStringFromBottomRight(String text, int x, int y, int color) {
		drawStringFromBottomRight(text, x, y, color, getFontRenderer().getFontSize());
	}

	public static void drawStringFromBottomLeft(String text, int x, int y, int color) {
		drawStringFromBottomLeft(text, x, y, color, getFontRenderer().getFontSize(), true);
	}

	public static void drawStringFromBottomLeft(String text, int x, int y, int color, int fontSize) {
		drawStringFromBottomLeft(text, x, y, color, fontSize, true);
	}

	public static void drawStringFromBottomLeft(String text, int x, int y, int color, int fontSize, boolean shadow) {
		drawString(text, x, getScaledResolution().getScaledHeight() - y * 2, color, fontSize, shadow);
	}

	public static void drawRect(int left, int top, int right, int bottom, int color) {
		Gui.drawRect(left, top, right, bottom, color);
	}

	public static void drawModalRect(int xCord, int yCord, int width, int height, int color) {
		Gui.drawRect(xCord, getScaledResolution().getScaledHeight() - yCord, xCord + width,
				getScaledResolution().getScaledHeight() - yCord - height, color);
	}

	public static void drawModalRectFromRight(int xCord, int yCord, int width, int height, int color) {
		drawModalRect(getScaledResolution().getScaledWidth() - xCord, yCord, width, height, color);
	}

	public static void drawModalRectFromTopRight(int xCord, int yCord, int width, int height, int color) {
		Gui.drawRect(getScaledResolution().getScaledWidth() - xCord, yCord,
				getScaledResolution().getScaledWidth() - xCord + width, yCord + height, color);
	}

	public static void drawModalRectFromTopLeft(int xCord, int yCord, int width, int height, int color) {
		Gui.drawRect(xCord, yCord, xCord + width, yCord + height, color);
	}

	public static void drawGradientRect(int left, int top, int right, int bottom, int startColor, int endColor) {
		Gui.drawGradientRect(left, top, right, bottom, startColor, endColor);
	}

	public static void drawModalGradientRectFromTopRight(int xCord, int yCord, int width, int height, int startColor,
			int endColor) {
		Gui.drawGradientRect(getScaledResolution().getScaledWidth() - xCord, yCord,
				getScaledResolution().getScaledWidth() - xCord + width, yCord + height, startColor, endColor);
	}

	public static void drawModalGradientRectFromTopLeft(int xCord, int yCord, int width, int height, int startColor,
			int endColor) {
		Gui.drawGradientRect(xCord, yCord, xCord + width, yCord + height, startColor, endColor);
	}

	public static void drawModalGradientRect(int xCord, int yCord, int width, int height, int startColor,
			int endColor) {
		Gui.drawGradientRect(xCord, getScaledResolution().getScaledHeight() - yCord, xCord + width,
				getScaledResolution().getScaledHeight() - yCord - height, startColor, endColor);
	}

	public static ScaledResolution getScaledResolution() {
		return new ScaledResolution(Minecraft.getMinecraft());
	}

	public static void drawOutlinedBoundingBox(AxisAlignedBB aa) {
		int[] colors = new int[] { 10, 0, 30, 15 };
		Tessellator tessellator = Tessellator.getInstance();
		WorldRenderer worldRenderer = tessellator.getWorldRenderer();

//		worldRenderer.begin(3, DefaultVertexFormats.POSITION_COLOR);
//		worldRenderer.pos(-259, 102, 19).endVertex();
//		worldRenderer.pos(-259, 104, 17).endVertex();
//		worldRenderer.pos(-257, 102, 19).endVertex();
//		worldRenderer.pos(-257, 104, 19).endVertex();
//		tessellator.draw();

		worldRenderer.begin(3, DefaultVertexFormats.POSITION_COLOR);
		worldRenderer.pos(aa.minX, aa.minY, aa.minZ).color(colors[0], colors[1], colors[2], colors[3]).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).color(colors[0], colors[1], colors[2], colors[3]).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).color(colors[0], colors[1], colors[2], colors[3]).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).color(colors[0], colors[1], colors[2], colors[3]).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.minZ).color(colors[0], colors[1], colors[2], colors[3]).endVertex();
		tessellator.draw();
		worldRenderer.begin(3, DefaultVertexFormats.POSITION_COLOR);
		worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).color(colors[0], colors[1], colors[2], colors[3]).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).color(colors[0], colors[1], colors[2], colors[3]).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).color(colors[0], colors[1], colors[2], colors[3]).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).color(colors[0], colors[1], colors[2], colors[3]).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).color(colors[0], colors[1], colors[2], colors[3]).endVertex();
		tessellator.draw();
		worldRenderer.begin(1, DefaultVertexFormats.POSITION_COLOR);
		worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
		tessellator.draw();
	}

	public static void drawBoundingBox(AxisAlignedBB aa) {
		Tessellator tessellator = Tessellator.getInstance();
		WorldRenderer worldRenderer = tessellator.getWorldRenderer();
		worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
		worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
		tessellator.draw();
		worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
		worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
		tessellator.draw();
		worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
		worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
		tessellator.draw();
		worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
		worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ);
		worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
		tessellator.draw();
		worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
		worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
		tessellator.draw();
		worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
		worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.minZ);
		worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
		worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
		tessellator.draw();
	}

	public static void drawOutlinedBlockESP(double x, double y, double z, float red, float green, float blue,
			float alpha, float lineWidth) {
		GL11.glPushMatrix();
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(770, 771);
		// GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(false);
		GL11.glLineWidth(lineWidth);
		GL11.glColor4f(red, green, blue, alpha);
		drawOutlinedBoundingBox(new AxisAlignedBB(x, y, z, x + 1D, y + 1D, z + 1D));
		GL11.glDisable(GL11.GL_LINE_SMOOTH);
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		// GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(true);
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glPopMatrix();
	}

	public static void drawBlockESP(double x, double y, double z, float red, float green, float blue, float alpha,
			float lineRed, float lineGreen, float lineBlue, float lineAlpha, float lineWidth) {
		GL11.glPushMatrix();
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(770, 771);
		// GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(false);
		GL11.glColor4f(red, green, blue, alpha);
		drawBoundingBox(new AxisAlignedBB(x, y, z, x + 1D, y + 1D, z + 1D));
		GL11.glLineWidth(lineWidth);
		GL11.glColor4f(lineRed, lineGreen, lineBlue, lineAlpha);
		drawOutlinedBoundingBox(new AxisAlignedBB(x, y, z, x + 1D, y + 1D, z + 1D));
		GL11.glDisable(GL11.GL_LINE_SMOOTH);
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		// GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(true);
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glPopMatrix();
	}

	public static void drawSolidBlockESP(double x, double y, double z, float red, float green, float blue,
			float alpha) {
		GL11.glPushMatrix();
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(770, 771);
		// GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(false);
		GL11.glColor4f(red, green, blue, alpha);
		drawBoundingBox(new AxisAlignedBB(x, y, z, x + 1D, y + 1D, z + 1D));
		GL11.glDisable(GL11.GL_LINE_SMOOTH);
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		// GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(true);
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glPopMatrix();
	}

	public static void drawOutlinedEntityESP(double x, double y, double z, double width, double height, float red,
			float green, float blue, float alpha) {
		GL11.glPushMatrix();
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(770, 771);
		// GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(false);
		GL11.glColor4f(red, green, blue, alpha);
		drawOutlinedBoundingBox(new AxisAlignedBB(x - width, y, z - width, x + width, y + height, z + width));
		GL11.glDisable(GL11.GL_LINE_SMOOTH);
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		// GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(true);
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glPopMatrix();
	}

	public static void drawSolidEntityESP(double x, double y, double z, double width, double height, float red,
			float green, float blue, float alpha) {
		GL11.glPushMatrix();
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(770, 771);
		// GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(false);
		GL11.glColor4f(red, green, blue, alpha);
		drawBoundingBox(new AxisAlignedBB(x - width, y, z - width, x + width, y + height, z + width));
		GL11.glDisable(GL11.GL_LINE_SMOOTH);
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		// GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(true);
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glPopMatrix();
	}

	public static void drawEntityESP(double x, double y, double z, double width, double height, float red, float green,
			float blue, float alpha, float lineRed, float lineGreen, float lineBlue, float lineAlpha, float lineWdith) {
		GL11.glPushMatrix();
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(770, 771);
		// GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(false);
		GL11.glColor4f(red, green, blue, alpha);
		drawBoundingBox(new AxisAlignedBB(x - width, y, z - width, x + width, y + height, z + width));
		GL11.glLineWidth(lineWdith);
		GL11.glColor4f(lineRed, lineGreen, lineBlue, lineAlpha);
		drawOutlinedBoundingBox(new AxisAlignedBB(x - width, y, z - width, x + width, y + height, z + width));
		GL11.glDisable(GL11.GL_LINE_SMOOTH);
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		// GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(true);
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glPopMatrix();
	}

	public static void drawTracerLine(double x, double y, double z, float red, float green, float blue, float alpha,
			float lineWdith) {
		GL11.glPushMatrix();
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
//		GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glBlendFunc(770, 771);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glLineWidth(lineWdith);
		GL11.glColor4f(red, green, blue, alpha);
		GL11.glBegin(2);
		GL11.glVertex3d(0.0D, 0.0D + Minecraft.getMinecraft().thePlayer.getEyeHeight() - 0.2, 0.0D);
		GL11.glVertex3d(x, y, z);
		GL11.glEnd();
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDisable(GL11.GL_LINE_SMOOTH);
		GL11.glDisable(GL11.GL_BLEND);
//		GL11.glEnable(GL11.GL_LIGHTING);
		GL11.glPopMatrix();
	}

	public static void renderBoundingBox(Entity entityIn, double x, double y, double z, float partialTicks, int red,
			int green, int blue, double xAdd, double yAdd, double zAdd) {
		GlStateManager.depthMask(false);
		GlStateManager.disableTexture2D();
		GlStateManager.disableLighting();
		GlStateManager.disableCull();
		GlStateManager.disableBlend();
		GlStateManager.disableDepth();
		AxisAlignedBB axisalignedbb = entityIn.getEntityBoundingBox();
		AxisAlignedBB axisalignedbb1 = new AxisAlignedBB(axisalignedbb.minX + xAdd - entityIn.posX + x,
				axisalignedbb.minY - entityIn.posY + y, axisalignedbb.minZ + zAdd - entityIn.posZ + z,
				axisalignedbb.maxX - xAdd - entityIn.posX + x, axisalignedbb.maxY + yAdd - entityIn.posY + y,
				axisalignedbb.maxZ - zAdd - entityIn.posZ + z);

		RenderGlobal.func_181563_a(axisalignedbb1, red, green, blue, 255);

//		Tessellator tessellator = Tessellator.getInstance();
//		WorldRenderer worldrenderer = tessellator.getWorldRenderer();
		GlStateManager.enableTexture2D();
		GlStateManager.enableLighting();
		GlStateManager.enableCull();
		GlStateManager.disableBlend();
		GlStateManager.enableDepth();
		GlStateManager.depthMask(true);
	}

	public static void renderPlayerESP(Entity entityIn, double x, double y, double z, int red, int green, int blue,
			float partialTicks) {
		renderBoundingBox(entityIn, x, y, z, partialTicks, red, green, blue, 0.75, 0.15, 0.75);
	}

	public static void renderItemsESP(Entity entityIn, double x, double y, double z, float partialTicks) {
		int red = 150;
		int green = 20;
		int blue = 150;

		renderBoundingBox(entityIn, x, y, z, partialTicks, red, green, blue, 0.35, 0.30, 0.35);
	}


	public static void drawBlurBuffer(int x1, int y1, int x2, int y2, boolean setupOverlayRendering) {
		Minecraft mc = Minecraft.getMinecraft();
		ScaledResolution resolution = new ScaledResolution(mc);
		GL11.glEnable(GL11.GL_SCISSOR_TEST);
		scissorHelper(x1, y1, x2, y2);
		drawBlurBuffer(setupOverlayRendering);
		GL11.glDisable(GL11.GL_SCISSOR_TEST);
	}

	public static void drawBlurBuffer(boolean setupOverlayRendering) {
		GL11.glPushMatrix();
		BlurBuffer.blurBuffer.framebufferRenderExt(Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight, true);
		GL11.glPopMatrix();
		if(setupOverlayRendering) {
			Minecraft.getMinecraft().entityRenderer.setupOverlayRendering();
		}
		GlStateManager.enableDepth();
	}

	public static void updateBlurBuffer(boolean setupOverlayRendering) {
		Minecraft mc = Minecraft.getMinecraft();

		if(mc.thePlayer != null && mc.thePlayer.ticksExisted > 10 && BlurBuffer.blurBufferTimer.hasTimeElapsed(1000 / 60, true)) {
			mc.getFramebuffer().unbindFramebuffer();

			BlurBuffer.blurBuffer.bindFramebuffer(true);

			mc.getFramebuffer().framebufferRenderExt(mc.displayWidth, mc.displayHeight, true);

			if (OpenGlHelper.shadersSupported) {
				if (BlurBuffer.getBlurShaderGroup() != null)
				{
					BlurBuffer.setBlurBufferRendered();
					GlStateManager.matrixMode(5890);
					GlStateManager.pushMatrix();
					GlStateManager.loadIdentity();
					BlurBuffer.getBlurShaderGroup().loadShaderGroup(partialTicks);
					GlStateManager.popMatrix();
				}
			}

			BlurBuffer.blurBuffer.unbindFramebuffer();
			mc.getFramebuffer().bindFramebuffer(true);

			if(setupOverlayRendering) {
				mc.entityRenderer.setupOverlayRendering();
			}
		}
	}

	public static void scissorHelper(int x1, int y1, int x2, int y2) {
		x2 -= x1;
		y2 -= y1;
		Minecraft mc = Minecraft.getMinecraft();
		ScaledResolution resolution = new ScaledResolution(mc);
		GL11.glScissor(x1 * resolution.getScaleFactor(),
				mc.displayHeight - y1 * resolution.getScaleFactor() - y2 * resolution.getScaleFactor(),
				x2 * resolution.getScaleFactor(),
				y2 * resolution.getScaleFactor()
		);
	}

	public static void drawBlurredShadow(int x, int y, int width, int height, int blurRadius) {
		drawBlurredShadow(x, y, width, height, blurRadius, new Color(0, 0, 0, 100));
	}

	private static HashMap<Integer, Integer> shadowCache = new HashMap<Integer, Integer>();

	public static void drawBlurredShadow(int x, int y, int width, int height, int blurRadius, Color color) {

		GlStateManager.alphaFunc(GL11.GL_GREATER, 0.01f);

		width = width + blurRadius * 2;
		height = height + blurRadius * 2;
		x = x - blurRadius;
		y = y - blurRadius;

		float _X = x - 0.25f;
		float _Y = y + 0.25f;

		int identifier = width * height + width + color.hashCode() * blurRadius + blurRadius;

		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glDisable(GL11.GL_CULL_FACE);
		GL11.glEnable(GL11.GL_ALPHA_TEST);
		GL11.glEnable(GL11.GL_BLEND);

		int texId = -1;
		if(shadowCache.containsKey(identifier)) {
			texId = shadowCache.get(identifier);

			GlStateManager.bindTexture(texId);
		}
		else {
			BufferedImage original = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

			Graphics g = original.getGraphics();
			g.setColor(color);
			g.fillRect(blurRadius, blurRadius, width - blurRadius * 2, height - blurRadius * 2);
			g.dispose();

			GaussianFilter op = new GaussianFilter(blurRadius);

			BufferedImage blurred = op.filter(original, null);

			texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
			shadowCache.put(identifier, texId);
		}

		GL11.glColor4f(1f, 1f, 1f, 1f);

		GL11.glBegin(GL11.GL_QUADS);
		GL11.glTexCoord2f(0, 0); // top left
		GL11.glVertex2f(_X, _Y);

		GL11.glTexCoord2f(0, 1); // bottom left
		GL11.glVertex2f(_X, _Y + height);

		GL11.glTexCoord2f(1, 1); // bottom right
		GL11.glVertex2f(_X + width, _Y + height);

		GL11.glTexCoord2f(1, 0); // top right
		GL11.glVertex2f(_X + width, _Y);
		GL11.glEnd();

		GL11.glDisable(GL11.GL_TEXTURE_2D);
	}

	public static HashMap<Integer, Integer> blurSpotCache = new HashMap<Integer, Integer>();

	public static void blurSpot(int x, int y, int width, int height, int blurRadius, int iterations) {
		Minecraft mc = Minecraft.getMinecraft();
		ScaledResolution sr = new ScaledResolution(mc);
		double scale = 1d / sr.getScaleFactor();

		width*=sr.getScaleFactor();
		height*=sr.getScaleFactor();

		int imageDownscale = 2;

		final int imageWidth = width / imageDownscale;
		final int imageHeight = height / imageDownscale;

		int bpp = 3; // Assuming a 32-bit display with a byte each for red, green, blue, and alpha.

		int identifier = (x * y * width * height * blurRadius) + width + height + blurRadius + x + y;

		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glDisable(GL11.GL_CULL_FACE);
		GL11.glEnable(GL11.GL_ALPHA_TEST);
		GL11.glEnable(GL11.GL_BLEND);

		int texId = -1;
		if(blurSpotCache.containsKey(identifier)) {
			texId = blurSpotCache.get(identifier);

			GlStateManager.bindTexture(texId);
		}
		else {

			ByteBuffer buffer = BufferUtils.createByteBuffer(width * height * bpp).order(ByteOrder.nativeOrder());
			GL11.glReadPixels(x, mc.displayHeight - y - height, width, height, GL11.GL_RGB, GL11.GL_UNSIGNED_BYTE, buffer );

			BufferedImage original = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

			for(int xIndex = 0; xIndex < width; xIndex++)
			{
				for(int yIndex = 0; yIndex < height; yIndex++)
				{
					int i = (xIndex + (width * yIndex)) * bpp;
					int r = buffer.get(i) & 0xFF;
					int g = buffer.get(i + 1) & 0xFF;
					int b = buffer.get(i + 2) & 0xFF;
					original.setRGB(xIndex, height - (yIndex + 1), (0xFF << 24) | (r << 16) | (g << 8) | b);
				}
			}

			BoxBlurFilter op = new BoxBlurFilter(blurRadius, blurRadius, iterations);

			BufferedImage image = new BufferedImage(imageWidth, imageHeight, original.getType());
			Graphics g = image.getGraphics();
			g.drawImage(original, 0, 0, imageWidth, imageHeight, null);
			g.dispose();

			BufferedImage blurred = op.filter(image, null);

			texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
			blurSpotCache.put(identifier, texId);
		}

		GL11.glPushMatrix();
		GL11.glScaled(scale, scale, scale);
		GL11.glColor4f(1f, 1f, 1f, 1f);

		GL11.glBegin(GL11.GL_QUADS);
		GL11.glTexCoord2f(0, 0); // top left
		GL11.glVertex2f(x, y);

		GL11.glTexCoord2f(0, 1); // bottom left
		GL11.glVertex2f(x, y + height);

		GL11.glTexCoord2f(1, 1); // bottom right
		GL11.glVertex2f(x + width, y + height);

		GL11.glTexCoord2f(1, 0); // top right
		GL11.glVertex2f(x + width, y);
		GL11.glEnd();

		GL11.glPopMatrix();

		GL11.glDisable(GL11.GL_TEXTURE_2D);

	}

	public static void drawFullCircle(float cx, float cy, float r, final int c) {
		r *= 2.0f;
		cx *= 2.0f;
		cy *= 2.0f;
		final float theta = 0.19634953f;
		final float p = (float) Math.cos(theta);
		final float s = (float) Math.sin(theta);
		float x = r;
		float y = 0.0f;
		enableGL2D();
		GL11.glEnable(2848);
		GL11.glHint(3154, 4354);
		GL11.glEnable(3024);
		GL11.glScalef(0.5f, 0.5f, 0.5f);
		glColor(c);
		GL11.glBegin(9);
		for (int ii = 0; ii < 32; ++ii) {
			GL11.glVertex2f(x + cx, y + cy);
			float t = x;
			x = p * x - s * y;
			y = s * t + p * y;
		}
		GL11.glEnd();
		GL11.glScalef(2.0f, 2.0f, 2.0f);
		GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
		disableGL2D();
	}

	static void enableGL2D() {
		GL11.glDisable(2929);
		GL11.glEnable(3042);
		GL11.glDisable(3553);
		GL11.glBlendFunc(770, 771);
		GL11.glDepthMask(true);
		GL11.glEnable(2848);
		GL11.glHint(3154, 4354);
		GL11.glHint(3155, 4354);
	}

	public static void disableGL2D() {
		GL11.glEnable(3553);
		GL11.glDisable(3042);
		GL11.glDisable(2848);
		GL11.glHint(3154, 4352);
		GL11.glHint(3155, 4352);
	}

	public static void glColor(final int hex) {
		final float alpha = (hex >> 24 & 0xFF) / 255.0f;
		final float red = (hex >> 16 & 0xFF) / 255.0f;
		final float green = (hex >> 8 & 0xFF) / 255.0f;
		final float blue = (hex & 0xFF) / 255.0f;
		GL11.glColor4f(red, green, blue, alpha);
	}

}