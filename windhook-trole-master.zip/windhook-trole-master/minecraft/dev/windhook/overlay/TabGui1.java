package dev.windhook.overlay;

import java.awt.Color;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import dev.windhook.BaseClient;
import dev.windhook.gui.clickgui.ClickGui;
import dev.windhook.gui.clickgui.GuiBind;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.utils.*;
import org.lwjgl.input.Keyboard;

import dev.windhook.event.EventListener;
import dev.windhook.event.events.KeyPressedEvent;
import dev.windhook.event.events.MouseClickEvent;
import dev.windhook.event.events.MouseScrollEvent;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.ModuleSettings;
import dev.windhook.module.modules.client.TabGui;
import dev.windhook.module.modules.semi_hidden.AdvancedTabGui;
import dev.windhook.utils.animation.basic.Translate;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.opengl.GL11;

public class TabGui1 extends EventListener {

	private int currentCategory;
	private int currentModule;
	private int currentSetting;

	private Translate translator = new Translate(0, 0);

	private String[] moduleSettingsExceptions;

	/**
	 * @formatter:off
	 * 
	 * 0 = Categories
	 * 1 = Modules
	 * 2 = Module Settings
	 * 
	 * @formatter:on
	 **/
	private int indentation;

	private int maxItemWidth;

	private ModuleManager moduleManager;

	public TabGui1() {
		BaseClient.instance.getEventManager().registerListener(this);
		this.moduleManager = BaseClient.instance.getModuleManager();

		this.moduleSettingsExceptions = new String[] { "toggled", "key" };
	}

	/**
	 * @return The current mode, 0 = default mode (ARROW KEYS), 1 = "Advanced" mode
	 *         (MOUSE WHEEL (CAN BE BOUND) AND MOUSE CLICKS)
	 */
	private int getMode() {
		return (BaseClient.instance.getModuleManager().getModule(AdvancedTabGui.class).isToggled() ? 1 : 0);
	}

	private List<Module> getModules() {
		return moduleManager.getModules(Category.values()[currentCategory]);
	}

	private Module getCurrentModule() {
		int modulesSize = getModules().size();
		if (modulesSize <= currentModule)
			currentModule = modulesSize;

		return getModules().get(currentModule);
	}

	private List<String> getCurrentSettingsList() {
		return /* getCurrentModule().getModuleSettings().getConfig().readLines() */ null;
	}

	private List<String> getFilteredSettingsList() {
		List<String> settings = getCurrentSettingsList().stream().distinct().collect(Collectors.toList());
		for (int i = 0; i < moduleSettingsExceptions.length; i++) {
			for (int j = 0; j < settings.size(); j++) {
				String setting = settings.get(j);
				setting = setting.substring(0, setting.indexOf(":"));

				if (moduleSettingsExceptions[i].equalsIgnoreCase(setting))
					settings.remove(j);
			}
		}

		return settings;
	}

	private String getCurrentSettings() {
		return getCurrentSettingsList().get(currentSetting);
	}

	private String getCurrentSettingsFiltered() {
		return getFilteredSettingsList().get(currentSetting);
	}

	private ModuleSettings getCurrentModuleSettings() {
		return /* getCurrentModule().getModuleSettings() */ null;
	}

	@Override
	public void onRender2D(Render2DEvent event) {
		if (!(BaseClient.instance.getModuleManager().getModule(TabGui.class)).isToggled())
			return;

		GuiScreen currentScreen = mc.currentScreen;

		if (currentScreen != null && (currentScreen instanceof ClickGui || currentScreen instanceof GuiBind))
			return;

		// TODO: Render ICON

		switch (indentation) {
		/** If inside the Category indentation draw it */
		case 0:
		default: {
			renderCategories(event);
			break;
		}
		/** If inside the Module indentation draw it */
		case 1: {
			renderModules(event);
			break;
		}
		/** If inside the Module Settings indentation draw it */
		case 3:
		case 2: {
			renderSettings(event);
			break;
		}

		}
	}

	/**
	 * @formatter:off
	 * @param direction 0 means the direction means DOWN and 1 means the direction is UP
	 * @formatter:on
	 */
	private void menuScroll(int direction) {
		if (!(BaseClient.instance.getModuleManager().getModule(TabGui.class).isToggled()))
			return;

		if (indentation == 3) {
			String[] currentSetting = getCurrentSettingsFiltered().split(": ");

			String key = currentSetting[0];
			String value = currentSetting[1];

			if (Integers.isInteger(value)) {
				int v = Integers.getInteger(value);
				v += (direction == 0 ? -1 : 1);
			/*	getCurrentModule().getModuleSettings().set(key, v); */
			} else if (Integers.isDouble(value)) {
				double v = Double.parseDouble(value);
				double incr = mc.gameSettings.keyBindSneak.isKeyDown() ? 1 : 0.1D;
				v += (direction == 0 ? -incr : incr);

				v = Double.valueOf(new DecimalFormat("#.#").format(v).replace(",", "."));

				if (v < 0)
					v = 0.0D;

				if (!(Double.toString(v).contains(".")))
					v = Double.parseDouble(v + ".0");

			/*	getCurrentModule().getModuleSettings().set(key, v); */
			} else if (Strings.isBoolean(value)) {
				boolean v = Strings.getBooleanValue(value);
				v = !v;
			/*	getCurrentModule().getModuleSettings().set(key, v); */
			}

			maxItemWidth = 0;
			return;
		}

		switch (indentation) {
		/** If inside the Category indentation scroll through it */
		case 0:
		default: {
			currentCategory = (direction == 0
					? (currentCategory == Category.values().length - 3 ? 0 : currentCategory + 1)
					: (currentCategory == 0 ? Category.values().length - 3 : currentCategory - 1));
			break;
		}
		/** If inside the Module indentation scroll through it */
		case 1: {
			currentModule = (direction == 0 ? (currentModule == getModules().size() - 1 ? 0 : currentModule + 1)
					: (currentModule == 0 ? getModules().size() - 1 : currentModule - 1));
			break;
		}
		case 2:
		case 3: {
			currentSetting = (direction == 0
					? (currentSetting == getFilteredSettingsList().size() - 1 ? 0 : currentSetting + 1)
					: (currentSetting == 0 ? getFilteredSettingsList().size() - 1 : currentSetting - 1));
			break;
		}
		}
	}

	/**
	 * @formatter:off
	 * @param direction 0 means LEFT and 1 means RIGHT
	 * @formatter:on
	 */
	private void menuInteract(int direction) {
		if (!(BaseClient.instance.getModuleManager().getModule(TabGui.class).isToggled()))
			return;

		if (indentation == 3) {
			indentation -= 2;
			menuInteract(1);
			return;
		}

		boolean next = (indentation == 0 && getModules().size() == 0 ? false
				: (indentation == 1 && getCurrentSettingsList().size() == 0 ? false : true));

		if (indentation == 0 && getModules().size() == 0)
			next = false;

		if (indentation == 1) {
			if (getFilteredSettingsList().size() == 0)
				next = false;
			else {
				List<String> moduleSettings = getFilteredSettingsList();
				next = false;
				for (int i = 0; i < moduleSettings.size(); i++) {
					String moduleSetting = moduleSettings.get(i);
					next = true;
					break;
				}
			}
		}

		int difference = (direction == 0 ? (indentation == 0 ? 0 : (indentation == 3 ? 0 : -1)) : (next ? 1 : 0));

		indentation += difference;

		if (indentation < 2)
			currentSetting = 0;
		if (indentation < 1)
			currentModule = 0;

		maxItemWidth = (difference == 0 ? maxItemWidth : 0);
	}

	@Override
	public void onKeyPressed(KeyPressedEvent event) {
		if(event.getKey() == Keyboard.KEY_INSERT){
			menuInteract(0);
		}

		if (event.getKey() == Keyboard.KEY_RETURN && indentation == 1) {
			getCurrentModule().toggle();
			return;
		}

		if (getMode() != 0)
			return;

		switch (event.getKey()) {
		case Keyboard.KEY_UP: {
			menuScroll(1);
			break;
		}
		case Keyboard.KEY_DOWN: {
			menuScroll(0);
			break;
		}
		case Keyboard.KEY_BACK:
		case Keyboard.KEY_LEFT: {
			menuInteract(0);
			break;
		}
		case Keyboard.KEY_RIGHT: {
			menuInteract(1);
			break;
		}
		default: {
			return;
		}
		}
	}

	@Override
	public void onMouseScroll(MouseScrollEvent event) {
		if (getMode() != 1)
			return;

		event.setCancelled(true);

		switch (event.getDirection()) {
		case 120: {
			menuScroll(1);
			break;
		}
		case 240: {
			menuScroll(1);
			menuScroll(1);
		}
		case -120: {
			menuScroll(0);
			break;
		}
		case -240: {
			menuScroll(0);
			menuScroll(0);
			break;
		}
		default: {
			return;
		}
		}
	}

	@Override
	public void onMouseClick(MouseClickEvent event) {
		if (getMode() != 1)
			return;

		switch (event.getButton()) {
		case 1: {
			menuInteract(0);
			break;
		}
		case 0: {
			menuInteract(1);
			break;
		}
		case 4: {
			if (!(indentation == 1))
				break;

			getCurrentModule().toggle();
		}
		default:
			return;
		}

	}

	private void renderCategories(Render2DEvent event) {
		List<String> items = new ArrayList<String>();

		Category[] categories = Category.values();
		for (int i = 0; i < categories.length; i++) {
			Category category = categories[i];

			if (category.equals(Category.HIDDEN) || category.equals(Category.SEMI_HIDDEN))
				continue;

			items.add(Strings.capitalizeOnlyFirstLetter(category.name()));
		}
		renderMenu(items, currentCategory);
	}

	private void renderModules(Render2DEvent event) {
		List<Module> modules = new ArrayList<Module>(getModules());

		List<String> items = new ArrayList<String>();
		for (int i = 0; i < modules.size(); i++) {
			Module module = modules.get(i);
			items.add((module.isToggled() ? "&a" : "") + Strings.capitalizeFirstLetter(module.getName()));
		}
		renderMenu(items, currentModule);
	}

	private void renderSettings(Render2DEvent event) {
		renderMenu(getFilteredSettingsList(), currentSetting);
	}

	private void renderMenu(List<String> items, int currentItem) {
		Module tabGuiModule = BaseClient.instance.getModuleManager().getModule(TabGui.class);

		boolean tabGuiRainbow = ModuleManager.tabGui.rainbow.isEnabled();
		boolean tabGuiGradient = ModuleManager.tabGui.gradient.isEnabled();
		int rainbowSpeed = (int) ModuleManager.tabGui.speed.getValue();
		int rainbowOffset = (int) ModuleManager.tabGui.offset.getValue();

		int height = BaseClient.instance.getFontRenderer().getFontSize() / 2 + 4;
		int y = BaseClient.instance.getFontRenderer().fontSizeLogo;




		RenderUtils.drawGradientRect(5, height * 2 - 5 + y, (maxItemWidth + 15) * 2,
				height * (items.size() + 2) - 5 + y, new Color(0, 0, 0, 100).getRGB(),
				tabGuiGradient ? new Color(100, 100, 100, 200).getRGB() : new Color(0, 0, 0, 100).getRGB());

		for (int i = 0; i < items.size(); i++) {
			String item = items.get(i);

			int itemWidth = Strings.getStringWidthCFR(item);

			if (itemWidth > maxItemWidth)
				maxItemWidth = itemWidth;

			boolean isCurrentItem = (i == currentItem);

			if (isCurrentItem) {
				int selectionColor = tabGuiRainbow ? Colors.getRGBWave(rainbowSpeed, 1, 0.5f, ((i) * rainbowOffset) * 2)
						: dev.windhook.module.Color.getColor(item).getRGB();
				this.translator.interpolate(height * (i + 2) - 5 + y, height * (i + 3) - 5 + y, 10);

				RenderUtils.drawGradientRect(5, (int) (translator.getX()), ((maxItemWidth + 15 + 5) * 2) - 7,
						(int) (translator.getY()),
						tabGuiRainbow ? selectionColor : dev.windhook.module.Color.getColor(item).getRGB(),
						tabGuiGradient ? new Color(0, 0, 0).getRGB()
								: tabGuiRainbow ? selectionColor
										: dev.windhook.module.Color.getColor(item).getRGB());
				if (indentation == 3)
					item = "&a" + item;
			}

			RenderUtils.drawString(item, 10, height * (i + 2) - 3 + y, -1);
		}

		if (indentation != 1 || getCurrentModule() == null)
			return;

		String description = getCurrentModule().getDescription();
		RenderUtils.drawGradientRect(5, 1 + height * (items.size() + 3) - height + y,
				Strings.getStringWidthCFR(description) + 12, height * (items.size() + 3) + y,
				new Color(0, 0, 0, 100).getRGB(),
				tabGuiGradient ? new Color(0, 0, 0, 100).getRGB() : new Color(100, 100, 100, 200).getRGB());
		RenderUtils.drawString(description, 8, height * (items.size() + 2) + y, -1);
	}

}