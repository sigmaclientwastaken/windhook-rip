package dev.windhook.overlay;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;

import dev.windhook.BaseClient;
import dev.windhook.event.EventListener;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.modules.client.ArrayList;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.Setting;
import dev.windhook.utils.Colors;
import dev.windhook.utils.Integers;
import dev.windhook.utils.RenderUtils;
import dev.windhook.utils.Strings;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

public class ToggledModules1 extends EventListener {

	public double newLineCurrent = 0;

	public UnicodeFontRenderer newFr = BaseClient.instance.font2.getFont(21);

	public ToggledModules1() {
		BaseClient.instance.getEventManager().registerListener(this);
	}

	@Override
	public void onRender2D(Render2DEvent event) {
		Module arrayList = BaseClient.instance.getModuleManager().getModule(ArrayList.class);

		if (arrayList.isToggled()) {
			List<Module> modules = BaseClient.instance.getModuleManager().getToggledModules();

			switch (ModuleManager.arrayList.mode.getMode()) {

				case "Old":
					modules.sort((module1,
								  module2) -> Strings.getStringWidthCFR(Strings.capitalizeFirstLetter(module2.getNameWithAddon()))
							- Strings.getStringWidthCFR(Strings.capitalizeFirstLetter(module1.getNameWithAddon())));
					int y = 1;

					int relativeYOffset = 3;
					int relativeXOffset = -2;

					int offset = BaseClient.instance.getFont().getFontSize() + relativeYOffset - 15;

					for (int i = 0; i < modules.size(); i++) {
						Module module = modules.get(i);
						String s = Strings.capitalizeFirstLetter(module.getNameWithAddon());
						int mWidth = Strings.getStringWidthCFR(s);

						int tabWidth = (int) ModuleManager.arrayList.tab_size.getValue();

						int moduleColor = ModuleManager.arrayList.rainbow.isEnabled()
								? Colors.getRGBWave((float) ModuleManager.arrayList.speed.getValue(), 1, 0.7f,
								Math.round(((i * y) * ModuleManager.arrayList.offset.getValue())))
								: module.getColor().getRGB();
						int tabColor = ModuleManager.arrayList.rainbow.isEnabled()
								? ModuleManager.arrayList.match_module_color.isEnabled() ? moduleColor
								: Colors.getRGBWave((float) ModuleManager.arrayList.speed.getValue(), 1, 0.7f,
								Integers.flipPositive(
										(int) Math.round(((i * y) * ModuleManager.arrayList.offset.getValue()))))
								: module.getColor().getRGB();
						boolean showGradient = ModuleManager.arrayList.gradient.isEnabled();
						int opacity = ModuleManager.arrayList.opacity.getValue() > 255 ? 255
								: (int) ModuleManager.arrayList.opacity.getValue();

						if (module.getCategory().equals(Category.HIDDEN) || !(module.isShownInModuleArrayList()))
							continue;

						RenderUtils.drawGradientRect(event.getWidth() - mWidth + relativeXOffset - 5, y + 1, event.getWidth(),
								y + offset - 1, new Color(0, 0, 0, opacity).getRGB(),
								showGradient ? new Color(100, 100, 100, opacity > 255 ? 255 : opacity).getRGB()
										: new Color(0, 0, 0, opacity > 255 ? 255 : opacity).getRGB());
						RenderUtils.drawRect(event.getWidth() - mWidth + relativeXOffset - 5, y + 1,
								event.getWidth() - mWidth - tabWidth, y + offset - 1, tabColor);
						RenderUtils.drawString(s, event.getWidth() - mWidth + relativeXOffset, y + 1, moduleColor,
								BaseClient.instance.getFontRenderer().fontSizeNormal, true);
						y += offset - 2;
					}
					break;

				case "Broken":

					GlStateManager.pushMatrix();
					GlStateManager.scale(1.5, 1.5, 1);

					FontRenderer fr = mc.fontRendererObj;
					float height = fr.FONT_HEIGHT + 1;
					ScaledResolution sr = new ScaledResolution(mc);

					modules = BaseClient.instance.getModuleManager().getToggledModules();
					modules.sort((module1,
								  module2) -> Strings.getStringWidthCFR(Strings.capitalizeFirstLetter(getFullName(module2)))
							- Strings.getStringWidthCFR(Strings.capitalizeFirstLetter(getFullName(module1))));

					int counter = 0;

					for(Module module : modules) {
						if(!module.isShownInModuleArrayList()){
							continue;
						}

						boolean mode = getAddon(module) != null;
						String modeStr = getAddon(module);

						fr.drawStringWithShadow(getFullName(module),
								(sr.getScaledWidth()/1.5f) - fr.getStringWidth(getFullName(module)) - 3,
								(int) (height * counter) + 2,
										Colors.getRGBWave(30f, 0.8f, 1f, counter * 30L));


						counter++;

					}
					GlStateManager.popMatrix();

					break;

				case "New":

					modules = BaseClient.instance.getModuleManager().getToggledModules3();
					modules.sort(Comparator.comparingInt(module -> newFr.getStringWidth((((Module)module).getAddon() == null)? ((Module)module).getName() : ((Module)module).getName() + " |" + ((Module)module).getAddon())).reversed());

					sr = new ScaledResolution(mc);

					GlStateManager.pushMatrix();

					GlStateManager.enableAlpha();
					GlStateManager.enableBlend();

					newLineCurrent = animate(getTarget(), newLineCurrent, 0.1D);

					Gui.drawRect(sr.getScaledWidth() - 4.5, 6, sr.getScaledWidth() - 3.5, newLineCurrent, new Color(223, 43, 255).getRGB());
					Gui.drawRect(sr.getScaledWidth() - 5, 6.5, sr.getScaledWidth() -3, newLineCurrent-0.5, new Color(223, 43, 255).getRGB());
					Gui.drawRect(sr.getScaledWidth() - 4.4, 6, sr.getScaledWidth() -3.5, newLineCurrent, new Color(223, 43, 255).getRGB());

					int size = newFr.getStringHeight("ApILwWAD|2131REWRNyj")+2;

					int counternew = 0;

					for(Module module : modules) {

						/// ticking
						if(module.isToggled()) {
							module.nalFade = Math.min(255, module.nalFade + 25);
						} else {
							module.nalFade = Math.max(0, module.nalFade - 25);
						}

						/// addons
						if(module.getAddon() == null) {

							newFr.drawString(module.getName(), sr.getScaledWidth() - newFr.getStringWidth(module.getName()) - 8,
									9 + (counternew * size), new Color(223, 43, 255, module.nalFade).brighter().getRGB(), true);

						} else {

							newFr.drawString(module.getAddon(), sr.getScaledWidth() - newFr.getStringWidth(module.getAddon()) - 8,
									9 + (counternew * size), new Color(194, 194, 194, module.nalFade).brighter().getRGB(), true);

							newFr.drawString(module.getName(), sr.getScaledWidth() - newFr.getStringWidth(module.getName() + " |" + module.getAddon()) - 8,
									9 + (counternew * size), new Color(223, 43, 255, module.nalFade).brighter().getRGB(), true);

						}

						counternew++;

					}

					GlStateManager.popMatrix();

					break;


			}


		}
	}

	public String getAddon(Module module) {
		Setting mode = null;
		for(Setting setting : module.settings){
			if(setting.name.equalsIgnoreCase("Mode")) {
				((ModeSetting)setting).getMode();
			}
		}
		return null;
	}

	public String getFullName(Module module) {
		return getAddon(module) != null ? module.getName() + " " + getAddon(module) : module.getName();
	}

	public double getTarget() {
		return (12) + (BaseClient.instance.getModuleManager().getToggledModules2().size()*(newFr.getStringHeight("ApILwWAD|2131REWRNyj")+2));
	}

	public double animate(double target, double current, double speed) {
		boolean larger = target > current;
		if (speed < 0.0D) {
			speed = 0.0D;
		} else if (speed > 1.0D) {
			speed = 1.0D;
		}

		double dif = Math.max(target, current) - Math.min(target, current);
		double factor = dif * speed;
		if (factor < 0.1D) {
			factor = 0.1D;
		}

		if (larger) {
			current += factor;
		} else {
			current -= factor;
		}

		return current;
	}

}