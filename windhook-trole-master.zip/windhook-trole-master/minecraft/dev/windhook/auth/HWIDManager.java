package dev.windhook.auth;

import java.util.ArrayList;
import java.util.List;

public class HWIDManager {

    /**
     * Your pastebin URL goes inside the empty string below.
     * It should be a raw pastebin link, for example: pastebin.com/raw/pasteid
     */

    public static final String pastebinURL = "https://pastebin.com/raw/a6gnmfM3";
    public static final String pastebinInfoURL = "https://pastebin.com/raw/xtpTFX1D";

    public static List<String> hwids = new ArrayList<>();

    public static void hwidCheck() {
        hwids = URLReader.readURL();
        boolean isHwidPresent = hwids.contains(SystemUtils.getSystemInfo());
        if (!isHwidPresent) {
            DisplayUtils.Display();
            throw new NoStackTraceThrowable("");
        }
    }

    public static String getUserName() {
        hwids = URLReader.readInfoURL();
        String hwid = SystemUtils.getSystemInfo();

        for(String id : hwids) {
            String[] parts = id.split(":");

            if(parts[0].equals(hwid)) {
                return parts[1];
            }
        }

        return null;
    }

    public static Integer getUserUID() {
        hwids = URLReader.readInfoURL();
        String hwid = SystemUtils.getSystemInfo();

        for(String id : hwids) {
            String[] parts = id.split(":");

            if(parts[0].equals(hwid)) {
                return Integer.parseInt(parts[2]);
            }
        }

        return null;
    }

}
