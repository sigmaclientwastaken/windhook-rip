package dev.windhook.gui.newgui;

import dev.windhook.BaseClient;
import dev.windhook.font.UnicodeFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL11;

public class RenderUtil {

    public static UnicodeFontRenderer fr17 = BaseClient.getInstance().getFont().getFont(17);
    public static UnicodeFontRenderer fr22 = BaseClient.getInstance().getFont().getFont(22);

    static Minecraft mc = Minecraft.getMinecraft();

    public static void scissor(double x, double y, double width, double height) {
        ScaledResolution sr = new ScaledResolution(mc);
        final double scale = sr.getScaleFactor();

        y = sr.getScaledHeight() - y;

        x *= scale;
        y *= scale;
        width *= scale;
        height *= scale;

        GL11.glScissor((int) x, (int) (y - height), (int) width, (int) height);
    }

}
