package dev.windhook.gui.menus;

public class Easing {

    public long lastMS;
    public long time;
    public float amount;

    public Easing(long time) {
        this.time = time;
    }

    public void reset() {
        lastMS = System.currentTimeMillis();
    }

    public boolean hasTimeElapsed() {
        if(System.currentTimeMillis()-lastMS > time) {
            return true;
        }
        return false;
    }

    public long getTime() {
        return System.currentTimeMillis() - lastMS;
    }

    public float getValue() {
        float value;

        float val1 = amount/100f;
        float val2 = time/100f;
        float val3 = getTime();

        if(time < getTime()) {
            return amount;
        } else {

            float val4 = val3 / val2;
            float val5 = val1 * val4;

            return val5;

        }

    }

    public void goal(float newAmount) {
        if(newAmount != amount) {
            amount = newAmount;
            reset();
        }
    }

}
