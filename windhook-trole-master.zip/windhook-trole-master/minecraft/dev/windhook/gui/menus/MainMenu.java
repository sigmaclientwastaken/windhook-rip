package dev.windhook.gui.menus;

import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.utils.RenderUtils;
import dev.windhook.utils.animation.basic.Scale;
import net.minecraft.client.gui.*;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class MainMenu extends GuiScreen {

    Color GRAY = new Color(35, 39, 42);
    Color BLUE = new Color(88, 101, 242);

    public int activeId = 1;
    public ArrayList<MenuButton> buttons = new ArrayList<>();
    UnicodeFontRenderer fr30 = RenderUtils.getFontRenderer().getFont(30);

    public MainMenu() {
    }

    public void initGui() {

        /* Adds the buttons to the buttons ArrayList */
        buttons.add(new MenuButton("Overview", 1));
        buttons.add(new MenuButton("Singleplayer", 2));
        buttons.add(new MenuButton("Multiplayer", 3));
        buttons.add(new MenuButton("Options", 4));

        /* Sorts the buttons ArrayList by length of string */
        //buttons.sort(Comparator.comparing(Str -> fr30.getStringWidth(Str.displayName)));

    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution sr = new ScaledResolution(mc);

  //      /* Button stuff */
  //      if(activeId == 2) // Singleplayer
  //          mc.displayGuiScreen(new GuiSelectWorld(this));
//
  //      if(activeId == 3) // Multiplayer
  //          mc.displayGuiScreen(new GuiMultiplayer(this));



        /* Draws the background rect. */
        RenderUtils.drawRect(0, 0, sr.getScaledWidth(), sr.getScaledHeight(), BLUE.getRGB());

        /* Draws the shadows. */
        drawWindow(new Color(16, 30, 30,255), sr, 3, 15, 25, 15, 25, 10);

        /* Draws the window rects. */
        RenderUtils.drawRect(15, 25, sr.getScaledWidth() - 15, sr.getScaledHeight() - 25, GRAY.getRGB());
        RenderUtils.drawRect(25, 15, sr.getScaledWidth() - 25, sr.getScaledHeight() - 15, GRAY.getRGB());

        /* Corners */
        drawCircle(25, 25, 10, new Color(GRAY.getRed() + 16, GRAY.getGreen() + 16, GRAY.getBlue() + 16).getRGB());
        drawCircle(25, sr.getScaledHeight() - 25, 10, new Color(GRAY.getRed() + 16, GRAY.getGreen() + 16, GRAY.getBlue() + 16).getRGB());
        drawCircle(sr.getScaledWidth() - 25, 25, 10, new Color(GRAY.getRed() + 16, GRAY.getGreen() + 16, GRAY.getBlue() + 16).getRGB());
        drawCircle(sr.getScaledWidth() - 25, sr.getScaledHeight() - 25, 10, new Color(GRAY.getRed() + 16, GRAY.getGreen() + 16, GRAY.getBlue() + 16).getRGB());

        /* Menu */
        drawWindow(new Color(21, 35, 35, 255), sr, 0, 225, 235, 25, 35, 10);

        /* Buttons */
        int counter = 0;
        for(MenuButton button : buttons) {

            drawWindow(new Color(153, 170, (button.id == activeId ? 100 : 181),255), sr, 0, 31, 41, 35 + (counter * 45), 45 + (counter * 45), 10, 180, 25, (button.id == activeId ? 71 : 72));

       //    try { RenderUtils.drawString(button.getName(), 43, 37 + (counter * 45), 0xffffffff);
       //    } catch(Exception e) { e.printStackTrace(); System.out.println(button.getName() == null); }


            counter++;
        }

    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        mc.displayGuiScreen(new GuiMainMenu());
    }

    public static void drawCircle(double x, double y, float radius, int color) {
        float alpha = (float) (color >> 24 & 255) / 255.0f;
        float red = (float) (color >> 16 & 255) / 255.0f;
        float green = (float) (color >> 8 & 255) / 255.0f;
        float blue = (float) (color & 255) / 255.0f;
        GL11.glColor3f(red, green, blue);
        GL11.glBegin(9);
        int i = 0;
        while (i <= 360) {
            GL11.glVertex2d(x + Math.sin((double) i * 3.141526 / 180.0) * (double) radius, y + Math.cos((double) i * 3.141526 / 180.0) * (double) radius);
            ++i;
        }
        GL11.glEnd();
    }

    public static void drawWindow(Color GRAY, ScaledResolution sr, int offset, int x1, int x2, int y1, int y2, int radius) {
        Gui.drawRect(x1 - offset, y2 - offset, sr.getScaledWidth() - x1 + offset, sr.getScaledHeight() - y2 + offset, GRAY.getRGB());
        Gui.drawRect(x2 - offset, y1 - offset, sr.getScaledWidth() - x2 + offset, sr.getScaledHeight() - y1 + offset, GRAY.getRGB());

        int i = new Color(GRAY.getRed() + 14, GRAY.getGreen() + 14, GRAY.getBlue() + 14).getRGB();
        drawCircle(x2 - offset, y2 - offset, 10, i);
        drawCircle(x2 - offset, sr.getScaledHeight() -y2 + offset, 10, i);
        drawCircle(sr.getScaledWidth() - x2 + offset, y2 - offset, 10, i);
        drawCircle(sr.getScaledWidth() - x2 + offset, sr.getScaledHeight() - y2 + offset, 10, i);
    }

    public static void drawWindow(Color GRAY, ScaledResolution sr, int offset, int x1, int x2, int y1, int y2, int radius, int width, int height, int colorOffset) {
        Gui.drawRect(x1 - offset, y2 - offset, width + x2 + offset, height + y1 + offset, GRAY.getRGB());
        Gui.drawRect(x2 - offset, y1 - offset, width + x1 + offset, height + y2 + offset, GRAY.getRGB());

        int i = new Color(GRAY.getRed() + colorOffset, GRAY.getGreen() + colorOffset, GRAY.getBlue() + colorOffset).getRGB();
        drawCircle(x2 - offset, y2 - offset, radius, i);
        drawCircle(x2 - offset, height + y1 + offset, radius, i);
        drawCircle(width + x1 + offset, y2 - offset, radius, i);
        drawCircle(width + x1 + offset, height + y1 + offset, radius, i);
    }

}

class MenuButton {

    String displayName;
    int id;

    public MenuButton(String displayName, int id) {
        this.displayName = displayName;
        this.id = id;
    }

    public void clicked() {}
    public void render() {}

    public void handleClick() {
        clicked();
    }

    public String getName() {
        if(displayName == null) {
            return "ERROR_NAME_NULL";
        } else {
            return displayName;
        }
    }

}
