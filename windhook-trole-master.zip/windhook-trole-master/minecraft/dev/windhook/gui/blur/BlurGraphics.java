package dev.windhook.gui.blur;

import net.minecraft.util.ResourceLocation;

public class BlurGraphics {

    public static final ResourceLocation blurShader = new ResourceLocation("wind/guiblur.json");

}
