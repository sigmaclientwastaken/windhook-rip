package dev.windhook.gui.astolfogui;

import com.google.gson.annotations.Expose;
import dev.windhook.BaseClient;
import dev.windhook.font.glyphrenderer.ClientFont;
import dev.windhook.font.glyphrenderer.GlyphPageFontRenderer;
import dev.windhook.gui.astolfogui.objects.AstolfoSetting;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.util.ArrayList;

public class AstolfoPane extends Gui {

    @Expose
    public int x, y;
    private int width = 125, height = 20;
    @Expose
    public boolean extended;
    @Expose
    public Category type;

    private AstolfoScreen screen;

    public ArrayList<AstolfoModulePane> modulePanes = new ArrayList<>();

    private final Color BACKGROUND_COLOR = Color.decode("#1A1A1A");
    private final Color BACKGROUND_COLOR2 = Color.decode("#252525");

    public AstolfoPane(Category type, int x, int y, AstolfoScreen screen) {
        this.x = x;
        this.y = y;
        this.type = type;
        this.screen = screen;
        int y2 = y;
        for (Module module : BaseClient.instance.getModuleManager().getModules(type)) {
            AstolfoModulePane modPane = new AstolfoModulePane(module, x, y2, screen, this);
            modulePanes.add(modPane);
            y2 += modPane.getHeight();
        }
    }

    private final GlyphPageFontRenderer fontRenderer = ClientFont.font(20, "AstolfoClickgui-IconFont", true);
    private char show = 'g', hide = 'i';
    public void draw(float mouseX, float mouseY) {
        update();
        int height2 = 0;
        for(AstolfoModulePane pane : this.modulePanes) {
            height2 += pane.getHeight();
        }
        drawRect(x, y, x+width, y+height, BACKGROUND_COLOR.getRGB());
        if (extended) {
            drawRect(x, y + height, x + width, y + height+height2, BACKGROUND_COLOR.getRGB());
        }
        int y2 = y + height;
        for (AstolfoModulePane pane : this.modulePanes) {
            if (extended) {
                pane.draw(mouseX, mouseY);
            }
            pane.x = this.x;
            pane.y = y2;
            y2 += pane.getHeight();

            int yAdd = pane.y;
            AstolfoSetting prev = null;
            for (AstolfoSetting changer : pane.changers) {
                changer.x = pane.x;
                changer.y = yAdd+18;
                prev = changer;
                yAdd += prev.height;
            }
        }
//		drawRect(x, y, x + width, y + height, HOVER_COLOR.getRGB());
        if(!extended) {
            drawHollowRect(x-.7, y-.5, width+1.3, height+.5, .7, type.getColor());
        }else {
            drawHollowRect(x-.7, y-.5, width+1.3, height+height2, .7, type.getColor());
        }
        AstolfoScreen.fr.drawString( type.getName(), x + 2 , (int) (y + 2.5F),
                Color.white.getRGB());
        fontRenderer.drawString(""+type.getIcon(), x+width-15, y+3.5F, type.getColor());
        fontRenderer.drawString(extended ? ""+show : ""+hide, x+width-27.5F, y+3.5F, extended ? type.getColor() : getMulitpliedColor(BACKGROUND_COLOR2.getRGB(), 1.3));
    }

    public void update() {
    }

    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (isHovered(mouseX, mouseY)) {
            if (mouseButton == 1) {
                extended = !extended;
            }
        }
        if (extended) {
            for (AstolfoModulePane pane : this.modulePanes) {
                pane.mouseClicked(mouseX, mouseY, mouseButton);
            }
        }
        return false;
    }

    public void mouseDragged(int mouseX, int mouseY) {
        if (screen.selectedPane == this) {
            this.x = mouseX - width / 2;
            this.y = mouseY - height / 2;
        }
        if (screen.selectedPane != this)
            screen.selectedPane.mouseDragged(mouseX, mouseY);
        int y2 = y + height;
        for (AstolfoModulePane pane : this.modulePanes) {
            pane.x = this.x;
            pane.y = y2;
            y2 += pane.getHeight();

            if (Mouse.isButtonDown(0)) {
                int yAdd = pane.y;
                AstolfoSetting prev = null;
                for (AstolfoSetting changer : pane.changers) {
                    changer.x = pane.x;
                    changer.y = yAdd+18;
                    prev = changer;
                    yAdd += prev.height;
                }
            }
        }
    }

    public void mouseReleased() {

    }

    public boolean isHovered(int mouseX, int mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    public static int getMulitpliedColor(Color color, double ammount) {
        return new Color((int)(color.getRed()*ammount), (int)(color.getGreen()*ammount), (int)(color.getBlue()*ammount), color.getAlpha()).getRGB();
    }

    public static int getMulitpliedColor(int color, double ammount) {
        return getMulitpliedColor(new Color(color), ammount);
    }


}
