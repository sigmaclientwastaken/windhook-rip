package dev.windhook.gui.astolfogui.objects;

import java.awt.Color;
import java.util.ArrayList;

import dev.windhook.module.Category;
import dev.windhook.module.settings.Setting;
import net.minecraft.client.gui.Gui;

public abstract class AstolfoSetting<T> extends Gui {

    public int x, y;
    public int width = 125;
    public int height = 35;
    public Setting setting;
    public boolean extended = false;
    public T value;
    public Color HOVER_COLOR = Color.blue, BACKGROUND_COLOR = new Color(25, 25, 25);
    public Category cat;

    public AstolfoSetting(int x, int y, Setting setting, Category cat) {
        this.x = x;
        this.y = y;
        this.setting = setting;
        this.height = 17;
        this.cat = cat;
    }

    public void draw(float mouseX, float mouseY) {
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
    }

    public void mouseDragged(int mouseX, int mouseY, int mouseButton) {
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

}
