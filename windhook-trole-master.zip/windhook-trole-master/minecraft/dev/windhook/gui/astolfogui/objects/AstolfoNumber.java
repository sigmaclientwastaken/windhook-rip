package dev.windhook.gui.astolfogui.objects;

import java.awt.Color;

import dev.windhook.gui.astolfogui.AstolfoScreen;
import dev.windhook.module.Category;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.module.settings.Setting;
import org.lwjgl.input.Mouse;

import net.minecraft.client.Minecraft;

public class AstolfoNumber extends AstolfoSetting<Double>{

    private float xAdd = 0;
    private boolean init = false;

    public AstolfoNumber(int x, int y, Setting setting, Category cat) {
        super(x, y, setting, cat);
        this.height = 20;
        this.width = 119;
    }

    @Override
    public void draw(float mouseX, float mouseY) {
        Minecraft mc = Minecraft.getMinecraft();
        if(this.value == null) {
            this.value = ((NumberSetting)setting).getValue();
        }
        if(!init) {
            this.value = calculateValue();
            float percentWidth = (float) ((width/((NumberSetting)setting).getMaximum())*((NumberSetting)setting).getValue());
            this.xAdd = (int) percentWidth;
            init = true;
        }
        drawRect(x+3, y +1, x+3+xAdd, y+20, cat.getColor());
        AstolfoScreen.fr.drawString(setting.name, x+6, y+4, Color.white.getRGB());
        int valueWidth = AstolfoScreen.fr.getStringWidth(value.toString().replace(".", ","));
        AstolfoScreen.fr.drawString(value.toString().replace(".", ","), x+width-valueWidth, y + 4, Color.white.getRGB());
        if(Mouse.isButtonDown(0)) {
            if(mouseX >= x+3 && mouseX <= x+3+width && mouseY >= y && mouseY <= y+20) {
                xAdd = (float) (((float)mouseX-x-3F));
            }
        }
        this.value = calculateValue();
        ((NumberSetting)setting).setValue(this.value);
    }

    public double calculateValue() {
        float percentWidth = (((float)1/width)*xAdd)*100;

        double d = (float)(((NumberSetting)setting).getMaximum()*(percentWidth/100));
        return (double)(Math.round(d*100)/100.0);
    }

}
