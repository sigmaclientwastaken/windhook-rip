package dev.windhook.gui.astolfogui.objects;

import dev.windhook.gui.astolfogui.AstolfoScreen;
import dev.windhook.module.Category;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.Setting;
import dev.windhook.utils.Timer;
import org.lwjgl.input.Mouse;

import java.awt.*;

public class AstolfoBoolean extends AstolfoSetting<Boolean>{

    public AstolfoBoolean(int x, int y, Setting setting, Category cat) {
        super(x, y, setting, cat);
        this.height = 20;
        this.width = 119;
        clickWaiter = new Timer();
    }

    private final Timer clickWaiter;

    @Override
    public void draw(float mouseX, float mouseY) {
        if(value == null) value = ((BooleanSetting)setting).isEnabled();
        if(value) drawRect(x+3, y, x+3+width, y+20, cat.getColor());
        AstolfoScreen.fr.drawString(setting.name, x+6, y+6, Color.white.getRGB());
        if(Mouse.isButtonDown(0) && clickWaiter.hasReached(200)) {
            if(mouseX >= x+3 && mouseX <= x+3+width && mouseY >= y && mouseY <= y+20) {
                this.value = !this.value;
                clickWaiter.reset();
            }
        }
        ((BooleanSetting)setting).setEnabled(value);
        super.draw(mouseX, mouseY);
    }

}
