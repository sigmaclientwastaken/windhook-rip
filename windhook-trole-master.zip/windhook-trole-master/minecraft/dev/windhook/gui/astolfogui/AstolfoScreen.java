package dev.windhook.gui.astolfogui;

import dev.windhook.BaseClient;
import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.module.Category;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Mouse;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AstolfoScreen extends GuiScreen {

    public static UnicodeFontRenderer fr = null;

    private List<AstolfoPane> panes = new ArrayList<AstolfoPane>();
    public AstolfoPane selectedPane = null;

    public AstolfoScreen() {
        fr = BaseClient.getInstance().font2.getFont(22);
    }

    public double targetScroll;
    public double currentScroll;

    @Override
    public void initGui() {
        panes.clear();
        int i = 20;
        for(Category Type : Category.values()) {
            File f = new File(AstolfoFileManager.getDirectory("astolfoclickgui"), Type.name().toLowerCase()+".json");
            AstolfoPane pane = JsonUtils.getObject(AstolfoPane.class, f);
            AstolfoPane pane2 = new AstolfoPane(Type, i, 20, this);
            if(pane != null) {
                pane2.x = pane.x;
                pane2.y = pane.y;
                if(pane.extended) {
                    pane2.extended = true;
                }else {
                    pane2.extended = false;
                }
                pane2.type = pane.type;
            }
            panes.add(pane2);
            i+=120;
        }
    }


    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {

        if (Mouse.hasWheel()) {
            int wheel = Mouse.getDWheel();
            if (wheel > 0) {
                targetScroll += 26;
            } else if (wheel < 0) {
                targetScroll -= 26;
            }
        }

        currentScroll = animate(targetScroll, currentScroll, 0.5979D);
        int t = (int) (mouseY - currentScroll);

        drawRect(0, 0, width, height, Integer.MIN_VALUE);

        GlStateManager.pushMatrix();

        GlStateManager.translate(0, currentScroll, 0);


        for(AstolfoPane pane : this.panes) {
            pane.draw(mouseX, t);
        }
        if(this.selectedPane != null && Mouse.isButtonDown(0)) this.selectedPane.mouseDragged(mouseX, t);

        GlStateManager.popMatrix();
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        int t = (int) (mouseY - currentScroll);

        for(AstolfoPane pane : this.panes) {
            pane.mouseClicked(mouseX, t, mouseButton);
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        int t = (int) (mouseY - currentScroll);

        for(AstolfoPane pane : this.panes) {
            if(this.selectedPane == null || this.selectedPane == pane) {
                if(pane.isHovered(mouseX, t)) this.selectedPane = pane;
            }
        }
        if(this.selectedPane != null && clickedMouseButton == 0) this.selectedPane.mouseDragged(mouseX, t);
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        this.selectedPane = null;
    }

    @Override
    public void onGuiClosed() {
        savePanes();
    }

    public void savePanes() {
        AstolfoFileManager.createDirectory("astolfoclickgui");
        for(AstolfoPane pane : this.panes) {
            JsonUtils.writeObjectToFile(pane, new File(AstolfoFileManager.getDirectory("astolfoclickgui"), pane.type.name().toLowerCase()+".json"));
        }
    }

    public double animate(double target, double current, double speed) {
        boolean larger = target > current;
        if (speed < 0.0D) {
            speed = 0.0D;
        } else if (speed > 1.0D) {
            speed = 1.0D;
        }

        double dif = Math.max(target, current) - Math.min(target, current);
        double factor = dif * speed;
        if (factor < 0.1D) {
            factor = 0.1D;
        }

        if (larger) {
            current += factor;
        } else {
            current -= factor;
        }

        return current;
    }

}
