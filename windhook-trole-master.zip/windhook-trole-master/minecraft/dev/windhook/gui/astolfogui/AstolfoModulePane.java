package dev.windhook.gui.astolfogui;

import dev.windhook.gui.astolfogui.objects.*;
import dev.windhook.module.Module;
import dev.windhook.module.settings.Setting;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.util.ArrayList;

public class AstolfoModulePane extends Gui {

    public int x, y;
    public int width = 125;
    public int height = 20;
    public int baseHeight = 20;
    private boolean extended;
    private Module module;

    private AstolfoScreen screen;
    private AstolfoPane paneOn;

    private final Color BACKGROUND_COLOR = Color.decode("#1A1A1A");
    private final Color BACKGROUND_COLOR2 = Color.decode("#252525");

    public ArrayList<AstolfoSetting> changers = new ArrayList<>();
    private boolean init = false;

    public AstolfoModulePane(Module module, int x, int y, AstolfoScreen screen, AstolfoPane paneOn) {
        this.x = x;
        this.y = y;
        this.module = module;
        this.screen = screen;
        this.paneOn = paneOn;
    }

    public void draw(float mouseX, float mouseY) {
        if (!init) {
            int yAdd = 0;
            for (Setting setting : this.module.getVisibleSettings()) {
                AstolfoSetting curr = null;
                switch (setting.thingy) {
                    case "CheckBox":
                        changers.add(curr = new AstolfoBoolean(x+width+1, y+changersAdd(), setting, this.module.getCategory()));
                        break;
                    case "Slider":
                        changers.add(curr = new AstolfoNumber(x, y+changersAdd()+18, setting, this.module.getCategory()));
                        break;
                    case "DropdownBox":
                        changers.add(curr = new AstolfoString(x+width+1, y+changersAdd(), setting, this.module.getCategory()));
                        break;
                    default:
                        break;
                }
                if(curr != null) yAdd += curr.height;
            }
            init = true;
        }
        if(!extended) {
            this.height = baseHeight;
        }else {
            this.height = baseHeight+changersAdd();
        }

        Color COLOR_ENABLED = new Color(module.getCategory().getColor());
        Color COLOR_DISABLED = BACKGROUND_COLOR2;
        update();
        drawRect(x, y, x + width, y + baseHeight,
                BACKGROUND_COLOR.getRGB());
        drawRect(x+2.25F, y-2.5F, x + width-1.75F, y + baseHeight - 2.5F,
                extended ? (COLOR_DISABLED.getRGB()) : !module.isToggled() ? (isHovered(mouseX, mouseY) ? getMulitpliedColor(COLOR_DISABLED, 1.5) : COLOR_DISABLED.getRGB()) : (isHovered(mouseX, mouseY) ? getMulitpliedColor(COLOR_ENABLED, 0.75) : COLOR_ENABLED.getRGB()));


        int stringWidth = AstolfoScreen.fr.getStringWidth(module.getName())+ 5;

        AstolfoScreen.fr.drawString(module.getName(), x + width-stringWidth, y ,
                extended ? (module.isToggled() ? COLOR_ENABLED.getRGB() : Color.white.getRGB()) : Color.white.getRGB());
        if (extended) {
            for (AstolfoSetting changer : this.changers) {
                changer.extended = true;
                changer.draw(mouseX, mouseY);
            }
        }else {
            for (AstolfoSetting changer : this.changers) {
                changer.extended = false;
            }
        }
    }

    public void update() {
    }

    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (isHovered(mouseX, mouseY)) {
            if (mouseButton == 1) {
                if(module.getVisibleSettings().size() > 0) extended = !extended;
            }
            if (mouseButton == 0) {
                this.module.toggle();
            }
        }
        for(AstolfoSetting changer : this.changers) {
            changer.mouseClicked(mouseX, mouseY, mouseButton);
        }
        return false;
    }

    public void mouseDragged(int mouseX, int mouseY) {
        if (Mouse.isButtonDown(0)) {
            int yAdd = this.y;
            AstolfoSetting prev = null;
            for (AstolfoSetting changer : this.changers) {
                changer.x = x;
                changer.y = yAdd+18;
                prev = changer;
                yAdd += prev.height;
            }
        }
    }

    public void mouseReleased() {

    }

    public boolean isHovered(float mouseX, float mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y-2.5 && mouseY <= y + baseHeight-2.5;
    }

    public int getHeight() {
        return height;
    }

    public int changersAdd() {
        int add = 0;
        try {
            for(AstolfoSetting changer : this.changers) {
                add += changer.height;
            }
        } catch (Exception e) {
        }
        return add;
    }

    public static int getMulitpliedColor(Color color, double ammount) {
        return new Color((int)(color.getRed()*ammount), (int)(color.getGreen()*ammount), (int)(color.getBlue()*ammount), color.getAlpha()).getRGB();
    }

    public static int getMulitpliedColor(int color, double ammount) {
        return getMulitpliedColor(new Color(color), ammount);
    }

}
