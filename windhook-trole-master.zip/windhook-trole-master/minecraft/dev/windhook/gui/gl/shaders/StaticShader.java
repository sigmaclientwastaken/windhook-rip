package dev.windhook.gui.gl.shaders;

public class StaticShader extends ShaderProgram {

	private int location_transformationMatrix;
	
	public StaticShader() {
		super();
		//	super(VERTEX_FILE, FRAGMENT_FILE);
		
	}

	@Override
	protected void bindAttributes() {
		super.bindAttribute(0, "position");
		super.bindAttribute(1, "textureCoords");
	}

	@Override
	protected void getAllUniformLocations() {
		
		location_transformationMatrix = super.getUniformLocation("transformationMatrix");
		
	}

}

