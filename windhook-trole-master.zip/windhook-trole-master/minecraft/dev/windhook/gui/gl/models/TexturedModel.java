package dev.windhook.gui.gl.models;

import dev.windhook.gui.gl.textures.ModelTexture;

public class TexturedModel {

	private RawModel rawModel;
	private ModelTexture texture;
	
	/**
	 * @param rawModel The raw model.
	 * @param texture The Model Texture.
	 */
	public TexturedModel(RawModel rawModel, ModelTexture texture) {
		this.rawModel = rawModel;
		this.texture = texture;
	}

	/**
	 * @return the rawModel
	 */
	public RawModel getRawModel() {
		return rawModel;
	}

	/**
	 * @return the texture
	 */
	public ModelTexture getTexture() {
		return texture;
	}
	
	
}
