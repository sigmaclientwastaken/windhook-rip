package dev.windhook.gui.dropdowngui;

import dev.windhook.BaseClient;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.settings.*;
import dev.windhook.utils.Colors;
import dev.windhook.utils.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DropdownGUI extends GuiScreen {

    public static Color colorGrayComponent = new Color(50, 50, 50);
    public static Color colorGraySubomponent = new Color(60, 60, 60);

    public ArrayList<Frame> frames = new ArrayList<Frame>();

    public DropdownGUI() {
        Minecraft mc = Minecraft.getMinecraft();

        for(Category c : Category.values()) {

            if(c == Category.HIDDEN) {
                continue;
            }

            Frame currentFrame = new Frame(c.getName());
            List<Module> modules = BaseClient.getInstance().getModuleManager().getModules(c);

            for(Module m : modules) {

                ModuleComponent currentModule = new ModuleComponent(m, currentFrame, colorGrayComponent.getRGB()) {

                    @Override
                    public void onPressed() {
                        module.toggle();
                    }

                    @Override
                    public void onUpdate() {
                        this.enabled = module.isToggled();
                    }

                };

                for(Setting set : m.settings) {

                    SettingComponent currentSetting = new SettingComponent(set, currentModule, colorGraySubomponent.getRGB()) {

                        @Override
                        public String getText() {

                            if(setting instanceof BooleanSetting) {
                                return ((BooleanSetting) setting).getName();
                            }

                            if(setting instanceof NumberSetting) {
                                return ((NumberSetting) setting).getName() + ": " + ((NumberSetting) setting).getValue();
                            }

                            if(setting instanceof ModeSetting) {
                                return ((ModeSetting) setting).getName() + ": " + ((ModeSetting) setting).getMode();
                            }

                            return setting.name.toUpperCase();
                        }

                        @Override
                        public int getColor() {

                            if(setting instanceof BooleanSetting) {
                                return ((BooleanSetting) setting).isEnabled() ? Colors.getRGBWave(10, 1, 0.5f, 5) : 0xFFFFFFFF;
                            }

                            if(setting instanceof ListSetting) {
                                return 0xFFFFFFFF;
                            }

                            return Colors.getRGBWave(10, 1, 0.5f, 5);
                        }

                        @Override
                        public void onPressed() {

                            if(setting instanceof BooleanSetting) {
                                ((BooleanSetting) setting).toggle();
                            }

                            if(setting instanceof NumberSetting) {
                                ((NumberSetting) setting).increment(!GuiScreen.isCtrlKeyDown());
                            }

                            if(setting instanceof ModeSetting) {
                                if (GuiScreen.isCtrlKeyDown()) {
                                    ((ModeSetting) setting).cycleReverse();
                                } else {
                                    ((ModeSetting) setting).cycle();
                                }
                            }

                        }
                    };

                    currentModule.elements.add(currentSetting);

                }

                currentFrame.add(currentModule);

            }

            frames.add(currentFrame);

        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
    //    RenderUtils.drawString("test", 0, 0, -1);
        for (Frame rFrame : frames) {
            rFrame.draw(mouseX, mouseY, partialTicks, 0, 0, this);
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        for (Frame rFrame : frames) {
            rFrame.mouseClicked(mouseX, mouseY, mouseButton);
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        for (Frame rFrame : frames) {
            rFrame.mouseReleased(mouseX, mouseY, state);
        }

    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        super.keyTyped(typedChar, keyCode);
        for (Frame rFrame : frames) {
            rFrame.keyTyped(typedChar, keyCode);
        }

        if(keyCode == ModuleManager.clickGuiNew.getKey()) {
            mc.displayGuiScreen(null);
        }

    };

    @Override
    public void initGui() {
        layoutFrames(new ScaledResolution(mc));
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private void layoutFrames(ScaledResolution sr) {
        int x = 10;
        int y = 10;
        int h = 15;
        int w = 130;
        for (Frame frame : frames) {
            if (frame.getX() == 0 || frame.getY() == 0) {
                if (x + w > sr.getScaledWidth()) {
                    x = 10;
                    y += h + 160;
                }
                frame.setX(x);
                frame.setY(y);
                x += w + 10;
            }
        }
    }

}