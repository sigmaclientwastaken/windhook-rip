package dev.windhook.gui.dropdowngui;

import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.Setting;
import dev.windhook.utils.Colors;
import dev.windhook.utils.RenderUtils;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.ArrayList;

public class ModuleComponent extends AbstractComponent {

    public ArrayList<AbstractComponent> elements = new ArrayList<AbstractComponent>();

    public Module module;
    public int color;
    public boolean held;
    public boolean enabled;
    public long hoverTime = 0;
    public long lastTime = 0;
    float p_73968_1_;

    public static int size = 110;

    public boolean open;

    public ModuleComponent(Module module, AbstractComponent parent, int color) {
        this.module = module;
        this.color = color;
        this.parent = parent;
        this.width = parent.width;
        this.height = 16;
        this.renderWidth = width;
        this.renderHeight = height;
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks, int parX, int parY, GuiScreen screen) {
        this.onUpdate();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.parent.x, this.parent.y, 0);
        this.absx = parX + this.x;
        this.absy = parY + this.y;

        int rHeight = this.height;

//		screen.drawRect(x - 1, y, x + width + 1, y + height - 1, 0xff404040);
//		screen.drawRect(x - 1, y, x + width + 1, y + height + 1, 0xff404040);
        UnicodeFontRenderer fr = RenderUtils.getFontRenderer().getFont(18);
        Gui.drawRect(x, y, x + width, y + rHeight, 404040);

        if (enabled) {
            Gui.drawRect(x, y - 1, x + width, y + height + 1, 0xff404040);
            GuiScreen.drawRect(this.x, this.y - 2, this.x + 3, this.y + this.height, color);
            fr.drawStringWithShadow(module.getName().toLowerCase(), (x + width) - (fr.getStringWidth(module.getName().toLowerCase()) + 3), y + 4, Colors.getRGBWave(10, 1, 0.5f, 5));
        } else if (!enabled) {
            Gui.drawRect(x, y - 1, x + width, y + height + 1, 0xff404040);
            GuiScreen.drawRect(this.x, this.y - 2, this.x + 3, this.y + this.height, color);
            fr.drawStringWithShadow(module.getName().toLowerCase(), (x + width) - (fr.getStringWidth(module.getName().toLowerCase()) + 3), y + 4, 0xFFFFFFFF);
        }


        int compY = this.height;
        int compX = 0;
        int spacer = 2;
        for (AbstractComponent c : this.elements) {
            c.y = compY + spacer - 2;
            c.x = spacer;
            c.width = this.width - spacer * 2;
            compY += c.renderHeight + spacer - 2;
        }
        if (this.open) {
            this.renderHeight = compY + spacer + 10;
            //GL11.glRotated(5, 0, Integer.MAX_VALUE, 0);
        }
        if (this.elements.size() > 0) {
            if (this.open) {
                for (AbstractComponent c : this.elements) {
                    // screen.drawRect(x, y + 12, x + width, y + height,
                    // 0xFF000000);
                }
                for (AbstractComponent c : this.elements) {
                    c.draw(mouseX, mouseY, partialTicks, absx, absy, screen);
                    c.isVisible = true;
                }
                this.renderHeight -= 13;
                //		SpecialCircle.circleOutline(x + width / 2 + 54, y + 7, 5, 0xFFFFFFFF);
                fr.drawString("-", x + 4, (int) (y + (float)3.1), 0xFFFFFFFF);
            } else {
                this.renderHeight = this.height;
                for (AbstractComponent c : this.elements) {
                    c.isVisible = false;
                }
                //		SpecialCircle.circleOutline(x + width / 2 + 54, y + 7, 5, 0xFFFFFFFF);
                fr.drawString("+", x + 4, (int) (y + (float)3.1), 0xFFFFFFFF);
            }
        } else {
            this.renderHeight = this.height;
        }
        GL11.glPopMatrix();
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (!this.isVisible) {
            return;
        }

        if (mouseX >= this.absx && mouseX <= this.absx + this.width) {
            if (mouseY >= this.absy && mouseY <= this.absy + this.height) {

            }
        }
        if (mouseX >= this.absx && mouseX <= this.absx + this.width) {
            if (mouseY >= this.absy && mouseY <= this.absy + this.height) {
                if (mouseButton == 0) {
                    this.held = true;
                } else {
                    if (this.elements.size() > 0) {
                        this.open = !this.open;
                    }
                }
            }

        }
        if (open) {
            for (AbstractComponent c : elements) {
                c.mouseClicked(mouseX, mouseY, mouseButton);
            }
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int mouseButton) {
        if (mouseX >= this.absx && mouseX <= this.absx + this.width) {
            if (mouseY >= this.absy && mouseY <= this.absy + this.height) {
                if (this.held) {
                    this.held = false;
                    this.onPressed();
                }
            }
        }
        if (open) {
            for (AbstractComponent c : elements) {
                c.mouseReleased(mouseX, mouseY, mouseButton);
            }
        }
    }

    public void onPressed() {
    }

    public void onUpdate() {
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) throws IOException {
        for (AbstractComponent c : elements) {
            c.keyTyped(typedChar, keyCode);
        }

    }

}
