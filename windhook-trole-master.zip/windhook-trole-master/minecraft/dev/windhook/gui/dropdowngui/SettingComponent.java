package dev.windhook.gui.dropdowngui;

import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.module.settings.Setting;
import dev.windhook.utils.RenderUtils;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.ArrayList;

public class SettingComponent extends AbstractComponent {

    public ArrayList<AbstractComponent> elements = new ArrayList<AbstractComponent>();

    public Setting setting;
    public boolean held;
    public boolean enabled;
    public int color;
    public long hoverTime = 0;
    public long lastTime = 0;
    public static UnicodeFontRenderer fr = RenderUtils.getFontRenderer().getFont(18);
    float p_73968_1_;

    public static int size = 100;

    public boolean open;

    public SettingComponent(Setting setting, AbstractComponent parent, int color) {
        this.setting = setting;
        this.parent = parent;
        this.color = color;
        this.width = parent.width - 4;
        this.height = 15;
        this.renderWidth = width;
        this.renderHeight = height;
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks, int parX, int parY, GuiScreen screen) {
        this.onUpdate();
        GL11.glPushMatrix();
        GL11.glTranslatef(this.parent.x, this.parent.y, 0);
        this.absx = parX + this.x;
        this.absy = parY + this.y;

        int rHeight = this.height;

        Gui.drawRect(x, y + 1, x + width, y + rHeight, 303030);

        Gui.drawRect(x, y + 1, x + width, y + height + 1, 0xff303030);
        Gui.drawRect(this.x, this.y - 2, this.x + 2, this.y + this.height + 2, color);

        if(enabled) {
            Gui.drawRect(this.x, this.y - 2, this.x + 2, this.y + this.height + 2, color);
            fr.drawStringWithShadow(getText(), (x + width) - (fr.getStringWidth(getText()) + 3), y + 4, color);
            //fr.drawStringWithShadow("\u2713", (float)(this.x + this.width / 2 + 50), (float)(this.y + 2), -1);
        }
        if(!enabled) {
            Gui.drawRect(this.x, this.y - 2, this.x + 2, this.y + this.height + 2, color);
            fr.drawStringWithShadow(getText(), (x + width) - (fr.getStringWidth(getText()) + 3), y + 4, getColor());
        }

        if (mouseX >= this.absx && mouseX <= this.absx + this.width) {
            if (mouseY >= this.absy && mouseY <= this.absy + this.height) {
                Gui.drawRect(x, y, x + width, y + height, 0x30000000);
            }
        }

        int compY = this.height;
        int compX = 0;
        int spacer = 2;
        for (AbstractComponent c : this.elements) {
            c.y = compY + spacer;
            c.x = spacer;
            c.width = this.width - spacer * 2;
            compY += c.renderHeight + spacer - 1;
        }
        if(this.open){
            this.renderHeight = compY + spacer + 10;
        }
        if (this.elements.size() > 0) {
            if (this.open) {
                for (AbstractComponent c : this.elements) {
                    c.draw(mouseX, mouseY, partialTicks, absx, absy, screen);
                    c.isVisible = true;
                }
                this.renderHeight -= 11;
            } else {
                this.renderHeight = this.height;
                for (AbstractComponent c : this.elements) {
                    c.isVisible = false;
                }
            }
        } else {
            this.renderHeight = this.height;
        }
        GL11.glPopMatrix();
    }




    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (!this.isVisible) {
            return;
        }

        if (mouseX >= this.absx && mouseX <= this.absx + this.width) {
            if (mouseY >= this.absy && mouseY <= this.absy + this.height) {

            }
        }
        if (mouseX >= this.absx && mouseX <= this.absx + this.width) {
            if (mouseY >= this.absy && mouseY <= this.absy + this.height) {
                if (mouseButton == 0) {
                    this.held = true;
                }else{
                    if(this.elements.size() > 0) {
                        this.open = !this.open;
                    }
                }
            }

        }
        if(open) {
            for(AbstractComponent c : elements) {
                c.mouseClicked(mouseX, mouseY, mouseButton);
            }
        }
    }



    @Override
    public void mouseReleased(int mouseX, int mouseY, int mouseButton) {
        if (mouseX >= this.absx && mouseX <= this.absx + this.width) {
            if (mouseY >= this.absy && mouseY <= this.absy + this.height) {
                if (this.held) {
                    this.held = false;
                    this.onPressed();
                }
            }
        }
        if(open) {
            for(AbstractComponent c : elements) {
                c.mouseReleased(mouseX, mouseY, mouseButton);
            }
        }
    }

    public void onPressed() {
    }

    public void onUpdate() {
    }

    public String getText() {
        return "Placeholder";
    }

    public int getColor() {
        return -1;
    }


    @Override
    public void keyTyped(char typedChar, int keyCode) throws IOException {
        for(AbstractComponent c : elements) {
            c.keyTyped(typedChar, keyCode);
        }

    }

}
