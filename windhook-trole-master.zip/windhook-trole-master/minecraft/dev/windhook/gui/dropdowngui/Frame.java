package dev.windhook.gui.dropdowngui;

import dev.windhook.module.Category;
import dev.windhook.utils.RenderUtils;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class Frame extends AbstractComponent {

    public String title;
    private boolean isOpen;
    private boolean isDrag;
    private int xOffset;
    private int yOffset;
    public ArrayList<AbstractComponent> comps = new ArrayList<>();
    public int max;
    public int min;
    private int size = 0;

    public Frame(String title) {
        this.title = title;
        this.x = 0;
        this.y = 0;
        this.width = 100;
        this.height = 15;
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks, int parX, int parY, GuiScreen screen) {

        /* Dragging math */
        if (this.isDrag) {
            this.x = (mouseX - this.xOffset);
            this.y = (mouseY - this.yOffset);
        }

        /* Variable stuff */
        this.absx = (parX + this.x);
        this.absy = (parY + this.y);
        AbstractComponent item;

        /* Component iteration */
        if (this.isOpen) {

            /* height stuff idk */
            int rHeight = this.height;

            /* Iteration math stuff IDK */
            for (Iterator localIterator = this.comps.iterator(); localIterator.hasNext();) {
                item = (AbstractComponent) localIterator.next();
                rHeight += item.renderHeight + 2;
            }
            rHeight -= this.comps.size() + 1;
        }

        /* Title rendering */
        Gui.drawRect(this.x, this.y - 2, this.x + this.width, this.y + this.height, DropdownGUI.colorGrayComponent.getRGB());
        RenderUtils.drawString(title, (this.x + this.width) - ( 2 + RenderUtils.getFontRenderer().getFont(20).getStringWidth(title)) , this.y + 2, -1, 20);

        /* rendering */
        if (this.isOpen) {
            for (AbstractComponent item1 : this.comps) {
                item1.draw(mouseX, mouseY, partialTicks, this.absx, this.absy, screen);
                item1.isVisible = true;
            }
        } else {
            for (AbstractComponent item1 : this.comps) {
                item1.isVisible = false;
            }
        }

        resizeComponenets();

    }

    /* math */
    private void resizeComponenets() {
        int compY = this.height;
        for (AbstractComponent comp : this.comps) {
            comp.x = 0;
            comp.y = compY;
            comp.width = this.width;
            compY += comp.renderHeight + 1;
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if ((mouseX >= this.x) && (mouseX <= this.x + this.width) && (mouseY >= this.y)
                && (mouseY <= this.y + this.height)) {
            if (mouseButton == 0) {
                this.isDrag = true;
                this.xOffset = (mouseX - this.x);
                this.yOffset = (mouseY - this.y);
            } else {
                this.isOpen = (!this.isOpen);
            }
        }
        if (this.isOpen) {
            for (AbstractComponent child : this.comps) {
                child.mouseClicked(mouseX, mouseY, mouseButton);
            }
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int mouseButton) {
        this.isDrag = false;
        for (AbstractComponent child : this.comps) {
            child.mouseReleased(mouseX, mouseY, mouseButton);
        }
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public void keyTyped(char typedChar, int keyCode) throws IOException {
        for (AbstractComponent child : this.comps) {
            child.keyTyped(typedChar, keyCode);
        }
    }

    public void keyTypedNum(int typedChar, int keyCode) throws IOException {
    }

    public boolean isExpanded() {
        return isOpen;
    }

    public String getTitle() {
        return title;
    }

    public void setExpanded(boolean open) {
        isOpen = open;

    }

    public void add(AbstractComponent comp) {
        comps.add(comp);
    }

}
