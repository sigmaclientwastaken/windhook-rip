package dev.windhook.gui.radialgui;

import dev.windhook.module.Category;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import net.minecraft.client.gui.GuiScreen;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RadialClickGui extends GuiScreen {

    public Category currentCategory;
    public Module currentModule;

    ArrayList<Category> radialMenuComponents = getVisibleCategories();

    public RadialCategoryMenu categoryMenu = new RadialCategoryMenu(50, radialMenuComponents) {
        @Override
        public Color getColor() {
            return new Color((int) ModuleManager.clickGuiNew.red.getValue(), (int) ModuleManager.clickGuiNew.green.getValue(), (int) ModuleManager.clickGuiNew.blue.getValue(), 255);
        }
    };

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {

        categoryMenu.render(Category.COMBAT, 50);

    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        ModuleManager.clickGuiNew.mode.set("Old");
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    /**
     * Gets an ArrayList of all categoies except Client, SemiHidden and Hidden.
     * @return the ArrayList.
     */
    public ArrayList<Category> getVisibleCategories() {
        ArrayList<Category> categories = new ArrayList<>();
        for(Category cat : Category.values()) {
            if(cat != Category.CLIENT && cat != Category.HIDDEN && cat != Category.SEMI_HIDDEN) {
                categories.add(cat);
            }
        }
        return categories;
    }

}
