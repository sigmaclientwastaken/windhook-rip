package dev.windhook.gui.radialgui;

import com.sun.javafx.geom.Vec2f;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

import java.awt.*;

public class RadialGuiUtils {

    public static void enableGL2D() {
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glDepthMask(true);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glHint(3155, 4354);
    }

    public static void disableGL2D() {
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
        GL11.glDisable(2848);
        GL11.glHint(3154, 4352);
        GL11.glHint(3155, 4352);
    }

    public static void drawCircle(float cx, float cy, float r, final int num_segments, final int c) {
        GL11.glPushMatrix();
        cx *= 2.0f;
        cy *= 2.0f;
        final float f = (c >> 24 & 0xFF) / 255.0f;
        final float f2 = (c >> 16 & 0xFF) / 255.0f;
        final float f3 = (c >> 8 & 0xFF) / 255.0f;
        final float f4 = (c & 0xFF) / 255.0f;
        final float theta = (float)(6.2831852 / num_segments);
        final float p = (float)Math.cos(theta);
        final float s = (float)Math.sin(theta);
        float x;
        r = (x = r * 2.0f);
        float y = 0.0f;
        enableGL2D();
        GL11.glScalef(0.5f, 0.5f, 0.5f);
        GL11.glColor4f(f2, f3, f4, f);
        GL11.glBegin(2);
        for (int ii = 0; ii < num_segments; ++ii) {
            GL11.glVertex2f(x + cx, y + cy);
            final float t = x;
            x = p * x - s * y;
            y = s * t + p * y;
        }
        GL11.glEnd();
        GL11.glScalef(2.0f, 2.0f, 2.0f);
        disableGL2D();
        GL11.glPopMatrix();
    }


    public static void drawFullCircle(int cx, int cy, double r, final int c) {
        r *= 2.0;
        cx *= 2;
        cy *= 2;
        final float f = (c >> 24 & 0xFF) / 255.0f;
        final float f2 = (c >> 16 & 0xFF) / 255.0f;
        final float f3 = (c >> 8 & 0xFF) / 255.0f;
        final float f4 = (c & 0xFF) / 255.0f;
        enableGL2D();
        GL11.glScalef(0.5f, 0.5f, 0.5f);
        GL11.glColor4f(f2, f3, f4, f);
        GL11.glBegin(6);
        for (int i = 0; i <= 2160; ++i) {
            final double x = Math.sin(i * Math.PI / 360.0) * r;
            final double y = Math.cos(i * Math.PI / 360.0) * r;
            GL11.glVertex2d(cx + x, cy + y);
        }
        GL11.glEnd();
        GL11.glScalef(2.0f, 2.0f, 2.0f);
        disableGL2D();
    }

    public static void drawBorderedCircle(final int circleX, final int circleY, final double radius, final double width, final int borderColor, final int innerColor) {
        enableGL2D();
        drawCircle(circleX, circleY, (float)(radius - 0.5), 2160 * 2, borderColor);
        drawFullCircle(circleX, circleY, radius, innerColor);
        disableGL2D();
    }

    public static void drawVLine(final float x, final float y, final float x1, final int y1) {
        final float var11 = (y1 >> 24 & 0xFF) / 255.0f;
        final float var12 = (y1 >> 16 & 0xFF) / 255.0f;
        final float var13 = (y1 >> 8 & 0xFF) / 255.0f;
        final float var14 = (y1 & 0xFF) / 255.0f;
        final Tessellator tes = Tessellator.getInstance();
        GlStateManager.enableAlpha();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        RenderHelper.disableStandardItemLighting();
        GL11.glBegin(6);
        GL11.glVertex2f(x, y);
        GL11.glVertex2f(x1, y);
        GL11.glVertex2f(x + (x1 - x) / 2.0f, y + 3.0f);
        GL11.glEnd();
        tes.draw();
        RenderHelper.enableStandardItemLighting();
    }

    public static void drawLine(Vec2f pre, Vec2f post, ScaledResolution sr, Color color) {

        float scaleX = 1/(sr.getScaledWidth()/2f);
        float scaleY = 1/(sr.getScaledHeight()/2f);

        float preX = (pre.x/scaleX)-1;
        float preY = (pre.y/scaleY)-1;
        float postX = (post.x/scaleX)-1;
        float postY = (post.y/scaleY)-1;

        GL11.glBegin(GL11.GL_LINES);

        GL11.glLineWidth(1);
        GL11.glColor3f(color.getRed()/255f, color.getGreen()/255f, color.getBlue()/255f);

        GL11.glVertex2f(preX, preY);

        GL11.glVertex2f(postX, postY);

        GL11.glEnd();

    }

    static float getThingForLinesInRadialMenu(int flag) {
        switch (flag) {

            case 1: // top left
               return 60;

            case 2:
                return 120;

            case 3:
                return 240;

            case 4:
                return 300;
        }
        return 0;
    }

}
