package dev.windhook.gui.radialgui;

import com.sun.javafx.geom.Vec2f;
import dev.windhook.module.Category;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class RadialCategoryMenu {

    Minecraft mc = Minecraft.getMinecraft();

    public int radius;
    public ArrayList<Category> components;

    Color BACKGROUND_GREY = new Color(20, 20, 20, 150);

    public RadialCategoryMenu(int radius, ArrayList<Category> components) {
        this.radius = radius;
        this.components = components;
    }

    public void onClick(Category category) {

    }

    public Color getColor() {
        return null;
    }

    public void render(Category selected, int color) {
        ScaledResolution sr = new ScaledResolution(mc);
        int x = 60;
        int y = sr.getScaledHeight()/2;
        RadialGuiUtils.drawBorderedCircle(x, y, radius, 1, getColor().getRGB(), BACKGROUND_GREY.getRGB());
        RadialGuiUtils.drawLine(new Vec2f(x, y), new Vec2f(x, y + radius), sr, getColor());
        RadialGuiUtils.drawLine(new Vec2f(x, y), new Vec2f(x, y - radius), sr, getColor());
        for(POSITIONS pos : POSITIONS.values()) {
            Gui.drawRect(x + pos.x + 10, y + pos.y + 10, x + pos.x - 10, y + pos.y - 10, new Color(25 + (25 * pos.category.offset), 100, 100).getRGB());
        }
    }

    private enum POSITIONS {

        ONE(Category.COMBAT, 15, 15),
        TWO(Category.MOVEMENT, 25, 0),
        THREE(Category.RENDER, 15, -15),
        FOUR(Category.EXPLOIT, -15, 15),
        FIVE(Category.PLAYER, -25, 0),
        SIX(Category.WORLD, -15, -15);

        public Category category;
        public int x, y;

        POSITIONS(Category category, int x, int y) {
            this.category = category;
            this.x = x;
            this.y = y;
        }

    }

}
