package dev.windhook.gui.blockminergui;

import dev.windhook.font.UnicodeFontRenderer;

public class MBButton {

    public String text;
    public void click(int mb) {}
    public void draw() {}

    public double x, y;

}
