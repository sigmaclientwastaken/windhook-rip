package dev.windhook.gui.blockminergui;

import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.module.Module;
import dev.windhook.module.settings.Setting;

import java.util.ArrayList;

public class BMModButton extends MBButton{

    public Module mod;
    public ArrayList<BMSettingButton> buttons = new ArrayList<>();

    public boolean expanded;

    public double width = 100, height = 15;
    public final double t;

    public BMModButton(Module mod, double x, double y) {
        this.mod = mod;
        this.x = x;
        this.y = y;

        int counter = 1;
        for(Setting set : mod.settings) {
            buttons.add(new BMSettingButton(set, x, y + (counter * 15)));
            counter++;
        }
        this.t = y + (counter * 15);
    }

    public void clicked(int mb) {}

    @Override
    public void draw() {
        UnicodeFontRenderer fr = BMClickGui.fr19;
        fr.drawString(mod.getName(), (int) x + 2,  (int) y + 1, mod.isToggled()? 0xff901010 : -1, true);
    }

    public double thingy() {
        return t;
    }

}
