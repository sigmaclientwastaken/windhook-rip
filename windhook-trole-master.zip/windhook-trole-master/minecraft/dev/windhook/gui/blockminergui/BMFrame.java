package dev.windhook.gui.blockminergui;

import dev.windhook.BaseClient;
import dev.windhook.module.Category;
import dev.windhook.module.Module;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

public class BMFrame {

    public ArrayList<MBButton> buttons = new ArrayList<>();
    public String title;

    public boolean expanded;

    public double x, y, width = 100, height = 15;
    public final double t;

    public BMFrame(Category category, double x, double  y) {
        this.title = category.getName();
        this.x = x;
        this.y = y;

        int counter = 1;
        for(Module m : BaseClient.instance.getModuleManager().getModules(category)) {
            buttons.add(new BMModButton(m, x, y + (counter * 15)));
            counter++;
        }
        this.t = (counter * 15);
    }

    public BMFrame(String title, double t, MBButton... buttonsList) {
        this.title = title;
        buttons.addAll(Arrays.asList(buttonsList));
        this.t = y + ((buttons.size()+1) * 15);
    }

    public void render() {

        Gui.drawRect(x, y, x + width, y + height, 0xff901010);

        BaseClient.instance.font2.getFont(20).drawString(title, (int) x + 12, (int) y + 2, -1, true);

        if(!expanded)
            return;

        Gui.drawRect(x, y + height, x + width, t, new Color(30, 30, 30, 190).getRGB());

        for(MBButton button : buttons) {
            if(button instanceof BMModButton) {
                if(((BMModButton) button).expanded) {
                    button.draw();
                    GlStateManager.translate(0, ((BMModButton) button).thingy(), 0);
                } else {
                    button.draw();
                }
            } else {
                button.draw();
            }
        }
    }

    public void click(int mx, int my, int mb) {

        if(mx > x && x + width > mx && my > y && y + height > my) {
            if(mb == 1) {
                expanded = !expanded;
            }
        }

    }

}
