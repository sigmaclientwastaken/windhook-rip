package dev.windhook.gui.blockminergui;

import dev.windhook.BaseClient;
import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.module.Category;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;

import java.io.IOException;
import java.util.ArrayList;

public class BMClickGui extends GuiScreen {

    public static UnicodeFontRenderer fr19 = BaseClient.getInstance().font2.getFont(19);

    public ArrayList<BMFrame> frames = new ArrayList<BMFrame>();

    public BMClickGui() {
        int counter = 0;
        for(Category cat : Category.values()) {
            if(cat == Category.HIDDEN || cat == Category.SEMI_HIDDEN)
                continue;

            frames.add(new BMFrame(cat, 10 + (counter * 110), 30));
            counter++;
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {

        GlStateManager.pushMatrix();

        GlStateManager.enableAlpha();
        GlStateManager.enableBlend();

        for(BMFrame frame : frames){
            frame.render();
        }

        GlStateManager.popMatrix();

    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {

        for(BMFrame frame : frames) {
            frame.click(mouseX, mouseY, mouseButton);
        }

    }
}
