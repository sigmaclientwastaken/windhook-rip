package dev.windhook.gui.blockminergui;

import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.module.settings.Setting;

public class BMSettingButton extends MBButton {

    public Setting set;
    public SetType type;

    public double width = 100, height = 15;

    public BMSettingButton(Setting set, double x, double y) {
        this.set = set;
        this.x = x;
        this.y = y;

        if(set instanceof NumberSetting) {
            this.type = SetType.NUMBER;
        } else if(set instanceof ModeSetting) {
            this.type = SetType.MODE;
        } else {
            this.type = SetType.BOOLEAN;
        }
    }

    public void click(int mb) {

        switch(type) {

            case MODE:
                if(mb == 0) {
                    ((ModeSetting)set).cycle();
                } else if(mb == 1) {
                    ((ModeSetting)set).cycleReverse();
                }
                break;

            case BOOLEAN:
                ((BooleanSetting)set).toggle();
                break;

            case NUMBER:
                if(mb == 0) {
                    ((NumberSetting)set).increment(true);
                } else if(mb == 1) {
                    ((NumberSetting)set).increment(false);
                }
                break;

        }

    }

    @Override
    public void draw() {
        UnicodeFontRenderer fr = BMClickGui.fr19;

        switch(type) {

            case MODE:
                fr.drawString(set.name, (int) x + 2, (int) y + 2, -1, true);
                fr.drawString(((ModeSetting)set).getMode(), (int) (x + width - (fr.getStringWidth(((ModeSetting)set).getMode())+2)), (int) y + 2, 0xffaaaaaa, true);
                break;

            case BOOLEAN:
                fr.drawString(set.name, (int) x + 2, (int) y + 2, ((BooleanSetting)set).isEnabled()? 0xff901010 : -1, true);
                break;

            case NUMBER:
                fr.drawString(set.name, (int) x + 2, (int) y + 2, -1, true);
                fr.drawString(((NumberSetting)set).getValue()+"", (int) (x + width - (fr.getStringWidth(((NumberSetting)set).getValue()+"")+2)), (int) y + 2, 0xffaaaaaa, true);
                break;

        }

    }


    public enum SetType {
        MODE,
        NUMBER,
        BOOLEAN
    }

}
