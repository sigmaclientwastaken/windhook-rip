package dev.windhook.config;

import com.google.gson.*;
import dev.windhook.BaseClient;
import dev.windhook.module.Module;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.modules.render.XRay;
import dev.windhook.module.settings.BooleanSetting;
import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.NumberSetting;
import dev.windhook.module.settings.Setting;
import net.minecraft.client.Minecraft;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class ConfigManager {

    static final Logger logger = LogManager.getLogger();
    static Minecraft mc = Minecraft.getMinecraft();

    protected static void saveConfig(Path path) {
        JsonObject config = new JsonObject();

        ModuleManager.modules.forEach(m -> {
            JsonObject module = new JsonObject();

            JsonObject settings = new JsonObject();

            m.settings.forEach(s -> {
                JsonObject settingObject = new JsonObject();

                settingObject.addProperty("name", s.name);
                settingObject.addProperty("type", s instanceof BooleanSetting ? "bool" : s instanceof NumberSetting ? "num" : "mode");

                try {
                    switch (settingObject.get("type").getAsString()) {

                        case "bool":
                            assert s instanceof BooleanSetting;
                            settingObject.addProperty("value", (((BooleanSetting) s).isEnabled()));
                            break;

                        case "num":
                            assert s instanceof NumberSetting;
                            settingObject.addProperty("value", (((NumberSetting) s).getValue()));
                            break;

                        case "mode":
                            assert s instanceof ModeSetting;
                            settingObject.addProperty("value", (((ModeSetting) s).getMode()));
                            break;

                    }
                } catch(Exception e) {
                    logger.fatal("Error loading config!!!", e);
                }

                settings.add(s.name, settingObject);
            });

            module.add("settings", settings);

            module.addProperty("name", m.getName());
            module.addProperty("toggled", m.isToggled());
            module.addProperty("key", m.getKey());

            try {
                if (Objects.equals(m.getName(), "XRay")) {
                    JsonArray arr = new JsonArray();
                    for (int i : ((XRay) m).get()) {
                        arr.add(new JsonPrimitive(i));
                    }
                    module.add("blocks", arr);
                }
            } catch (Exception e) {
                logger.warn("Error saving XRay blocks!");
            }

            config.add(m.getName(), module);
        });

        try {
            Files.write(path, Arrays.asList(config.toString()));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void loadConfig(Path path) {
        JsonParser parser = new JsonParser();

        try {
            parser.parse(new String(Files.readAllBytes(path))).getAsJsonObject().entrySet().forEach(moduleEntry -> {

                JsonObject moduleObject = moduleEntry.getValue().getAsJsonObject();
                JsonObject settings = (moduleObject.getAsJsonObject("settings"));

                Module module = BaseClient.getInstance().getModuleManager().getModule(moduleObject.get("name").getAsString());

                if(module != null) {

                    module.setToggledSilent(moduleObject.get("toggled").getAsBoolean());
                    module.nalFade = 1;
                    module.setKey(moduleObject.get("key").getAsInt());

                    if(settings != null) {

                        module.settings.forEach(setting -> {
                            if (settings.has(setting.name)) {
                                JsonObject a = settings.get(setting.name).getAsJsonObject();

                                if (a != null) {

                                    if (!(a.get("type").isJsonNull() || a.get("value").isJsonNull())) {

                                        switch (a.get("type").getAsString()) {

                                            case "bool":
                                                ((BooleanSetting) setting).setEnabled(a.get("value").getAsBoolean());
                                                break;

                                            case "num":
                                                ((NumberSetting) setting).setValue(a.get("value").getAsDouble());
                                                break;

                                            case "mode":
                                                ((ModeSetting) setting).set(a.get("value").getAsString());
                                                break;

                                        }

                                    }

                                }

                            }
                        });

                    }

                    try {
                        if (Objects.equals(module.getName(), "XRay")) {
                            ArrayList<Integer> values = new ArrayList<Integer>();
                            JsonArray array = moduleObject.getAsJsonArray("blocks");
                            for (JsonElement value : array) {
                                values.add(value.getAsInt());
                            }
                            ((XRay) module).KEY_IDS = values;
                        }
                    } catch (Exception e) {
                        if (e instanceof NullPointerException) {
                            logger.info("XRay blocks do not exist!");
                        } else {
                            logger.error(e);
                        }
                    }
                }

            });
        } catch (JsonSyntaxException | IOException e) {
            e.printStackTrace();
        }
    }

    public static void setupConfigManager() {
        try {
            Files.createDirectories(Paths.get("WindHookConfigs"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void save(String name) {
        saveConfig(Paths.get("WindHookConfigs",name+".json"));
    }

    public static void load(String name) {
        loadConfig(Paths.get("WindHookConfigs",name+".json"));
    }


    public static void saveDefault() {
        saveConfig(Paths.get("WindHook","settings.json"));
    }

    public static void loadDefault() {
        loadConfig(Paths.get("WindHook","settings.json"));
    }



}
