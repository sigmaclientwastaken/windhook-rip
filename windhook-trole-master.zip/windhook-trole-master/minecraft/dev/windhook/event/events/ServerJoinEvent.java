package dev.windhook.event.events;

import dev.windhook.event.Event;
import net.minecraft.client.multiplayer.ServerData;

public class ServerJoinEvent extends Event {

	private final ServerData serverData;

	public ServerJoinEvent(final ServerData serverData) {
		this.serverData = serverData;
	}

	public ServerData getServerData() {
		return serverData;
	}


}