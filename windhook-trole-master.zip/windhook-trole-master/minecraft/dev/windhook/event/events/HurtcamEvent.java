package dev.windhook.event.events;

import dev.windhook.event.CancellableEvent;

public class HurtcamEvent extends CancellableEvent {
}
