package dev.windhook.event.events;

import dev.windhook.event.CancellableEvent;

public class VelocityEvent extends CancellableEvent {

}
