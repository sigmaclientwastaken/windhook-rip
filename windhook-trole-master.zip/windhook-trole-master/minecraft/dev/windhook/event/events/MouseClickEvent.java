package dev.windhook.event.events;

import dev.windhook.utils.KeyUtils;
import dev.windhook.event.Event;

public class MouseClickEvent extends Event {

	private int button;

	/**
	 * @formatter:off
	 * Directions:
	 * 0 = LEFT CLICK
	 * 1 = RIGHT CLICK
	 * 2 = WHEEL CLICK
	 * 
	 * Check the MouseButton enum (inside of the KeyUtils class) for more informations about how the mouse buttons work
	 * 
	 */
	public MouseClickEvent(int button) {
		this.button = button;
	}
	
	public int getButton() {
		return button;
	}
	
	public KeyUtils.MouseButton getMouseButton() {
		return KeyUtils.MouseButton.getFromDefaultCode(button);
	}

}