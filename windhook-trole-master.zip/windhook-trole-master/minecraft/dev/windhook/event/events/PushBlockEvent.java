package dev.windhook.event.events;

import dev.windhook.event.CancellableEvent;

public class PushBlockEvent extends CancellableEvent {

	private Type eventType;

	public Type getEventType() {
		return eventType;
	}

	public void setEventType(Type eventType) {
		this.eventType = eventType;
	}

	public PushBlockEvent() {
	}

	public enum Type {
		PRE,
		POST
	}

}