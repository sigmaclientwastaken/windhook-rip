package dev.windhook.event.events;

import dev.windhook.event.Event;

public class PreRender3DEvent extends Event {

	private float partialTicks;

	public PreRender3DEvent(float partialTicks) {
		this.partialTicks = partialTicks;
	}

	public float getPartialTicks() {
		return partialTicks;
	}

}