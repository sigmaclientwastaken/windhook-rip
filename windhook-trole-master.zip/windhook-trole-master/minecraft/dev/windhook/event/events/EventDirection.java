package dev.windhook.event.events;

public enum EventDirection {
    INCOMING,
    OUTGOING
}