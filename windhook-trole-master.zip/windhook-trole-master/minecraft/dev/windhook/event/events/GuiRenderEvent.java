package dev.windhook.event.events;

import dev.windhook.event.Event;

public class GuiRenderEvent extends Event {

    public float partialTicks;

    public GuiRenderEvent(float partialTicks) {
        this.partialTicks = partialTicks;
    }

}