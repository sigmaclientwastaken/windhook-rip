package dev.windhook.event.events;

import dev.windhook.event.Event;

public class UpdateEvent extends Event {

}