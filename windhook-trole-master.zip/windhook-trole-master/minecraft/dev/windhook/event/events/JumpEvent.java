package dev.windhook.event.events;

import dev.windhook.event.Event;

public class JumpEvent extends Event {
    private double motionY;
    private final boolean pre;

    public JumpEvent(double motionY, boolean pre) {
        this.motionY = motionY;
        this.pre = pre;
    }

    public double getMotionY() {
        return motionY;
    }
    public void setMotionY(double motiony) {
        this.motionY = motiony;
    }

    public boolean isPre() {
        return pre;
    }

    public boolean isPost() {
        return !pre;
    }
}
