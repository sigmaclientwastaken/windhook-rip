package dev.windhook.event;

public class Event {

	public Event() {
	}

}