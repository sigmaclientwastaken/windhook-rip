package dev.windhook;

import java.io.File;

import dev.windhook.auth.HWIDManager;
import dev.windhook.config.ConfigManager;
import dev.windhook.gui.astolfogui.AstolfoScreen;
import dev.windhook.gui.dropdowngui.DropdownGUI;
import dev.windhook.module.modules.Client;
import dev.windhook.module.modules.client.ClickGuiNew;
import dev.windhook.module.modules.render.ESP;
import dev.windhook.replay.ReplayManager;
import dev.windhook.utils.Blur;
import net.arikia.dev.drpc.DiscordEventHandlers;
import net.arikia.dev.drpc.DiscordRPC;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import org.apache.logging.log4j.LogManager;
import org.lwjgl.opengl.Display;

import dev.windhook.account.AccountManager;
import dev.windhook.command.CommandManager;
import dev.windhook.event.EventManager;
import dev.windhook.font.Font;
import dev.windhook.friends.FriendsManager;
import dev.windhook.gui.altmanager.GuiAltManager;
import dev.windhook.gui.clickgui.ClickGui;
import dev.windhook.hooks.HookManager;
import dev.windhook.irc.IRCClient;
import dev.windhook.module.ModuleManager;
import dev.windhook.overlay.TabGui1;
import dev.windhook.overlay.ToggledModules1;
import dev.windhook.thealtening.AltService;
import dev.windhook.utils.Config;
import dev.windhook.utils.Files;
import dev.windhook.utils.Strings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.Locale;

public class BaseClient {

	/**
	 * Credits
	 *
	 * Base: OxideWavelength's base, AcaiBerii's fork
	 * Fonts: Slick's font manager edited by Russian412 and color system by OxideWavelength
	 * Alt Manager: Russian412's Alt Manager with some small bug-fixes by OxideWavelength
	 * The Altening Implementation: Russian412
	 * ZeroDay b21 colored ClickGUI, epic arraylist and client module group: AcaiBerii
	 * 
	 * Everything else in the base is made by OxideWavelength
	 *
	 * WindHook by sigmaclientwastaken and Segation
	 **/

	private String clientName = "WindHook";
	private String clientVersion = "b7";
	private final String author = "sigmaclientwastaken & Segation";

	public Integer userUID;
	public String userUserName;

	public static BaseClient instance;
	private DiscordEventHandlers handlers;
	
	public static DiscordRP discordRP = new DiscordRP();

	private final String defaultUsername = "WindHookUser";

	public Blur blur;

	private EventManager eventManager;

	private FriendsManager friendsManager;

	private CommandManager commandManager;
	private ModuleManager moduleManager;
	public ReplayManager replayManager;

	private IRCClient ircClient;

	private AccountManager accountManager;

	private AltService altService;

	private Font font;

	public Font font2;

	private String packageBase = "dev.windhook";

	private Config genericConfig;

	private ClickGui clickGui;
	private DropdownGUI dropdownGUI;

	public boolean isReplay = false;
	public boolean isRecording = false;

	public DropdownGUI getDropdownGUI() {
		return dropdownGUI;
	}

	public void setDropdownGUI(DropdownGUI dropdownGUI) {
		this.dropdownGUI = dropdownGUI;
	}

	private Locale englishLocale;

	private ClassLoader loader = ClassLoader.getSystemClassLoader();

	public BaseClient() {
		instance = this;
	}

	public void initialize() {
		instance = this;

		printStartup();
		setupShutdownHook();

		Display.setTitle(String.format("%1$s %2$s | Loading...", clientName, clientVersion));

		this.englishLocale = new Locale();

		this.ircClient = new IRCClient("chat.freenode.net", 6667, Minecraft.getMinecraft().getSession().getUsername(),
				"#WaveLengthBaseClient");

		new GuiAltManager(); // We create the instance.

		String clientFolder = new File(".").getAbsolutePath();

		clientFolder = (clientFolder.contains("jars")
				? new File(".").getAbsolutePath().substring(0, clientFolder.length() - 2)
				: new File(".").getAbsolutePath()) + Strings.getSplitter() + clientName;

		String accountManagerFolder = clientFolder + Strings.getSplitter() + "alts";

		Files.createRecursiveFolder(accountManagerFolder);

		this.accountManager = new AccountManager(new File(accountManagerFolder));

		this.clickGui = new ClickGui();
		discordRP.start();

		this.eventManager = new EventManager();

		this.friendsManager = new FriendsManager();

		this.replayManager = new ReplayManager();

		this.commandManager = new CommandManager(".");

		this.moduleManager = new ModuleManager();

		commandManager.registerCommands(); // Moved here to make sure the CommandManager instance is created, else the
											// "commandManager" variable in the Command class would be null (since we
											// are
											// getting the CommandManager instance from this class)

		this.altService = new AltService();

		switchToMojang();

		this.genericConfig = new Config(new File(clientFolder + Strings.getSplitter() + "config.cfg"));

		/** Setting a custom icon */

		/** Both 16x16 and 32x32 version encoded in Base64 */
		String icon16x16 = "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAZdJREFUOE9jZKAQMFKon2EQGCDIIMhfGdV39N9blvdXH13csfh6TyvIW7Pd9h/QE7WwvPX+0tXus0VZl14ePcHAwMDaEDB5r6aCvvmZayfmdu8qy4J5gTlOr6hm0aW+RqQwYdwT+uLN868Pb8duM7dAFo93yO1beGByIUgMHgYzXPaczdjjYgxTGKaakXf6zZEDiz2OnbZZzsfJwMDwDyQXqB9XtP7ioskMDAy/UQyQ4FBQ4OUQELj94cIFkMSe0JffXVaLc0ZoZmdzs/DzzL3c1gkSnxa88WbWWn91mEUosbDU68zN6G0m6goCCgpe8slJ0y7W1oFceSzq6y+rZdysMnzKKizs7DwPXl8DW4LiAhDHXzk5fePduQsWe506HrvNzJSBgeEvSHyK0/Z9Ey4U5xZYdyzN2exngJx20NMBY4lx30x9MWvr2O3m2jCFvLxSIpMcV5zc/2L1ikWnJlfjMUCUZ03U7tcv3jy5evrp/g0Lr/a2gBQ3uszeoamo63bmzf4dXesrvfC5gOSUPQiSMsluRtMAAK9QkhGiYFsMAAAAAElFTkSuQmCC";
		String icon32x32 = "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAABNZJREFUWEdjZBhgwDjA9jOMOmA0BGAhwIQlMf7DkUCxqQUp/Q/F6NpAdqCHNFwto5aMnnllaPcJ5l/sDGw/uRnYfvIwsP3kYnj/9e2dyK1GqsimSXOqyGwMvv6YgRFq3v//DP/+/wPjv///Mlgv58GI0jUpp///Yv/K8JftJwMXIx8DFyM/AzcjH4NdjwxYLUwDS5RZRrW7cnh6/HJHOailf3CEAAtIfI3f5dNKAtoGz78+vu+9Vl6NgYEBFGLYQo0Zag/jqqLDv5Jne4l8/vz5AwMDw19kB4DYrBvir/wKWKjDxsDA8JtA+cB4KvrHP0ZGJgYmRmYG48XMIEeBDcQFHHS8Y5Kc8mbFTXLnQlaDEmRLQo89231zw9SFl7pa8RnmIh8S1GS1YO2+xxvnu8mHJE47X5O34Fr3ZHx65qRvebfp/NKWTaeW9+F0gLWMq1e12Zz1Xuvk2fEZtjnw3ktuVl4Bp1WifCeivv34x/Dvm9UyHm48ejiXZR/4FjXVgZWBgQElajESza7gZ/9jdxqKv/zy8hUOA9n2hb7+ufLGlKaZlxvrd4U8fS3AISLitkRc8APDB1DcYoBU6/JuIxWLiMyFgbLYsgiK2GSnrYe+//n6ruxQWAA2w9L06urD1LIaXNZIgELpl4d8eFCTzaK1B55uWFp2IDwGm541iad/tx/I9z57/9gugg6Q51dXnO925J7TalGspSTI919+f/zot0FFDGbYqZhf/1mYWP4bLWLCKCOkOaVlJkVtehw81xireVgF94S8/FN2OMjm3MujJ5BdLMEjIbrG59arpmPJobserV4Dk1vmfeakhpChWexOS4Orr05dRNbT5r5kBxP7P+6KTXG22EIHqwMKTHr7LSScvSO2GIDyNxz0OaxfYyXlEWyxjBPkU1BpBgbqvHrqSwPO3bj3/urlsC36esh6NsVe+5+10Vf1yae7d4h2AAMDA+f+sLffHFcJgwoReOFyLvbvv9sfr1wM36RviG7Yyegff//9/8tkuYwb7jh9KWubBtfpBwMX6oHMwQpw1oabA+69W3y1u2rV7ekzQDq1RE0MF3ucOBe/xUz/yvtzl9BNq7OcNcNdITK943Ru3OY7CxaD5OcHHLpz4e2hfRMP16SR7AAPhcjIAqOuWR7rZHlBmlf6XLikwK+hY76UA2tlJMogyrM2/PZnUAL1WicvwMDAwLQx9trf5MV2fG8Y3nwm2QGg8ntvyMt/oWs0+d8xvPt8JOLTv6PPtq0sPxQRgcuw7YGPP7Ixs/E5r9HjCVT3jo0wT+8JX2TOg0s9SBxvg2S264FzDz5dP3/u5cFdFebTVvhs0xX5/PnpW1wG+iklJOUYtc7d8nDhVGs11/illyZWbrq8ZArZDlAW1NOZ5rTt4vc/395zsfDwuK2V4sBnGMhDWyPu/vvD9uP/b9bvjCFzTQhWUoSaZIxbIm//ZfnDzrjy2tTa+Vc7YZUUPAuiOYhxeuC2K2JC4lqvfj1+mLk4QBFHIwWuDa8D1qSc+c/ym42B+S8bA9NfVgamv8wMTP+ZGdxXy6KUAyDTNsXc+PeP+RfjH9afDH9YfjL8Yf3B8J/lL0Nsvzu4yCYnEYL0gCxCz8OgcgFb3Y9NLSikcDVswG4iFAUEopxy6VEHjIbAgIcAANGfxjDZ7+/RAAAAAElFTkSuQmCC";

		/** Calling the #setWindowIcon() method with the two encoded icons */
		Minecraft.getMinecraft().setWindowIcon(icon16x16, icon32x32);

		/* Discord RPC code */
		handlers = new DiscordEventHandlers.Builder().setReadyEventHandler((user) -> {
			LogManager.getLogger("WindHook").info("Welcome " + user.username + "#" + user.discriminator + "!");
		}).build();
		DiscordRPC.discordInitialize("903625392177434644", handlers, true);

		blur = new Blur();
	}

	public void afterMinecraft() {
		Display.setTitle(String.format("%1$s %2$s | dsc.gg/windhook", clientName, clientVersion));

		this.font = new Font(packageBase + ".font.fonts", "jellolight", 25, 30, 33, 50, 55);
		this.font2 = new Font(packageBase + ".font.fonts", "mono", 25, 30, 33, 50, 55);

		registerHuds();

		this.dropdownGUI = new DropdownGUI();

		ConfigManager.setupConfigManager();
		ConfigManager.loadDefault();

		Client.launch();

		moduleManager.setupArray();

		blur.init();

		HWIDManager.hwidCheck();

		if(!Minecraft.getMinecraft().isFullScreen())
			Minecraft.getMinecraft().toggleFullscreen();

		userUID = HWIDManager.getUserUID();
		userUserName = HWIDManager.getUserName();

		LogManager.getLogger("WindHook").info("Welcome " + userUserName + ", UID: " + userUID.toString() + "!");

		ClickGuiNew.astolfoScreen = new AstolfoScreen();

	}

	private void registerHuds() {
		new ToggledModules1();
		new TabGui1();
	}

	public String getClientName() {
		return clientName;
	}

	public String getClientVersion() {
		return clientVersion;
	}

	public String getAuthor() {
		return author;
	}

	public String getDefaultUsername() {
		return defaultUsername;
	}

	public EventManager getEventManager() {
		return eventManager;
	}

	public FriendsManager getFriendsManager() {
		return friendsManager;
	}

	public CommandManager getCommandManager() {
		return commandManager;
	}

	public ModuleManager getModuleManager() {
		return moduleManager;
	}

	public IRCClient getIRCClient() {
		return ircClient;
	}

	public AccountManager getAccountManager() {
		return accountManager;
	}

	public AltService getAltService() {
		return altService;
	}

	@Deprecated
	public Font getFontRenderer() {
		return font;
	}

	public Font getFont() {
		return font;
	}

	public String getPackageBase() {
		return packageBase;
	}

	public Config getGenericConfig() {
		return genericConfig;
	}

	public ClickGui getClickGui() {
		return clickGui;
	}

	public Locale getEnglishLocale() {
		return englishLocale;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public void setClientVersion(String clientVersion) {
		this.clientVersion = clientVersion;
	}

	public ClassLoader getLoader() {
		return this.loader;
	}

	public void switchToMojang() {
		try {
			this.altService.switchService(AltService.EnumAltService.MOJANG);
		} catch (NoSuchFieldException e) {
			LogManager.getLogger("WindHook").info("Couldn't switch to modank altservice");
		} catch (IllegalAccessException e) {
			LogManager.getLogger("WindHook").info("Couldn't switch to modank altservice -2");
		}
	}

	public void switchToTheAltening() {
		try {
			this.altService.switchService(AltService.EnumAltService.THEALTENING);
		} catch (NoSuchFieldException e) {
			LogManager.getLogger("WindHook").info("Couldn't switch to altening altservice");
		} catch (IllegalAccessException e) {
			LogManager.getLogger("WindHook").info("Couldn't switch to altening altservice -2");
		}
	}

	public void setupShutdownHook() {
		boolean shutdownHookInit = HookManager.installShutdownHook(new Thread(() -> {
			DiscordRPC.discordShutdown();
			ConfigManager.saveDefault();
			LogManager.getLogger("WindHook").info(String.format("%s %s shutting down.", this.clientName, this.clientVersion));
		}));

		System.out.println(
				String.format("Shutdown hook %s initialized.", shutdownHookInit ? "successfully" : "unsuccessfully"));
	}

	public void printStartup() {
		LogManager.getLogger("WindHook").info(String.format("%s %s starting up.", this.clientName, this.clientVersion));
	//	MainGameLoop.main(new String[]{});
	}

	public static void chatMessage(String message) {
		Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage((IChatComponent) new ChatComponentText("§8[§j!§8] §7" + message));
	}


	public static BaseClient getInstance() {
		return BaseClient.instance;
	}
	
	public static DiscordRP getDiscordRP() {
		return discordRP;
	}

}