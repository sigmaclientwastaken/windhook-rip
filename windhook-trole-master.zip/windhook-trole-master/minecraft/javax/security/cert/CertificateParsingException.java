package javax.security.cert;

public class CertificateParsingException extends CertificateException {
   public CertificateParsingException() {
   }

   public CertificateParsingException(String var1) {
      super(var1);
   }
}
