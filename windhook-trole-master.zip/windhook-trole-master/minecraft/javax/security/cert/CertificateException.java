package javax.security.cert;

public class CertificateException extends Exception {
   public CertificateException() {
   }

   public CertificateException(String var1) {
      super(var1);
   }
}
