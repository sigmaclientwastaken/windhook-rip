package javax.security.cert;

public class CertificateExpiredException extends CertificateException {
   public CertificateExpiredException() {
   }

   public CertificateExpiredException(String var1) {
      super(var1);
   }
}
