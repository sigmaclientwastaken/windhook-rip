package javax.net.ssl;

public class SSLProtocolException extends SSLException {
   public SSLProtocolException(String var1) {
      super(var1);
   }
}
