package javax.net.ssl;

import java.io.IOException;

public class SSLException extends IOException {
   public SSLException(String var1) {
      super(var1);
   }
}
