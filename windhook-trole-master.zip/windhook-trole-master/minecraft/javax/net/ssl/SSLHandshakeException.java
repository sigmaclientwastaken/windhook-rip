package javax.net.ssl;

public class SSLHandshakeException extends SSLException {
   public SSLHandshakeException(String var1) {
      super(var1);
   }
}
