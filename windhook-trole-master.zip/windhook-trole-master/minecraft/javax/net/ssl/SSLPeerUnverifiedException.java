package javax.net.ssl;

public class SSLPeerUnverifiedException extends SSLException {
   public SSLPeerUnverifiedException(String var1) {
      super(var1);
   }
}
