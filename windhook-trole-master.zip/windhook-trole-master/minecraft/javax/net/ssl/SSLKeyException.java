package javax.net.ssl;

public class SSLKeyException extends SSLException {
   public SSLKeyException(String var1) {
      super(var1);
   }
}
